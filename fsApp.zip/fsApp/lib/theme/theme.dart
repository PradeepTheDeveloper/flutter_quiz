import 'package:flutter/material.dart'
    show
        ThemeData,
        Brightness,
        AppBarTheme,
        ElevatedButtonThemeData,
        ElevatedButton,
        FloatingActionButtonThemeData,
        BottomSheetThemeData,
        Colors;
import 'package:fserv/constants/app_constants.dart';

class AppTheme {
  static ThemeData one = ThemeData(
      primaryColor: AppColors.blue,
      scaffoldBackgroundColor: AppColors.black,
      brightness: Brightness.dark,
      appBarTheme: const AppBarTheme(
          centerTitle: true,
          backgroundColor: AppColors.blue,
          titleTextStyle: AppStyles.appBarTextStyle,
          elevation: 0),
      elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.green, elevation: 0)),
      floatingActionButtonTheme: const FloatingActionButtonThemeData(
          backgroundColor: AppColors.green, foregroundColor: AppColors.green),
      bottomSheetTheme:
          const BottomSheetThemeData(backgroundColor: Colors.transparent));
}
