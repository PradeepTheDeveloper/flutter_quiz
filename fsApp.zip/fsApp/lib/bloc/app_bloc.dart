import 'package:flutter/material.dart'
    show
        ConnectionState,
        Widget,
        WidgetBuilder,
        StreamBuilder,
        BuildContext,
        AsyncSnapshot,
        Builder;
import 'package:rxdart/rxdart.dart' show BehaviorSubject;
import 'dart:async';

import 'package:flutter/material.dart';

class AppBloc<E> {
  ConnectionState connectionState = ConnectionState.waiting;
  E? data;
  final BehaviorSubject<E> subject = BehaviorSubject<E>();
  Stream<E> get _subjectStream => subject.stream;
  StreamSink<E> get subjectSink => subject.sink;

  void change(E value) {
    subjectSink.add(value);
  }

  void close() {
    subject.close();
  }

  Widget stream(WidgetBuilder builder) => StreamBuilder<E>(
      stream: _subjectStream,
      initialData: data,
      builder: (BuildContext context, AsyncSnapshot<E> snapshot) {
        connectionState = snapshot.connectionState;
        data = snapshot.data;
        return Builder(builder: builder);
      });
}
