import 'package:flutter/services.dart' show MethodChannel;
import 'package:fserv/model/device.dart';
import 'dart:io' show Platform;

Future<Device> getDeviceInfo() async {
  String deviceModel =
      await const MethodChannel('deviceInfo').invokeMethod("deviceModel");

  String deviceID =
      await const MethodChannel('deviceInfo').invokeMethod("deviceID");

  String osVersion =
      await const MethodChannel('deviceInfo').invokeMethod("deviceOsVersion");

  Device deviceData = Device(
    deviceID,
    deviceModel,
    Platform.operatingSystem,
    osVersion,
  );


  return deviceData;
}
