import 'package:flutter_secure_storage/flutter_secure_storage.dart'
    show FlutterSecureStorage;
import 'package:fserv/functions/appfunctions.dart';

class CacheStorage {
  static const FlutterSecureStorage cache = FlutterSecureStorage();

  static Future<void> storeString(String key, String value) async =>
      await cache.write(key: key, value: value);

  static Future<void> storeBool(String key, bool value) async =>
      await cache.write(key: key, value: value.toString());

  static Future<void> storeInt(String key, int value) async =>
      await cache.write(key: key, value: value.toString());

  static Future<void> storeDouble(String key, double value) async =>
      await cache.write(key: key, value: value.toString());

  static Future<String> readString(String key) async =>
      await cache.read(key: key) ?? "";

  static Future<bool> readBool(String key) async =>
      boolEncode(await cache.read(key: key) ?? " ");

  static Future<int> readInt(String key) async =>
      int.tryParse(await cache.read(key: key) ?? "0") ?? 0;

  static Future<double> readDouble(String key) async =>
      double.tryParse(await cache.read(key: key) ?? "0") ?? 0;
}
