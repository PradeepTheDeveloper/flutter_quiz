import 'package:flutter/services.dart';

class NewRelic {
  static const MethodChannel _newRelicMethod = MethodChannel("newRelic");

  static Future<String?> _noticeHttpTransaction(
    String url,
    String httpMethod,
    int startTime,
    int endTime,
    int statusCode,
    int bytesSent,
    int bytesReceived,
  ) =>
      _newRelicMethod.invokeMethod<String>("noticeHttpTransaction", {
        "url": url,
        "httpMethod": httpMethod,
        "statusCode": statusCode,
        "bytesSent": bytesSent,
        "bytesReceived": bytesReceived,
        "startTime": startTime,
        "endTime": endTime,
      });

  static Future<bool?> setAttribute(String name, String value) async =>
      await _newRelicMethod
          .invokeMethod<bool>("setAttribute", {"name": name, "value": value});

  static Future<bool?> removeAttribute(String name) async =>
      await _newRelicMethod
          .invokeMethod<bool>("removeAttribute", {"name": name});

  static Future<String> noticeHttpTransaction({
    required String url,
    required String httpMethod,
    required int startTime,
    required int endTime,
    required int statusCode,
    required int bytesSent,
    required int bytesReceived,
  }) async {
    String value;
    value = await _noticeHttpTransaction(url, httpMethod, startTime, endTime,
            statusCode, bytesSent, bytesReceived) ??
        "Error";
    return value;
  }
}
