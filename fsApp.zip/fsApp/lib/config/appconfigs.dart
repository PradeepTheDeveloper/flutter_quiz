library appconfigs;

export 'device_info.dart';
export 'flavourconfig.dart';
export 'prefs.dart';
export 'request_params.dart';
