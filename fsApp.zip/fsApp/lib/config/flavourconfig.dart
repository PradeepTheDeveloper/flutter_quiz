import 'package:flutter/material.dart'
    show InheritedWidget, ThemeData, Widget, Key, BuildContext;

enum AppEnvironment { dev, qaTest, prod, prodTest }

class AppConfig extends InheritedWidget {
  final AppEnvironment appEnvironment;
  final String appName;
  final String description;
  final String baseUrl;
  final ThemeData themeData;
  final Widget widget;

  const AppConfig({
    Key? key,
    required this.appEnvironment,
    required this.appName,
    required this.description,
    required this.baseUrl,
    required this.themeData,
    required this.widget,
  }) : super(key: key, child: widget);

  static AppConfig? of(BuildContext context) {
    return context.dependOnInheritedWidgetOfExactType();
  }

  @override
  bool updateShouldNotify(InheritedWidget oldWidget) => false;
}
