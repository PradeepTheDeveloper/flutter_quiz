import 'dart:convert' show jsonEncode;
import '/constants/strings.dart';
import '/constants/variables.dart';

class AppHttpBody {
  static String registerBody(
    String userName,
    String password,
  ) =>
      jsonEncode(
        {
          ApiBodyStrings.userName: userName,
          ApiBodyStrings.password: password,
          ApiBodyStrings.billingCompanyID: billingCompanyID,
          ApiBodyStrings.userID: userID,
          ApiBodyStrings.deviceID: deviceInfo.deviceId,
          ApiBodyStrings.deviceModel: deviceInfo.deviceModel,
          ApiBodyStrings.deviceOS: deviceInfo.deviceOs,
          ApiBodyStrings.deviceOSVersion: deviceInfo.deviceOsVersion,
          ApiBodyStrings.pushNotificationToken: null,
        },
      );

  static String unregisterBody() => jsonEncode({
        ApiBodyStrings.userID: userID,
        ApiBodyStrings.deviceID: deviceInfo.deviceId,
        ApiBodyStrings.userDeviceInformationID: userDeviceInformationID,
      });

  static String getJWTBody() {
    Map body = {
      ApiBodyStrings.userID: userID,
      ApiBodyStrings.uniqueDeviceID: uniqueDeviceID,
    };

    if (uniqueDeviceID.isEmpty) {
      body.addEntries([MapEntry(ApiBodyStrings.deviceID, deviceInfo.deviceId)]);
    }
    return jsonEncode(body);
  }

  static String addSkipReason(Map<String, dynamic> meterSkipReason) =>
      jsonEncode(meterSkipReason);
}

class AppHttpHeaders {
  static Map<String, String> get contentTypeJson =>
      {"Content-Type": "application/json"};
  static Map<String, String> get withAuthorization => {
        "Content-Type": "application/json",
        "authorization": "Brearer $jwtToken",
      };
}
