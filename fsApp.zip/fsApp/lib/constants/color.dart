import 'package:flutter/material.dart' show Color, Colors;

class AppColors {
  static const Color appBackgroundColor = Color(0xff000000);

  static const Color red = Color(0xffff0000);

  static const Color backSpaceColor = Color(0xffff0000); //red

  static const Color lightWhite = Color(0xffc4c4c4);

  static const Color transparent = Colors.transparent;

  static const Color pinFieldColor = Color(0xffc4c4c4);

  static const Color white = Color(0xffffffff);

  static const Color showPinIconActiveColor = Color(0xffffffff);

  static const Color iconColor = Color(0xffffffff);

  static const Color inactiveTabText = Color(0xffffffff);

  static const Color appBartext = Color(0xffffffff);

  static const Color black = Color(0xff000000);

  static const Color pinFieldText = Color(0xff000000);

  static const Color cursorColor = Color(0xff000000);

  static const Color numberKeyText = Color(0xff000000);

  static const Color activeTabText = Color(0xff000000);

  static const Color buttontext = Color(0xff000000);

  static const Color yellow = Color(0xfff7ba32);

  static const Color meterListTodoCard = Color(0xfff7ba32);

  static const Color meterListSkippedCard = Color(0xff0D72BA);

  static const Color pinFieldFocus = Color(0xfff7ba32);

  static const Color numberKeyColor = Color(0xfff7ba32);

  static const Color green = Color(0xff71d300);

  static const Color meterListCompletedCard = Color(0xff71d300);

  static const Color activeTabColor = Color(0xff71d300);

  static const Color buttonColor = Color(0xff71d300);

  static const Color grey = Color(0xff21211F);

  static const Color showPinIconInActiveColor = Color(0xff21211F);

  static const Color routeListCardColor = Color(0xff21211F);

  static const Color inactiveTabColor = Color(0xff21211F);

  static const Color lightgrey = Color(0xff878683);

  static const Color blue = Color(0xff0D72BA);

  static const Color qrBorder = Color(0xff0D72BA);

  static const Color appBarColor = Color(0xff0D72BA);

  static const Color introBackgroundColor = Color(0xff0D72BA);

  static const Color darkBlue = Color(0xff070E16);

  static const Color lightGreen = Color(0xff07FE16);
}
