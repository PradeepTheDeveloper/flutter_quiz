class RemoteConfigKeys {
  static const String appUpdateCodes = "appUpdateCodes";
}
