import 'dart:io';

import 'package:flutter/material.dart'
    show BuildContext, GlobalKey, MediaQuery, ScaffoldState;
import '../model/work_order_taskbin.dart';
import '/functions/appfunctions.dart';
import '/model/appmodels.dart';
import '/model/skip_reason.dart';

double width = SizeConfig.width;
double height = SizeConfig.height;
bool isMobile = SizeConfig.isMobile;
bool isPortrait = SizeConfig.isPortrait;
bool isLandscape = SizeConfig.isLandscape;

enum MeterListType { todo, completed, skipped }

enum SaveApiResponse {
  success,
  failed,
  unexpectedError,
  paramaterError,
  meterNotFound,
  noInternet,
}

final GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();

bool isAppUpdated = false;

late BuildContext currentContext;

double get bottomInset => MediaQuery.of(currentContext).viewInsets.bottom;

Duration requestTimeout = const Duration(seconds: 60);

Duration loaderTimeOut = const Duration(milliseconds: 500);

Duration loaderStart = const Duration(milliseconds: 200);

DateTime jwtTokenTimer = timeNow;

bool flexUpdate = false;
bool forceUpdate = false;
bool isRegistered = false;
bool pinCreated = false;
bool isScanned = false;
bool routeOrder = true;
bool ascendingOrder = true;
bool canResume = true;
late bool mtrReadAppGPS;
bool allRoutesGlobal = false;
late Device deviceInfo;
late QRData qrData;
bool isversionUpdated = false;
bool chooseDashboard = false;

bool latlon = false;

const dot = ".";

List<TaskBin> taskBinList = [];

String readingLatitude = "";
String readingLongitude = "";

late int userID;
String loggedUserName = "";
String uniqueDeviceID = "";
late String loginPin;
late int billingCompanyID;
late int userDeviceInformationID;
late String jwtToken;
late String bcDateFormat;
late String bcTimeZone;
int jwtExpiryInMinute = 30;
late String url = "";

int selectedCommunityID = 0;
late int meterLocationID;
bool resumed = false;

const String dialogTitle = 'Update Available';
const String dialogMessage =
    'A new version of the app is available. Please update to the latest version to continue using the app.';
final String installNowButtonLabel = Platform.isIOS ? 'Update' : 'Install Now';
const String laterButtonLabel = 'Ignore';

DateTime get timeNow => DateTime.now();

///List of Reading Data
Map<int, ActiveCommunity> communityList = {};
Map<int, CommunityRoutes>? routeList = {};
Map<int, Meter> meterList = {};
Map<int, MyRoutes> myRoutesList = {};
Map<int, SkipReason> skipReasonsList = {};
List<WorkOrderProblem> problemsList = <WorkOrderProblem>[];
List<WorkOrder> workOrderList = <WorkOrder>[];
List<int> createdWorkOrderList = <int>[];

//List<WOTaskBinResponse> taskBinList = [];
Map<String, dynamic> row = {};

List<int> todoMeterList = <int>[];
List<int> completedMeterList = <int>[];
List<int> skippedMeterList = <int>[];
MeterListType meterListType = MeterListType.todo;
List<int> get currentMeterList => meterListType == MeterListType.todo
    ? todoMeterList
    : meterListType == MeterListType.completed
        ? completedMeterList
        : skippedMeterList;

bool idleTimeOut = false;
bool isPinLoginPage = false;
List addPostReadings = [];

bool createWorkorderPrivilege = false;
bool editMeterCommentsPrivilege = false;
bool showPreviousReadPrivilege = false;
bool meterReadPrivilege = false;
bool workOrderPrivilege = false;

int meterIndex = 0;
int meterID = 0;

int idleTimeOutMinutes = 15;

late DateTime appPausedTime;

late String meterLocationName;

///Login Flow API's
final Uri registerUri = Uri.parse("$url/api/user/registerUserDevice");
final Uri getJwtUri = Uri.parse("$url/api/user/getJWTToken");
final Uri unRegisterUri = Uri.parse("$url/api/user/unRegisterUserDevice");

///Enter Reading/Notes API's
final Uri getActiveCommunityListUrl =
    Uri.parse("$url/api/community/getActiveCommunity");

final Uri getProblemListUrl = Uri.parse(
    "$url/api/WorkOrderTemplate/GetFieldServiceWorkOrderTemplateByBillingCompanyIDAndUserID");

Uri get getWorkOrderListUrl =>
    Uri.parse("$url/api/WorkOrder/GetWorkOrdersFromMeterID/$meterID");
Uri createWorkOrderUrl(String id) => Uri.parse(
    "$url/api/WorkOrder/CreateWorkOrderForMeterIDByWorkOrderTemplateIds/$id");

Uri get getRoutesList => Uri.parse(
    "$url/api/MeterLocation/getMeterLocationInfosByCommunityID?communityID=$selectedCommunityID&readDate=${dateToBcTimeZone(timeNow)}&dateRange=0&ignoreEstimateReads=true");

Uri getMetersByRoutes(int routeId) => Uri.parse(
    "$url/api/Meter/GetBasicMetersAndReadAndResidentByCommunityAndDate?communityID=$selectedCommunityID&readDate=${dateToBcTimeZone(timeNow)}&dateRange=0&ignoreEstimateReads=true&meterLocationID=$routeId&sortOrder=1");

Uri get addMeterReadingWithNotesUrl =>
    Uri.parse("$url/api/MeterReading/addMeterReading");

Uri get getMyroutesUri => Uri.parse(
    "$url/api/meter/GetAssignedMetersByDate?readDate=${dateToBcTimeZone(timeNow)}&dateRange=0&ignoreEstimateReads=true");

Uri get getSkipReasonCodesUri =>
    Uri.parse("$url/api/SkipReasonCode/GetAllActiveSkipReasonCode");

Uri get addSkipReasonUri =>
    Uri.parse("$url/api/MeterReadSkipReason/SaveMeterReadSkipReason");

Uri get woDashboardApiFunctionUri =>
    Uri.parse("$url/api/taskbin/GetTaskBinWithWOCountByUserID/$userID");

Map<String, String> urlToLaunch(String urlToLaunch) => {"url": urlToLaunch};

String gmapsAddresslink(String address) =>
    "https://maps.google.com/?q=$address";

bool emptyTextValidation(String value) => RegExp(r"^\s*$").hasMatch(value);

// List<WorkOrderTaskbin> taskBinList = [
//   WorkOrderTaskbin(1, "Taskbin 1", 5),
//   WorkOrderTaskbin(2, "Taskbin 2", 8),
//   WorkOrderTaskbin(3, "Taskbin 3", 3),
// ];
