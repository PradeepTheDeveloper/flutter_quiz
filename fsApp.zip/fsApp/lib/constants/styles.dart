import 'package:flutter/material.dart'
    show TextStyle, FontStyle, FontWeight, Colors, TextOverflow;
import 'package:fserv/constants/color.dart';

class AppStyles {
  static const TextStyle headerStyle = TextStyle(
      fontSize: 16,
      fontStyle: FontStyle.italic,
      fontWeight: FontWeight.bold,
      color: Colors.white,
      wordSpacing: 2.4);

  static const cardTextStyle = TextStyle(
    fontSize: 30,
    fontWeight: FontWeight.bold,
    color: Colors.white,
  );

  static const signInTextStyle = TextStyle(
    fontSize: 20,
    fontWeight: FontWeight.normal,
    color: Colors.black,
  );

  static const readPageYellowTextStyle = TextStyle(
    fontSize: 18,
    fontWeight: FontWeight.w600,
    color: AppColors.yellow,
  );
  static const readPageBoldWhiteTextStyle = TextStyle(
    fontSize: 18,
    fontWeight: FontWeight.bold,
    color: AppColors.white,
  );

  static const readPageMeterTextStyle = TextStyle(
    fontSize: 16,
    fontWeight: FontWeight.w300,
    color: Colors.white54,
  );

  static const readPageEditTextStyle = TextStyle(
    fontSize: 16,
    fontWeight: FontWeight.bold,
    color: AppColors.white,
  );

  static const readPagelightWhiteTextStyle = TextStyle(
    fontSize: 22,
    fontWeight: FontWeight.w300,
    color: AppColors.white,
  );

  static const TextStyle logoSloganStyle = TextStyle(
      fontSize: 16,
      fontStyle: FontStyle.italic,
      fontWeight: FontWeight.bold,
      color: Colors.white,
      wordSpacing: 1.2);

  static const TextStyle h1Style = TextStyle(
      fontSize: 31,
      fontWeight: FontWeight.bold,
      color: AppColors.numberKeyText,
      wordSpacing: 1.0);

  static const TextStyle h2Style = TextStyle(
      fontSize: 24,
      fontStyle: FontStyle.italic,
      fontWeight: FontWeight.bold,
      color: Colors.white,
      wordSpacing: 0.8);

  static TextStyle pinTextStyle = const TextStyle(
    fontSize: 18,
    fontWeight: FontWeight.bold,
    color: AppColors.white,
  );

  static const TextStyle subHeading = TextStyle(
      color: AppColors.lightWhite,
      fontSize: 18,
      fontWeight: FontWeight.w300,
      letterSpacing: 2);

  static TextStyle loggedStyle = const TextStyle(
    fontSize: 18,
    fontWeight: FontWeight.bold,
    color: AppColors.white,
  );

  static TextStyle buttonStyle = const TextStyle(
    fontSize: 20,
    fontWeight: FontWeight.bold,
    color: AppColors.black,
  );

  static TextStyle userStyle = const TextStyle(
    fontSize: 28,
    fontWeight: FontWeight.bold,
    color: AppColors.white,
  );

  static TextStyle scanTextStyle = const TextStyle(
    fontSize: 18,
    color: AppColors.white,
    fontWeight: FontWeight.normal,
  );

  static const TextStyle footerStyle = TextStyle(
    color: Colors.white,
    fontSize: 12,
  );

  static const TextStyle sloganStyle = TextStyle(
    color: Colors.amber,
    fontSize: 16,
    fontWeight: FontWeight.bold,
  );

  static const TextStyle appBarTextStyle = TextStyle(
    color: AppColors.appBartext,
    fontSize: 30,
    fontWeight: FontWeight.w300,
  );
  static const TextStyle introStyle = TextStyle(
      color: AppColors.yellow,
      fontSize: 60,
      fontWeight: FontWeight.w300,
      letterSpacing: 4);

  static const TextStyle tabTextStyle = TextStyle(
    fontSize: 14,
    fontWeight: FontWeight.bold,
  );

  static const TextStyle dropdownTextStyle = TextStyle(
    color: AppColors.black,
    fontSize: 20,
    fontWeight: FontWeight.bold,
  );

  static const TextStyle optionsDropdownTextStyle = TextStyle(
    color: AppColors.black,
    fontSize: 16,
    fontWeight: FontWeight.bold,
  );

  static const TextStyle routeCardTitle = TextStyle(
      color: AppColors.white, fontSize: 20, fontWeight: FontWeight.normal);

  static const TextStyle routeCardStatus = TextStyle(
    color: AppColors.lightgrey,
    fontSize: 14,
    fontWeight: FontWeight.normal,
  );

  static const TextStyle boldHeading = TextStyle(
    color: AppColors.white,
    fontSize: 16,
    fontWeight: FontWeight.bold,
  );

  static const TextStyle alertBoldHeading = TextStyle(
    color: AppColors.white,
    fontSize: 20,
    fontWeight: FontWeight.bold,
  );

  static const TextStyle boldPopUpHeading = TextStyle(
    color: AppColors.black,
    fontSize: 16,
    fontWeight: FontWeight.bold,
  );

  static const TextStyle dialogText = TextStyle(
    color: AppColors.black,
    fontSize: 16,
    fontWeight: FontWeight.normal,
  );

  static const TextStyle alertDialogText = TextStyle(
    color: AppColors.white,
    fontSize: 16,
    fontWeight: FontWeight.normal,
  );

  static const TextStyle selectedProlem = TextStyle(
    color: AppColors.black,
    fontSize: 16,
    fontWeight: FontWeight.normal,
  );
  static const TextStyle unSlectedProblem = TextStyle(
    color: AppColors.white,
    fontSize: 16,
    fontWeight: FontWeight.normal,
  );

  static const TextStyle keyBoardKey = TextStyle(
      fontWeight: FontWeight.bold, fontSize: 20, color: AppColors.black);

  static const TextStyle wordSpacing = TextStyle(
      color: AppColors.lightWhite,
      fontSize: 16,
      fontWeight: FontWeight.w300,
      letterSpacing: 2);

  static const problemsTabLabel =
      TextStyle(fontSize: 16, fontWeight: FontWeight.w500);
  static const address = TextStyle(
    color: AppColors.grey,
    fontSize: 24,
    fontWeight: FontWeight.normal,
  );

  static const workOrder = TextStyle(
    color: AppColors.black,
    fontSize: 24,
    fontWeight: FontWeight.bold,
  );

  static const TextStyle workOrderTaskbinCount = TextStyle(
    color: AppColors.white,
    fontSize: 18,
    fontWeight: FontWeight.normal,
  );
  static const TextStyle workOrderTaskbinName = TextStyle(
    color: AppColors.white,
    fontSize: 16,
    fontWeight: FontWeight.normal,
  );
}

class AnimatedStyles {
  static TextStyle sloganStyle = const TextStyle(
      color: AppColors.green, fontSize: 24, fontWeight: FontWeight.bold);
}

class WorkOrderCardStyles {
  static const workId = TextStyle(
      color: AppColors.white, fontSize: 18, fontWeight: FontWeight.bold);

  static const taskCode = TextStyle(
      color: AppColors.white, fontSize: 17, fontWeight: FontWeight.w500);

  static const task = TextStyle(
      color: AppColors.white, fontSize: 14, fontWeight: FontWeight.w500);

  static const dateLable = TextStyle(
      color: AppColors.lightgrey, fontSize: 12, fontWeight: FontWeight.w500);
  static const date = TextStyle(
      color: AppColors.white, fontSize: 14, fontWeight: FontWeight.w500);
  static const priority = TextStyle(
      color: AppColors.white, fontSize: 12, fontWeight: FontWeight.bold);
}

class MeterListCardStyles {
  static const lable = TextStyle(
      color: AppColors.white, fontSize: 16, fontWeight: FontWeight.normal);

  static const meterId = TextStyle(
      color: AppColors.grey, fontSize: 16, fontWeight: FontWeight.w300);

  static const address = TextStyle(
      color: AppColors.grey,
      fontSize: 24,
      fontWeight: FontWeight.normal,
      overflow: TextOverflow.ellipsis);

  static const TextStyle text = TextStyle(
      color: AppColors.black, fontSize: 24, fontWeight: FontWeight.bold);
}

class DropDownStyles {
  static const lable = TextStyle(
      color: AppColors.black, fontSize: 12, fontWeight: FontWeight.normal);
}
