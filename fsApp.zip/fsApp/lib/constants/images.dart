class Images {
  static const String footerLogo = "assets/images/starniklogofooter.png";

  static const String starnikLogo = "assets/images/starniklogo.png";

  static const String qrScanImage = "assets/images/qrscan.png";

  static const String smrtLogo = "assets/images/smrtLogo.jpg";

  static const String arrow = "assets/images/arrow.png";
}

class CustomIcon {
  static const String meterReadingIcon = "assets/images/meterReadingIcon.png";

  static const String workorderIcon = "assets/images/workorderIcon.png";

  static const String ascending = "assets/images/ascending.png";

  static const String descending = "assets/images/descending.png";
}
