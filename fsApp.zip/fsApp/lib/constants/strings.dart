class AppStrings {
  static const String starnikUrl = "https://www.starnik.com/";

  static const String logoSloganText = "METER READING & FIELD SERVICE";

  static const String register = "Register";

  static const String readMeters = "Read Meters";

  static const String workOrders = "Work Orders";

  static const String appName = "SMRT";

  static const String defaultDate = "1111-11-11";

  static const String signin = "Sign In";

  static const String gatherReadings = "Gather Readings";

  static const String settings = "Settings";

  static const String ok = "OK";

  static const String showPin = "Show Pin";

  static const String hidePin = "Hide Pin";

  static const String showPassword = "Show Password";

  static const String hidePassword = "Hide Password";

  static const String save = "Save";

  static const String skip = "Skip";

  static const String comments = "Comments";

  static const String selectSkipReason = "Select Skip Reason";

  static const String done = "Done";

  static const String search = "Search";

  static const String searchBy = "Search By";

  static const String all = "All";

  static const String apply = "Apply";

  static const String submit = "Submit";

  static const String login = "Login";

  static const String edit = "Edit";

  static const String meterNotes = "Meter Notes";

  static const String skipNotes = "Skip Notes";

  static const String noRecordsFound = "No Records Found";

  static const String noWorkOrderTemplatesAvailable =
      "No work order templates available";

  static const String noMatchingRecordsFound = "No matching records found.";

  static String pleaseEnterVaild(String value) => "Please Enter Valid $value";

  static const String connectToFetchData = "Connect internet to fetch data";

  static const String meter = "Meter";

  static const String deleteUser = "Delete User";

  static const String meterId = "Meter ID";

  static const String loc = "Loc";

  static const String saveNext = "Save & Next";

  static const String lastRead = "Last Read: ";

  static const String lastBilledUsage = "Last Billed Usage: ";

  static const String readingLatitude = "Reading Latitude: ";

  static const String readingLongitude = "Reading Longitude: ";

  static const String advancedOptions = "Advanced Options";

  static const String showMeterInfo = "Show Meter Information";

  static const String sortBy = "Sort By";

  static const String routeOrder = "Route Order";

  static const String altRouteOrder = "Alt Route Order";

  static const String route = "Route";

  static const String forCompletedMeters = "For Completed Meters";

  static const String meterReadingWithinLast = "Meter reading within last";

  static const String days = "Days";

  static const String considerEstimated =
      "Consider estimated readings as valid readings.";

  static const String date = "Date:";

  static const String createdDate = "Created Date";

  static const String futureStartDate = "Future Start Date";

  static const String completedDate = "Completed Date";

  static const String address = "Address";

  static const String premise = "Premise";

  static const String accountName = "Account Name";

  static const String meterInformation = "Meter Information";

  static const String serialNo = "Serial #";

  static const String meterNo = "Meter #";

  static const String amrId = "AMR ID";

  static const String amrType = "AMR Type";

  static const String standardMeterSize = "Standard Meter Size";

  static const String myRoutes = "My Routes";

  static const String allRoutes = "All Routes";

  static const String community = "Community";

  static const String todo = "TO DO";

  static const String scanQRCode = "Scan QR Code";

  static const String completed = "Completed";

  static const String skipped = "Skipped";

  static const String enterReading = "Enter Reading";

  static const String problemText = "Problems";

  static const String todayWorkOrder = "Today W/O";

  static const String previousWorkOrder = "Previous W/O";

  static const String createWorkOrder = "Create W/O";

  static const String createWO = "Create Work Order";

  static const String loggedHint = "Logged in as";

  static const String setPin = "Set Pin";

  static const String createPin = "Create Pin";

  static const String enterPin = "Enter Pin";

  static const String reEnterPin = "Re-enter Pin";

  static const String submitGo = "Submit & Go";

  static const String workOrderNo = "Work Order No";

  static const String woTextData = "1234567890";

  static const String routeTextData = "Route 1";

  static const String powerText = "Powered by";

  static const String loginText = "Login";

  static const String userName = "Username";

  static const String password = "Password";

  static const String cameraPermissionString =
      "Without camera access you can't able to move forward.\n Allow access in settings";

  static const String locationPermissionString =
      "Without location access you are not able to save readings.\n Please allow location access within the settings to continue.";

  static const String openSettings = "Open Settings";

  static const String scanHintText =
      "To complete registration for your user, login to the Field Service Portal, click on the SMRT App button, and generate your unique QR Code to scan.";

  static const String english = "English";

  static const String spanish = "Spanish";

  static const String dbPrimaryId = "_id";

  static const String installUpdateMessage =
      "Do you want to install the new update?";

  static const String install = "Install";

  static const String remindMeLater = "Remind me later";

  static const databaseName = "MeterReading.db";

  static const databaseVersion = 4;

  static const String completedWorkOrder = "Completed Work Order";
}

class JwtKeys {
  static const String exp = "exp";

  static const String nbf = "nbf";

  static const String bcDateFormat = "bcDateFormat";

  static const String bcTimeZone = "bcTimeZone";

  static const String mtrReadAppGPS = "MtrReadAppGPS";

  static const String uniqueDeviceID = "uniqueDeviceID";
}

class ApiBodyStrings {
  static const String userID = "userID";

  static const String userName = "userName";

  static const String password = "password";

  static const String billingCompanyID = "billingCompanyID";

  static const String deviceID = "deviceID";

  static const String deviceName = "deviceName";

  static const String deviceModel = "deviceModel";

  static const String deviceOS = "deviceOS";

  static const String deviceOSVersion = "deviceOSVersion";

  static const String userDeviceInformationID = "userDeviceInformationID";

  static const String pushNotificationToken = "pushNotificationToken";

  static const String communityID = "communityID";

  static const String meterLocationID = "meterLocationID";

  static const String readDate = "readDate";

  static const String uniqueDeviceID = "uniqueDeviceID";
}

class ApiResponseKeyStrings {
  static const String userMessage = "userMessage";

  static const String message = "message";

  static const String errorCode = "errorCode";

  static const String url = "url";

  static const String jwtToken = "jwtToken";

  static const String privilegeids = "privilegeids";

  static const String userDeviceInformationID = "userDeviceInformationID";
}

class LogAttributes {
  static const String operatingServer = "operatingServer";
  static const String billingCompanyID = "billingCompanyID";
  static const String userDeviceInformationID = "userDeviceInformationID";
  static const String deviceID = "deviceID";
  static const String userName = "user'sName";
  static const String userId = "userId";
  static const String api = "api";
}

class SnackBarMessages {
  static const String unableToLogin = "Unable to login";

  static const String unableToDeleteTheUser = "Unable to delete the user";

  static const String unableToGetSkipReasons = "Unable to get skip reasons";

  static const String unableToSaveReading =
      "Unable to save reading to the meter";

  static const String unableToGetMeters = "Unable to get meters";

  static const String unableToGetRoutes = "Unable to get routes";

  static const String unableToGetCommunities = "Unable to get communities";

  static const String unableToGetYourAssignedMeters =
      "Unable to get your assigned meters";

  static const String unableToCreateWorkorder =
      "Unable to create work order(s) for the meter";

  static const String unableToGetWorkorders =
      "Unable to get work orders of the meter";

  static const String unableToGetProblemsList = "Unable to get problems list";

  static const String unableToSkipMeter = "Unable to skip the meter";

  static const String checkInternet = "Please check your internet connection.";

  static const String emptySkipReason = "Skip reasons are not available";

  static const String enterValidSkipNotes = "Enter valid skip notes";

  static const String meterdoesnotExist = "Meter does not exist";

  static const String skipReasonDoesNotExist = "Skip Reason does not exist";

  static String problemDoesNotExist(List<String> list) =>
      "${list.join(", ")} does not exist";

  static String problemsDoesNotExist(List<String> list) =>
      "${list.join(", ")} does not exist, Other ${SnackBarMessages.workOrdersCreatedSuccessfully}";

  static const String noMetersinThisRoute = "No meters in this route";

  static const String unableToFetchLocation =
      "Unable to fetch location data\n Please try again";

  static const String locationPermissionDenied =
      "Location permission is denied";

  static const String syncSuccess = "Data synced successfully.";

  static const String dontHaveAccessToCommunity =
      "You don't have access to this community.";

  static const String noMeterList = "No meter list in this route.";

  static const String checkInternetDataPush =
      "Please connect to internet for data sync.";

  static const String enterValidInput = "Please enter valid reading.";

  static const String pleaseSelectAProblem = "Please select a problem.";

  static const String pinsNotMatch = "Pins don't match.";

  static const String unregisteredSuccessfully = "Unregistered Successfully";

  static const String firstMeter = "First meter of this route.";

  static const String lastMeter = "Last meter of this route.";

  static const String enterValidPin = "Please enter a valid Pin.";

  static const String incorrectPin = "You have entered an incorrect pin.";

  static const String notAuthorized =
      "You are not authorized to access this app, please contact your admin.";

  static const String scanValidQR = "Please scan a valid QR.";

  static const String rescanQRFromPortal = "Re-scan the QR from Web Portal.";

  static const String unknownError = "Unknown Error.";

  static const String timeout = "Request Timed Out.";

  static const String userNotregistered = "User not registered.";

  static const String pressBackagaintoexit = "Press back again to exit!";

  static const String meterRouteNavigation =
      "Map navigation will be available soon.";

  static const String workOrderAvailableSoon =
      "Work order option will be available soon.";

  static const String sortOptionAvailableSoon =
      "Sorting option will be available soon.";

  static const String autoRead = "Auto read option will be available soon.";

  static const String youDontHavePrevilegeToCreateWorkorder =
      "You don't have access to create work order";

  static const String youDontHavePrevilegeToEditMeterNotes =
      "You don't have access to edit meter notes";

  static const String noAccessToThisCommunity = "No access to this community.";

  static const String meterSkippedSuccessfully = "Meter Skipped successfully.";

  static const String readingSavedSuccessfully = "Reading saved successfully.";

  static const String workOrdersCreatedSuccessfully =
      "Work orders created successfully.";

  static const String noPrivilegetoMeterReads =
      "User does not have privilege to access Read Meters.";
}

highUsageMessage(reading) =>
    "HIGH USAGE ALERT: The reading entered of $reading is higher than the upper limit for this meter. Please confirm this is correct before saving.";

rollOverMessage(reading) =>
    "ROLLOVER ALERT: The reading entered of $reading indicates this meter has reached its maximum value and has rolled over. Please confirm this is correct before saving.";

vacantUserMessage(reading) =>
    "VACANT USAGE ALERT: This premise is currently vacant but has a reading of $reading. Please confirm this is correct before saving.";

zeroUsageMessage(reading) =>
    "ZERO USAGE ALERT: The reading entered of $reading results in a total usage of 0 for this meter. Please confirm this is correct before saving.";

class WorkOrderProblemApiStrings {
  static const String workOrderTemplateID = "workOrderTemplateID";

  static const String workOrderTemplateName = "workOrderTemplateName";

  static const String meterID = "meterID";

  static const String status = "status";

  static const String message = "message";

  static const String createWorkOrderTable = "createWorkOrderTable";

  static const String problemListTable = "problemListTable";

  static const String id = "_id";
}

class WorkOrderApiStrings {
  static const String meterWorkOrderID = "meterWorkOrderID";

  static const String meterWorkOrderPriorityName = "meterWorkOrderPriorityName";

  static const String meterWorkOrderMaintanceTypename =
      "meterWorkOrderMaintanceTypename";

  static const String createdDate = "createdDate";

  static const String futureStartDate = "futureStartDate";

  static const String completedDate = "completedDate";

  static const String workOrderTable = "workOrderTable";

  static const String id = "_id";

  static const String fetched = "fetched";

  static const String meterId = "meterId";
}

class CommunityApiStrings {
  static const communityListTable = 'communityListTable';

  static const communityName = 'communityName';

  static const communityID = 'communityID';
}

class RouteApiStrings {
  static const String routeListTable = 'routeListTable';

  static const String communityID = 'communityID';

  static const String meterLocationName = 'meterLocationName';

  static const String meterLocationID = 'meterLocationID';

  static const String meterCount = 'meterCount';

  static const String completedMeterCount = 'completedMeterCount';

  static const String skipReasonMeterCount = 'skipReasonMeterCount';
}

class MeterApiStrings {
  static const meterListTable = 'meterListTable';

  static const communityID = 'communityID';

  static const meterReadSkipReasonID = 'meterReadSkipReasonID';

  static const meterReadSkipReasonNotes = 'meterReadSkipReasonNotes';

  static const routeId = 'routeId';

  static const meterID = 'meterID';

  static const meterName = 'meterName';

  static const serialNumber = 'serialNumber';

  static const amrid = 'amrid';

  static const meterStandardSize = 'meterStandardSize';

  static const amrType = 'meterInterfaceTypeName';

  static const apartmentName = 'apartmentName';

  static const addressLine1 = 'addressLine1';

  static const addressLine2 = 'addressLine2';

  static const addressLine3 = 'addressLine3';

  static const city = 'city';

  static const state = 'state';

  static const zip5 = 'zip5';

  static const zip4 = 'zip4';

  static const residentName = 'residentName';

  static const deviation = 'deviation';

  static const meterNotes = 'meterNotes';

  static const rolloverReading = 'rolloverReading';

  static const multiplier = 'multiplier';

  static const lastReadDate = 'lastReadDate';

  static const lastReading = 'lastReading';

  static const lastReadGPSLatitude = 'lastReadGPSLatitude';

  static const lastReadGPSLongitude = 'lastReadGPSLongitude';

  static const lastBilledUsage = 'lastBilledUsage';

  static const residentID = 'residentID';

  static const routeOrder = 'routeOrder';

  static const altRouteOrder = 'altRouteOrder';

  static const readCount = "readCount";

  static const latitude = "latitude";

  static const longitude = "longitude";
}

class ReadingStrings {
  static const readingListTable = 'reading_list';

  static const meterReadingID = 'meterReadingID';

  static const meterNotes = 'meterNotes';

  static const meterID = 'meterID';

  static const previousDate = 'previousDate';

  static const previousReading = 'previousReading';

  static const presentDate = 'presentDate';

  static const presentReading = 'presentReading';

  static const meterStatus = 'meterStatus';

  static const prevMeterStatus = 'prevMeterStatus';

  static const inputDate = 'inputDate';

  static const unitOfMeasurementID = 'unitOfMeasurementID';

  static const estimationMethod = 'estimationMethod';

  static const hasTime = 'hasTime';

  static const inputUserID = 'inputUserID';

  static const isEstimated = 'isEstimated';

  static const importBatchID = 'importBatchID';

  static const returnValue = 'returnValue';

  static const message = 'message';

  static const addressLineOne = "addressLine1";

  static const addressLineTwo = "addressLine2";

  static const addressLineThree = "addressLine3";

  static const meterSize = "meterStandardSize";

  static const estimationMethodID = "estimationMethodID";

  static const recentReadingDate = "recentReadingDate";

  static const gPSLatitude = "GPSLatitude";

  static const gPSLongitude = "GPSLongitude";
}

class SkipReasonApiStrings {
  static const skipReasonTable = 'skip_reason';

  static const skipReasonID = 'skipReasonID';

  static const skipReason = 'skipReason';

  static const description = 'description';

  static const isNotesRequired = 'isNotesRequired';

  static const isActive = 'isActive';
}

class WOTaskbinApiStrings {
  static const taskbinTable = 'taskbinTable';

  static const taskbinID = 'taskbinID';

  static const taskbinName = 'taskbinName';

  static const workOrderCount = 'workOrderCount';
}

class MeterSkipReasonApiStrings {
  static const meterSkipReasonTable = 'meter_skip_reason';

  static const meterReadSkipReasonID = 'MeterReadSkipReasonID';

  static const notes = 'Notes';

  static const status = 'status';

  static const userID = 'UserID';

  static const readDate = 'ReadDate';

  static const meterID = 'MeterID';
}

class MeterSkipReasonResponseApiStrings {
  static const returnValue = 'returnValue';

  static const meterID = 'meterID';
}

class MyRoutesApiStrings {
  static const myRoutesTable = 'myRoutesTable';

  static const meterLocationID = 'meterLocationID';

  static const meterIDs = 'meterIDs';

  static const status = 'status';

  static const skipReasonID = 'skipReasonID';

  static const String meterReadSkipReasonIDs = 'meterReadSkipReasonIDs';

  static const readingCompletedMeterIDs = 'readingCompletedMeterIDs';
}

class WoTaskbinApiStrings {
  static const taskbinName = 'taskbinName';

  static const taskbinId = 'taskbinId';

  static const workOrderCount = 'workOrderCount';
}

class RoutesTabMessages {
  static const String connectInternet = "Connect to internet to fetch data";
  static const String noCompletedRoutes =
      "No Completed routes in this Community";

  static const String noSkippedRoutes =
      "No meters are skipped in this community";

  static const String noRoutes = "No routes in this Community";
  static const String noAssignedRoutes =
      "No routes assigned to you in this community";
}

class LoaderStrings {
  static const String pleaseWait = "Please wait...";
}

class Pages {
  static const String dashboard = "Dashboard";

  static const String pinLogin = "PinLogin";

  static const String reading = "Reading";

  static const String settings = "Settings";

  static const String createWorkOrder = "CreateWorkOrder";

  static const String workOrderDashBoard = "workOrderDashBoard";

  static const String moduleSelectPage = "moduleSelectPage";

  static const String splashScreen = "SplashScreen";
}
