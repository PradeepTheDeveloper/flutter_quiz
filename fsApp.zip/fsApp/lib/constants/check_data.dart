import '../screens/inapp_update.dart';
import '/constants/app_constants.dart';
import '/functions/appfunctions.dart';
import '/route/route.dart';
import '/screens/appscreens.dart';

void getData() async {
  await getAllStorageValues();

  routeWithRemove(
      page: isRegistered
          ? pinCreated
              ? PinLoginPage.routeNamed
              : PinCreate.routeNamed
          : Login.routeNamed);
  inAppUpdate();
}
