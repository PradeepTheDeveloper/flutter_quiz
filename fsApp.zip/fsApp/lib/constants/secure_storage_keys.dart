class SecureStorageKeys {
  static const String loginPin = "loginPin";

  static const String isRegistered = "isRegistered";

  static const String userDeviceInformationID = "userDeviceInformationID";

  static const String jwtToken = "jwtToken";

  static const String problemList = "problemList";

  static const String userID = "userID";

  static const String userName = "userName";

  static const String pinCreated = "pinCreated";

  static const String isScanned = "isScanned";

  static const String billingCompanyID = "billingCompanyID";

  static const String url = "url";

  static const String workOrders = "workOrders";

  static const String lastLoginDate = "lastLogin";

  static const String lastRoute = "lastRoute";

  static const String bcDateFormat = "bcDateFormat";

  static const String bcTimeZone = "bcTimeZone";

  static const String mtrReadAppGPS = "mtrReadAppGPS";

  static const String showPreviousReadPrivilege = "showPreviousReadPrivilege";

  static const String editMeterPrivilege = "editMeterPrivilege";

  static const String createWorkorderPrivilege = "createWorkorderPrivilege";

  static const String meterReadPrivilege = "meterReadPrivilege";

  static const String workOrderPrivilege = "workOrderPrivilege";

  static const String uniqueDeviceID = "uniqueDeviceID";
}
