import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart'
    show defaultTargetPlatform, kIsWeb, TargetPlatform;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      throw UnsupportedError(
        'DefaultFirebaseOptions have not been configured for web - '
        'you can reconfigure this by running the FlutterFire CLI again.',
      );
    }
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      case TargetPlatform.iOS:
        return ios;
      case TargetPlatform.macOS:
        throw UnsupportedError(
          'DefaultFirebaseOptions have not been configured for macos - '
          'you can reconfigure this by running the FlutterFire CLI again.',
        );
      case TargetPlatform.windows:
        throw UnsupportedError(
          'DefaultFirebaseOptions have not been configured for windows - '
          'you can reconfigure this by running the FlutterFire CLI again.',
        );
      case TargetPlatform.linux:
        throw UnsupportedError(
          'DefaultFirebaseOptions have not been configured for linux - '
          'you can reconfigure this by running the FlutterFire CLI again.',
        );
      default:
        throw UnsupportedError(
          'DefaultFirebaseOptions are not supported for this platform.',
        );
    }
  }

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyD6FDF4yC2pZ2EdrhPCfckkll57lMl17tI',
    appId: '1:989022391793:android:d1e4ae33f9ed9b77350850',
    messagingSenderId: '989022391793',
    projectId: 'smrt-202a4',
    storageBucket: 'smrt-202a4.appspot.com',
  );

  static const FirebaseOptions ios = FirebaseOptions(
    apiKey: 'AIzaSyB8EXgPiffXTLQ2YS_Bm-8lIFtwVr134xc',
    appId: '1:989022391793:ios:8f19d83c6be1c6d2350850',
    messagingSenderId: '989022391793',
    projectId: 'smrt-202a4',
    storageBucket: 'smrt-202a4.appspot.com',
    iosClientId:
        '989022391793-c72sou98kcrm57on3an338imi3h38sd6.apps.googleusercontent.com',
    iosBundleId: 'com.starnik.smrt',
  );
}
