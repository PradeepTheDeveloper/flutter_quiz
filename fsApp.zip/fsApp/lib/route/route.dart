import 'package:flutter/material.dart' show Navigator;
import 'package:fserv/config/appconfigs.dart';
import 'package:fserv/constants/app_constants.dart';
import 'package:get/get.dart';

routeWithoutRemove({required dynamic page, dynamic arguments}) {
  if (!resumed && isRegistered && pinCreated) {
    CacheStorage.storeString(SecureStorageKeys.lastRoute, page);
  }

  return Get.toNamed(page, arguments: arguments);
}

routeWithRemove({required dynamic page, dynamic arguments}) {
  if (!resumed && isRegistered && pinCreated) {
    CacheStorage.storeString(SecureStorageKeys.lastRoute, page);
  }

  return Get.offNamedUntil(
    page,
    (route) => false,
    arguments: arguments,
  );
}

pop() {
  if (Navigator.canPop(currentContext)) {
    Get.back();
  }
}
