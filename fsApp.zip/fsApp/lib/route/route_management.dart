import 'package:get/get.dart';
import '../screens/gather_reads/create_work_order_page.dart';
import '../screens/gather_reads/gather_reads_dashboard.dart';
import '../screens/gather_reads/reading.dart';
import '../screens/intro.dart';
import '../screens/module_select_screen.dart';
import '../screens/pin_create_page.dart';
import '../screens/pin_login_page.dart';
import '../screens/qrscan.dart';
import '../screens/scanhint.dart';
import '../screens/settings.dart';
import '../screens/signin.dart';
import '../screens/splash.dart';
import '../screens/work_order/work_order_dashboard.dart';

Transition transition = Transition.rightToLeft;
Duration animationDuration = const Duration(milliseconds: 100);

List<GetPage<dynamic>>? getRoutes = [
  getAnimatedPage(Login.routeNamed, const Login()),
  getAnimatedPage(SplashScreen.routeNamed, const SplashScreen()),
  getAnimatedPage(QRScan.routeNamed, const QRScan()),
  getAnimatedPage(PinLoginPage.routeNamed, const PinLoginPage()),
  getAnimatedPage(ScanHint.routeNamed, const ScanHint()),
  getAnimatedPage(SignIn.routeNamed, const SignIn()),
  getAnimatedPage(CreateWorkOrder.routeNamed, const CreateWorkOrder()),
  getAnimatedPage(Dashboard.routeNamed, const Dashboard()),
  getAnimatedPage(WorkOrderDashBoard.routeNamed, const WorkOrderDashBoard()),
  getAnimatedPage(Reading.routeNamed, const Reading()),
  getAnimatedPage(PinCreate.routeNamed, const PinCreate()),
  getAnimatedPage(ModuleSelectScreen.routeNamed, const ModuleSelectScreen()),
  getAnimatedPage(
    SettingsPage.routeNamed,
    SettingsPage(Get.arguments),
  ),
];

GetPage getAnimatedPage(
  String name,
  page,
) =>
    GetPage(
      name: name,
      page: () => page,
      transition: transition,
      transitionDuration: animationDuration,
    );
