import 'package:fserv/constants/app_constants.dart';

class CommunityRoutes {
  final int meterCount;
  final int meterLocationID;
  final String meterLocationName;
  final int communityID;
  int? completedMeterCount;
  int? skipReasonMeterCount;

  CommunityRoutes({
    required this.meterCount,
    required this.meterLocationID,
    required this.meterLocationName,
    required this.communityID,
    this.completedMeterCount,
    this.skipReasonMeterCount,
  });

  factory CommunityRoutes.fromJson(Map<String, dynamic> json) =>
      CommunityRoutes(
        meterCount: json[RouteApiStrings.meterCount],
        meterLocationID: json[RouteApiStrings.meterLocationID],
        meterLocationName: json[RouteApiStrings.meterLocationName],
        communityID: json[RouteApiStrings.communityID],
        completedMeterCount: json[RouteApiStrings.completedMeterCount],
        skipReasonMeterCount: json[RouteApiStrings.skipReasonMeterCount],
      );

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data[RouteApiStrings.meterCount] = meterCount;
    data[RouteApiStrings.meterLocationID] = meterLocationID;
    data[RouteApiStrings.meterLocationName] = meterLocationName;
    data[RouteApiStrings.communityID] = communityID;
    data[RouteApiStrings.completedMeterCount] = completedMeterCount;
    data[RouteApiStrings.skipReasonMeterCount] = skipReasonMeterCount;
    return data;
  }
}
