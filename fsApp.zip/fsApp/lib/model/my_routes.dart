import 'package:fserv/constants/app_constants.dart';
import 'package:fserv/constants/strings.dart';

class MyRoutes {
  final int meterLocationID;
  final List<dynamic> meterIDs;
  final List<dynamic> readingCompletedMeterIDs;
  final List<dynamic> skippedMeterIDs;

  MyRoutes({
    required this.meterLocationID,
    required this.meterIDs,
    required this.readingCompletedMeterIDs,
    required this.skippedMeterIDs,
  });

  factory MyRoutes.fromJson(Map<String, dynamic> json) => MyRoutes(
        meterLocationID: json[MyRoutesApiStrings.meterLocationID],
        skippedMeterIDs: json[MyRoutesApiStrings.meterReadSkipReasonIDs] ?? [],
        meterIDs:
            List<int>.from(json[MyRoutesApiStrings.meterIDs].map((e) => e)),
        readingCompletedMeterIDs: List<int>.from(
            json[MyRoutesApiStrings.readingCompletedMeterIDs].map((e) => e)),
      );

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data[MyRoutesApiStrings.meterLocationID] = meterLocationID;
    data[MyRoutesApiStrings.meterIDs] = meterIDs;
    data[MyRoutesApiStrings.meterReadSkipReasonIDs] = skippedMeterIDs;
    data[MyRoutesApiStrings.readingCompletedMeterIDs] =
        readingCompletedMeterIDs;
    return data;
  }
}
