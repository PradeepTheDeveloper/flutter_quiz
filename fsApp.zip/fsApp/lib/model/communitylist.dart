import 'package:fserv/constants/app_constants.dart';
import 'package:fserv/constants/strings.dart';

class ActiveCommunity {
  late int communityID;
  late String communityName;

  ActiveCommunity({
    required communityID,
    required communityName,
  });

  ActiveCommunity.fromJson(Map<String, dynamic> json) {
    communityID = json[CommunityApiStrings.communityID];
    communityName = json[CommunityApiStrings.communityName];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data[CommunityApiStrings.communityID] = communityID;
    data[CommunityApiStrings.communityName] = communityName;
    return data;
  }
}
