class AddReadResponse {
  final int meterID;
  final String message;
  int returnValue;

  AddReadResponse(this.meterID, this.message, this.returnValue);

  factory AddReadResponse.fromJson(Map<String, dynamic> json) =>
      AddReadResponse(json['meterID'], json['message'], json['returnValue']);
}

class CreateWorkOrderResponse {
  int meterID;
  final bool isSuccess;
  final List<CreateWorkOrderResponseInfo> woResponseInfos;

  CreateWorkOrderResponse(this.meterID, this.isSuccess, this.woResponseInfos);

  factory CreateWorkOrderResponse.fromJson(Map<String, dynamic> json) {
    return CreateWorkOrderResponse(
        0,
        json['responseCode'] == 200,
        (json['woResponseInfos'] as List)
            .map<CreateWorkOrderResponseInfo>(
                (e) => CreateWorkOrderResponseInfo.fromJson(e))
            .toList());
  }
}

class CreateWorkOrderResponseInfo {
  final int workOrderTemplateID;
  int returnValue;
  final String message;

  CreateWorkOrderResponseInfo(
      this.workOrderTemplateID, this.returnValue, this.message);

  factory CreateWorkOrderResponseInfo.fromJson(Map<String, dynamic> json) =>
      CreateWorkOrderResponseInfo(
          json['workOrderTemplateID'], json['returnValue'], json['message']);
}
