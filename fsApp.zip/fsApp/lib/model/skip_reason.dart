import 'package:fserv/constants/app_constants.dart';
import 'package:fserv/functions/appfunctions.dart';

class SkipReason {
  final int skipReasonID;
  final String skipReason;
  final String description;
  final bool isActive;
  final bool isNotesRequired;

  SkipReason({
    required this.skipReasonID,
    required this.skipReason,
    required this.description,
    required this.isActive,
    required this.isNotesRequired,
  });

  factory SkipReason.fromJson(Map<String, dynamic> json) => SkipReason(
        skipReasonID: json[SkipReasonApiStrings.skipReasonID],
        skipReason: json[SkipReasonApiStrings.skipReason],
        isNotesRequired:
            json[SkipReasonApiStrings.isNotesRequired].runtimeType == String
                ? boolEncode(json[SkipReasonApiStrings.isNotesRequired])
                : json[SkipReasonApiStrings.isNotesRequired],
        description: json[SkipReasonApiStrings.description],
        isActive: json[SkipReasonApiStrings.isActive].runtimeType == String
            ? boolEncode(json[SkipReasonApiStrings.isActive])
            : json[SkipReasonApiStrings.isActive],
      );

  Map<String, dynamic> toJson() => {
        SkipReasonApiStrings.skipReasonID: skipReasonID,
        SkipReasonApiStrings.skipReason: skipReason,
        SkipReasonApiStrings.isNotesRequired: isNotesRequired.toString(),
        SkipReasonApiStrings.description: description,
        SkipReasonApiStrings.isActive: isActive.toString(),
      };
}
