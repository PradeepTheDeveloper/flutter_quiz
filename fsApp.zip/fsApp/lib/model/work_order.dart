import 'package:fserv/constants/app_constants.dart';

class WorkOrder {
  final int meterWorkOrderID;
  final String priority;
  final String task;
  final int? meterID;
  final DateTime createdDate;
  final DateTime futureStartDate;
  final DateTime completedDate;

  WorkOrder(
      {required this.meterWorkOrderID,
      required this.priority,
      required this.task,
      required this.meterID,
      required this.createdDate,
      required this.futureStartDate,
      required this.completedDate});

  factory WorkOrder.fromJson(Map<String, dynamic> json) => WorkOrder(
        meterWorkOrderID: json[WorkOrderApiStrings.meterWorkOrderID],
        priority: json[WorkOrderApiStrings.meterWorkOrderPriorityName],
        task: json[WorkOrderApiStrings.meterWorkOrderMaintanceTypename],
        createdDate: DateTime.parse(json[WorkOrderApiStrings.createdDate]),
        meterID: json[WorkOrderApiStrings.meterId],
        futureStartDate:
            DateTime.parse(json[WorkOrderApiStrings.futureStartDate]),
        completedDate: DateTime.parse(json[WorkOrderApiStrings.completedDate]),
      );

  Map<String, dynamic> toJson() => {
        WorkOrderApiStrings.meterWorkOrderID: meterWorkOrderID,
        WorkOrderApiStrings.meterWorkOrderPriorityName: priority,
        WorkOrderApiStrings.meterWorkOrderMaintanceTypename: task,
        WorkOrderApiStrings.meterId: meterID,
        WorkOrderApiStrings.createdDate: createdDate.toString(),
        WorkOrderApiStrings.futureStartDate: futureStartDate.toString(),
        WorkOrderApiStrings.completedDate: completedDate.toString(),
      };
}
