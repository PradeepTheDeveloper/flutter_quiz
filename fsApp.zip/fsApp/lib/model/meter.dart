import 'package:fserv/constants/app_constants.dart';

class Meter {
  final int meterID;
  final String? serialNo;
  final String? meterNo;
  final String? amrId;
  final String? amrType;
  final String? stdMeterSize;
  final String? apartmentName;
  final String? addressLineOne;
  final String? addressLineTwo;
  final String? addressLineThree;
  final String? zip5;
  final String? zip4;
  final String? city;
  final String? state;
  final String? residentName;
  String? meterNotes;
  final double? deviation;
  final double? rolloverReading;
  String? lastReadDate;
  double? lastReading;
  String? lastReadingLongitude;
  String? lastReadingLatitude;
  final double? lastBilledUsage;
  final String? multiplier;
  final double? routeOrder;
  final double? altRouteOrder;
  final int? residentID;
  int? readCount;
  String longitude;
  String latitude;
  int? meterReadSkipReasonID;
  String? meterReadSkipReasonNotes;

  factory Meter.fromJson(Map<String, dynamic> json) => Meter(
        meterID: json[MeterApiStrings.meterID],
        serialNo: json[MeterApiStrings.serialNumber],
        meterNo: json[MeterApiStrings.meterName],
        amrId: json[MeterApiStrings.amrid],
        amrType: json[MeterApiStrings.amrType] ?? "",
        stdMeterSize: json[MeterApiStrings.meterStandardSize] ?? "",
        apartmentName: json[MeterApiStrings.apartmentName],
        addressLineOne: json[MeterApiStrings.addressLine1],
        addressLineTwo: json[MeterApiStrings.addressLine2],
        addressLineThree: json[MeterApiStrings.addressLine3],
        zip5: json[MeterApiStrings.zip5],
        zip4: json[MeterApiStrings.zip4],
        state: json[MeterApiStrings.state],
        city: json[MeterApiStrings.city],
        residentName: json[MeterApiStrings.residentName] ?? "",
        meterNotes: json[MeterApiStrings.meterNotes] ?? "",
        deviation: json[MeterApiStrings.deviation] ?? 0,
        rolloverReading: json[MeterApiStrings.rolloverReading] ?? 0,
        lastReadDate: json[MeterApiStrings.lastReadDate] ?? "1111-11-11",
        lastReading: json[MeterApiStrings.lastReading],
        lastReadingLatitude: json[MeterApiStrings.lastReadGPSLatitude],
        lastReadingLongitude: json[MeterApiStrings.lastReadGPSLongitude],
        lastBilledUsage: json[MeterApiStrings.lastBilledUsage],
        multiplier: json[MeterApiStrings.multiplier] ?? "0.0",
        routeOrder: json[MeterApiStrings.routeOrder],
        altRouteOrder: json[MeterApiStrings.altRouteOrder],
        residentID: json[MeterApiStrings.residentID] ?? 0,
        readCount: json[MeterApiStrings.readCount] ?? 0,
        latitude: json[MeterApiStrings.latitude],
        longitude: json[MeterApiStrings.longitude],
        meterReadSkipReasonID: json[MeterApiStrings.meterReadSkipReasonID],
        meterReadSkipReasonNotes:
            json[MeterApiStrings.meterReadSkipReasonNotes],
      );

  Map<String, dynamic> toJson() => {
        MeterApiStrings.meterID: meterID,
        MeterApiStrings.serialNumber: serialNo,
        MeterApiStrings.meterName: meterNo,
        MeterApiStrings.amrid: amrId,
        MeterApiStrings.amrType: amrType,
        MeterApiStrings.meterStandardSize: stdMeterSize,
        MeterApiStrings.apartmentName: apartmentName,
        MeterApiStrings.addressLine1: addressLineOne,
        MeterApiStrings.addressLine2: addressLineTwo,
        MeterApiStrings.addressLine3: addressLineThree,
        MeterApiStrings.zip5: zip5,
        MeterApiStrings.zip4: zip4,
        MeterApiStrings.state: state,
        MeterApiStrings.city: city,
        MeterApiStrings.residentName: residentName,
        MeterApiStrings.meterNotes: meterNotes,
        MeterApiStrings.deviation: deviation,
        MeterApiStrings.rolloverReading: rolloverReading,
        MeterApiStrings.lastReadDate: lastReadDate,
        MeterApiStrings.lastReading: lastReading,
        MeterApiStrings.lastReadGPSLatitude: lastReadingLatitude,
        MeterApiStrings.lastReadGPSLongitude: lastReadingLongitude,
        MeterApiStrings.lastBilledUsage: lastBilledUsage,
        MeterApiStrings.multiplier: multiplier,
        MeterApiStrings.routeOrder: routeOrder,
        MeterApiStrings.altRouteOrder: altRouteOrder,
        MeterApiStrings.residentID: residentID,
        MeterApiStrings.readCount: readCount,
        MeterApiStrings.latitude: latitude,
        MeterApiStrings.longitude: longitude,
        MeterApiStrings.meterReadSkipReasonID: meterReadSkipReasonID,
        MeterApiStrings.meterReadSkipReasonNotes: meterReadSkipReasonNotes,
      };

  Meter({
    required this.meterID,
    required this.serialNo,
    required this.meterNo,
    required this.amrId,
    required this.amrType,
    required this.stdMeterSize,
    required this.apartmentName,
    required this.addressLineOne,
    required this.addressLineTwo,
    required this.addressLineThree,
    required this.zip5,
    required this.zip4,
    required this.state,
    required this.city,
    required this.residentName,
    required this.meterNotes,
    required this.deviation,
    required this.rolloverReading,
    required this.lastReadDate,
    required this.lastReading,
    required this.lastReadingLatitude,
    required this.lastReadingLongitude,
    required this.lastBilledUsage,
    required this.multiplier,
    required this.routeOrder,
    required this.altRouteOrder,
    required this.residentID,
    required this.readCount,
    required this.longitude,
    required this.latitude,
    required this.meterReadSkipReasonID,
    required this.meterReadSkipReasonNotes,
  });
}
