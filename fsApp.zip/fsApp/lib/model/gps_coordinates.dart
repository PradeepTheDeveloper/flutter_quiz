class GpsCoordinates {
  final String? latitude;
  final String? longitude;

  GpsCoordinates(this.latitude, this.longitude);
}
