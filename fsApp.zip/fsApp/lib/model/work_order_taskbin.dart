class TaskBinResponse {
  final String message;
  final int responseCode;
  final List<TaskBin> taskBinList;

  TaskBinResponse({
    required this.message,
    required this.responseCode,
    required this.taskBinList,
  });

  factory TaskBinResponse.fromJson(Map<String, dynamic> json) {
    return TaskBinResponse(
      message: json['message'],
      responseCode: json['responseCode'],
      taskBinList: List<TaskBin>.from(
        json['taskbinlist'].map((x) => TaskBin.fromJson(x)),
      ),
    );
  }
}

class TaskBin {
  final int taskbinID;
  final String taskbinName;
  final int workOrderCount;

  TaskBin({
    required this.taskbinID,
    required this.taskbinName,
    required this.workOrderCount,
  });

  factory TaskBin.fromJson(Map<String, dynamic> json) {
    return TaskBin(
      taskbinID: json['taskbinID'],
      taskbinName: json['taskbinName'],
      workOrderCount: json['workOrderCount'],
    );
  }

  @override
  String toString() {
    return 'TaskBin(id: $taskbinID, name: $taskbinName)';
  }
}
