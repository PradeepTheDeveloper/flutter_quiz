class Device {
  final String deviceId;
  final String deviceModel;
  final String deviceOs;
  final String deviceOsVersion;

  Device(this.deviceId, this.deviceModel, this.deviceOs, 
      this.deviceOsVersion);
}
