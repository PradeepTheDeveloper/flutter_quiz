import 'package:fserv/constants/app_constants.dart';

class AddMeterSkipReason {
  final int meterReadSkipReasonID;
  final int meterID;
  final String notes;
  final int status;
  final int userID;
  final String readDate;

  AddMeterSkipReason({
    required this.meterReadSkipReasonID,
    required this.meterID,
    required this.notes,
    required this.status,
    required this.userID,
    required this.readDate,
  });

  factory AddMeterSkipReason.fromJson(Map<String, dynamic> json) {
    return AddMeterSkipReason(
      meterReadSkipReasonID:
          json[MeterSkipReasonApiStrings.meterReadSkipReasonID],
      meterID: json[MeterSkipReasonApiStrings.meterID],
      readDate: json[MeterSkipReasonApiStrings.readDate],
      status: json[MeterSkipReasonApiStrings.status] ?? 0,
      notes: json[MeterSkipReasonApiStrings.notes],
      userID: json[MeterSkipReasonApiStrings.userID],
    );
  }

  Map<String, dynamic> toJson() => {
        MeterSkipReasonApiStrings.meterReadSkipReasonID: meterReadSkipReasonID,
        MeterSkipReasonApiStrings.meterID: meterID,
        MeterSkipReasonApiStrings.readDate: readDate,
        MeterSkipReasonApiStrings.notes: notes,
        MeterSkipReasonApiStrings.status: status,
        MeterSkipReasonApiStrings.userID: userID,
      };
}
