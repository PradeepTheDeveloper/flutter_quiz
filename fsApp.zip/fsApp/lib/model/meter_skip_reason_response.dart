import 'package:fserv/constants/app_constants.dart';

class AddMeterSkipReasonResponse {
  int returnValue;
  final int meterID;

  AddMeterSkipReasonResponse({
    required this.returnValue,
    required this.meterID,
  });

  factory AddMeterSkipReasonResponse.fromJson(Map<String, dynamic> json) =>
      AddMeterSkipReasonResponse(
        returnValue: json[MeterSkipReasonResponseApiStrings.returnValue],
        meterID: json[MeterSkipReasonResponseApiStrings.meterID],
      );

  Map<String, dynamic> toJson() => {
        MeterSkipReasonResponseApiStrings.returnValue: returnValue,
        MeterSkipReasonResponseApiStrings.meterID: meterID,
      };
}
