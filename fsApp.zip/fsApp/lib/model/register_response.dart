import '../constants/strings.dart';

class RegisterResponse {
  final int userDeviceInformationID;
  final int billingCompanyID;
  final String loggedUserName;
  final String uniqueDeviceID;

  RegisterResponse({
    required this.userDeviceInformationID,
    required this.loggedUserName,
    required this.billingCompanyID,
    required this.uniqueDeviceID,
  });
  factory RegisterResponse.fromJson(Map<String, dynamic> json) =>
      RegisterResponse(
        userDeviceInformationID: json[ApiBodyStrings.userDeviceInformationID],
        loggedUserName: json[ApiBodyStrings.userName],
        billingCompanyID: json[ApiBodyStrings.billingCompanyID],
        uniqueDeviceID: json[ApiBodyStrings.uniqueDeviceID],
      );
}
