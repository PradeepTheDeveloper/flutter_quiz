import 'package:fserv/constants/app_constants.dart';

class WorkOrderProblem {
  final int id;
  final String? name;

  WorkOrderProblem({required this.id, required this.name});

  factory WorkOrderProblem.fromJson(Map<String, dynamic> json) {
    return WorkOrderProblem(
      id: json[WorkOrderProblemApiStrings.workOrderTemplateID],
      name: json[WorkOrderProblemApiStrings.workOrderTemplateName],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      WorkOrderProblemApiStrings.workOrderTemplateID: id,
      WorkOrderProblemApiStrings.workOrderTemplateName: name,
    };
  }
}
