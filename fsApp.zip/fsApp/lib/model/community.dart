class Community {
  final int id;
  final String name;

  Community(this.id, this.name);
  factory Community.fromJson(Map<String, dynamic> json) =>
      Community(json['CommunityID'], json['CommunityName']);
}
