import 'package:fserv/constants/strings.dart';

class QRData {
  final int userId;
  final int billingCompanyId;
  final String url;

  QRData(this.userId, this.billingCompanyId, this.url);

  factory QRData.fromJson(Map<String, dynamic> json) => QRData(
        json[ApiBodyStrings.userID],
        json[ApiBodyStrings.billingCompanyID],
        json[ApiResponseKeyStrings.url],
      );
}
