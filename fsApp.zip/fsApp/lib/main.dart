import 'dart:async';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart'
    show FlutterError, FlutterErrorDetails, debugPrint, kDebugMode;
import 'package:flutter/material.dart'
    show
        FlutterError,
        FlutterErrorDetails,
        WidgetsFlutterBinding,
        debugPrint,
        runApp;
import 'package:flutter/services.dart' show SystemChrome, DeviceOrientation;
import 'package:fserv/firebase_options.dart';
import 'package:fserv/functions/appfunctions.dart';
import 'package:fserv/my_app.dart';
import 'package:firebase_crashlytics/firebase_crashlytics.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  await getAllStorageValues();

  if (kDebugMode) {
    FirebaseCrashlytics.instance.setCrashlyticsCollectionEnabled(false);
  } else {
    FirebaseCrashlytics.instance.setCrashlyticsCollectionEnabled(true);
  }

  FlutterError.onError = (FlutterErrorDetails details) async {
    debugPrint("Main F Error ---- ${details.exception.toString()}");
    try {
      FirebaseCrashlytics.instance.recordFlutterError(details);
    } on Exception catch (e) {
      debugPrint("$e");
    }
  };
  runZonedGuarded(
    () {
      SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp])
          .then(
        (_) {
          runApp(const MyApp());
        },
      );
    },
    (Object error, StackTrace stack) {
      debugPrint("Main Error ---- ${error.toString()}");

      try {
        FirebaseCrashlytics.instance.recordError(error, stack);
      } on Exception catch (e) {
        debugPrint("$e");
      }
    },
  );
}
