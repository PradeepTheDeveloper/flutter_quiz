import 'package:flutter/material.dart';

import 'package:fserv/constants/app_constants.dart';
import 'package:fserv/functions/appfunctions.dart';
import 'package:fserv/screens/appscreens.dart';
import 'package:fserv/route/route.dart';
import 'package:fserv/theme/theme.dart';
import 'package:get/get.dart';

import 'route/route_management.dart';

class MyApp extends StatefulWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> with WidgetsBindingObserver {
  @override
  void initState() {
    WidgetsBinding.instance.addObserver(this);
    super.initState();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) async {
    WidgetsBinding.instance.addObserver(this);
    if (state == AppLifecycleState.paused) {
      if (isRegistered && pinCreated && !isPinLoginPage) {
        appPausedTime = timeNow;
      }
    }
    if (state == AppLifecycleState.inactive) {
      if (isRegistered && pinCreated && !isPinLoginPage) {
        appPausedTime = timeNow;
      }
    }
    if (state == AppLifecycleState.detached) {}
    if (state == AppLifecycleState.resumed) {
      idleTimeOut =
          timeNow.difference(appPausedTime).inMinutes >= idleTimeOutMinutes;

      if (isRegistered && pinCreated) {
        resumed = true;
        if (canResume && idleTimeOut) {
          routeWithRemove(page: PinLoginPage.routeNamed);
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    currentContext = context;
    return LayoutBuilder(
      builder: (context, constrains) {
        return OrientationBuilder(
          builder: (context, orientation) {
            SizeConfig().get(constrains, orientation);
            return GetMaterialApp(
              title: AppStrings.appName,
              debugShowCheckedModeBanner: false,
              theme: AppTheme.one,
              home: const SplashScreen(),
              getPages: getRoutes,
            );
          },
        );
      },
    );
  }
}
