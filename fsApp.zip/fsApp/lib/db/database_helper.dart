import 'dart:io';
import 'package:fserv/constants/strings.dart';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path_provider/path_provider.dart';

class FSDatabaseHelper {
  FSDatabaseHelper._privateConstructor();
  static final FSDatabaseHelper instance =
      FSDatabaseHelper._privateConstructor();

  static Database? _database;
  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  _initDatabase() async {
    Directory documentsDirectory = await getApplicationDocumentsDirectory();
    String path = join(documentsDirectory.path, AppStrings.databaseName);
    return await openDatabase(
      path,
      version: AppStrings.databaseVersion,
      onCreate: _onCreate,
      onUpgrade: _onUpgrade,
    );
  }

  Future _onCreate(Database db, int version) async {
    await db.execute('''
          CREATE TABLE ${CommunityApiStrings.communityListTable} (
            ${AppStrings.dbPrimaryId} INTEGER PRIMARY KEY,
            ${CommunityApiStrings.communityName} TEXT NOT NULL,
            ${CommunityApiStrings.communityID} INTEGER NOT NULL
          )
          ''');

    await db.execute('''
          CREATE TABLE ${RouteApiStrings.routeListTable} (
            ${AppStrings.dbPrimaryId} INTEGER PRIMARY KEY,
            ${RouteApiStrings.communityID} INTEGER NOT NULL,
            ${RouteApiStrings.meterLocationName} TEXT NOT NULL,
            ${RouteApiStrings.meterLocationID} INTEGER NOT NULL,
            ${RouteApiStrings.meterCount} INTEGER NOT NULL,
            ${RouteApiStrings.completedMeterCount} INTEGER NOT NULL
          )
          ''');

    await db.execute('''
          CREATE TABLE ${MeterApiStrings.meterListTable} (
            ${AppStrings.dbPrimaryId} INTEGER PRIMARY KEY,
            ${MeterApiStrings.communityID} INTEGER NOT NULL,
            ${MeterApiStrings.routeId} INTEGER NOT NULL,
            ${MeterApiStrings.meterID} INTEGER NULL,
            ${MeterApiStrings.meterName} TEXT NULL,
            ${MeterApiStrings.serialNumber} TEXT NULL,
            ${MeterApiStrings.amrid} TEXT NULL,
            ${MeterApiStrings.meterStandardSize} TEXT NULL,
            ${MeterApiStrings.amrType} TEXT NULL,
            ${MeterApiStrings.apartmentName} TEXT NULL,
            ${MeterApiStrings.addressLine1} TEXT NULL,
            ${MeterApiStrings.addressLine2} TEXT NULL,
            ${MeterApiStrings.addressLine3} TEXT NULL,
            ${MeterApiStrings.city} TEXT NULL,
            ${MeterApiStrings.state} TEXT NULL,
            ${MeterApiStrings.zip5} TEXT NULL,
            ${MeterApiStrings.zip4} TEXT NULL,
            ${MeterApiStrings.residentName} TEXT NULL,
            ${MeterApiStrings.deviation} REAL NULL,
            ${MeterApiStrings.multiplier} TEXT NULL,
            ${MeterApiStrings.lastReadDate} TEXT NULL,
            ${MeterApiStrings.lastReading} REAL NULL,
            ${MeterApiStrings.lastBilledUsage} REAL NULL,
            ${MeterApiStrings.rolloverReading} REAL NULL,
            ${MeterApiStrings.meterNotes} TEXT NULL,
             ${MeterApiStrings.routeOrder} REAL NULL,
            ${MeterApiStrings.altRouteOrder} REAL NULL,
            ${MeterApiStrings.residentID} INTEGER NULL,
             ${MeterApiStrings.readCount} INTEGER NULL,
              ${MeterApiStrings.latitude} TEXT NULL,
             ${MeterApiStrings.longitude} TEXT NULL
          )
          ''');

    await db.execute('''
          CREATE TABLE ${ReadingStrings.readingListTable} (
            ${AppStrings.dbPrimaryId} INTEGER PRIMARY KEY,
            ${ReadingStrings.meterReadingID} INTEGER NOT NULL,
            ${ReadingStrings.meterID} INTEGER NOT NULL,
            ${ReadingStrings.previousDate} TEXT NULL,
            ${ReadingStrings.previousReading} REAL NULL,
             ${ReadingStrings.presentDate} TEXT NULL,
            ${ReadingStrings.presentReading} REAL NULL,
            ${ReadingStrings.meterStatus} INTEGER NULL,
            ${ReadingStrings.prevMeterStatus} INTEGER NULL,
             ${ReadingStrings.inputDate} TEXT NULL,
            ${ReadingStrings.unitOfMeasurementID} INTEGER NULL,
             ${ReadingStrings.estimationMethod} INTEGER NULL,
            ${ReadingStrings.hasTime} TEXT NULL,
            ${ReadingStrings.inputUserID} INTEGER NULL,
            ${ReadingStrings.isEstimated} TEXT NULL,
             ${ReadingStrings.importBatchID} INTEGER NULL,
            ${ReadingStrings.meterNotes} TEXT NULL,
             ${ReadingStrings.message} TEXT NULL
          )
          ''');

    await db.execute('''
          CREATE TABLE ${WorkOrderApiStrings.workOrderTable} (
            ${AppStrings.dbPrimaryId} INTEGER PRIMARY KEY,
            ${WorkOrderApiStrings.meterWorkOrderID} INTEGER NOT NULL,
            ${WorkOrderApiStrings.meterWorkOrderPriorityName} TEXT NOT NULL,
            ${WorkOrderApiStrings.meterWorkOrderMaintanceTypename} TEXT NOT NULL,
            ${WorkOrderApiStrings.createdDate} TEXT NOT NULL,
            ${WorkOrderApiStrings.completedDate} TEXT NOT NULL,
            ${WorkOrderApiStrings.futureStartDate} TEXT NOT NULL,
            ${WorkOrderApiStrings.meterId} INTEGER NOT NULL
          )
          ''');

    await db.execute('''
          CREATE TABLE ${WorkOrderProblemApiStrings.createWorkOrderTable} (
            ${AppStrings.dbPrimaryId} INTEGER PRIMARY KEY,
            ${WorkOrderProblemApiStrings.workOrderTemplateID} INTEGER NOT NULL,
            ${WorkOrderProblemApiStrings.meterID} INTEGER NOT NULL

          )
          ''');

    await db.execute('''
          CREATE TABLE ${MyRoutesApiStrings.myRoutesTable} (
            ${AppStrings.dbPrimaryId} INTEGER PRIMARY KEY,
            ${MyRoutesApiStrings.meterLocationID} INTEGER NOT NULL,
            ${MyRoutesApiStrings.status} INTEGER NOT NULL,
            ${MyRoutesApiStrings.meterIDs} INTEGER NOT NULL

          )
          ''');

    await db.execute('''
          ALTER TABLE ${MeterApiStrings.meterListTable}
          ADD COLUMN ${MeterApiStrings.lastReadGPSLongitude} TEXT NULL
          ''');

    await db.execute('''
          ALTER TABLE ${MeterApiStrings.meterListTable}
          ADD COLUMN ${MeterApiStrings.lastReadGPSLatitude} TEXT NULL
          ''');

    await db.execute('''
          ALTER TABLE ${ReadingStrings.readingListTable}
          ADD COLUMN ${ReadingStrings.gPSLongitude} TEXT NULL
          ''');

    await db.execute('''
          ALTER TABLE ${ReadingStrings.readingListTable}
          ADD COLUMN ${ReadingStrings.gPSLatitude} TEXT NULL
          ''');
    await db.execute('''
          CREATE TABLE IF NOT EXISTS ${MeterSkipReasonApiStrings.meterSkipReasonTable} (
            ${AppStrings.dbPrimaryId} INTEGER PRIMARY KEY,
            ${MeterSkipReasonApiStrings.meterID} INTEGER NOT NULL,
            ${MeterSkipReasonApiStrings.meterReadSkipReasonID} INTEGER NOT NULL,
            ${MeterSkipReasonApiStrings.notes} TEXT NOT NULL,
            ${MeterSkipReasonApiStrings.readDate} TEXT NOT NULL,
            ${MeterSkipReasonApiStrings.status} INTEGER NOT NULL,
            ${MeterSkipReasonApiStrings.userID} INTEGER NOT NULL
          )
          ''');

    await db.execute('''
          CREATE TABLE IF NOT EXISTS ${SkipReasonApiStrings.skipReasonTable} (
            ${AppStrings.dbPrimaryId} INTEGER PRIMARY KEY,
            ${SkipReasonApiStrings.skipReasonID} INTEGER NOT NULL,
            ${SkipReasonApiStrings.skipReason} TEXT NOT NULL,
            ${SkipReasonApiStrings.isNotesRequired} TEXT NOT NULL,
            ${SkipReasonApiStrings.isActive} TEXT NOT NULL,
            ${SkipReasonApiStrings.description} TEXT NOT NULL
          )
          ''');

    await db.execute('''
          ALTER TABLE ${MyRoutesApiStrings.myRoutesTable}
          ADD COLUMN ${MyRoutesApiStrings.skipReasonID} INTEGER NULL
          ''');

    await db.execute('''
          ALTER TABLE ${MeterApiStrings.meterListTable}
          ADD COLUMN ${MeterApiStrings.meterReadSkipReasonID} INTEGER NULL
          ''');

    await db.execute('''
          ALTER TABLE ${MeterApiStrings.meterListTable}
          ADD COLUMN ${MeterApiStrings.meterReadSkipReasonNotes} TEXT NULL
          ''');

    await db.execute('''
          ALTER TABLE ${RouteApiStrings.routeListTable}
          ADD COLUMN ${RouteApiStrings.skipReasonMeterCount} INTEGER NULL
          ''');
    await db.execute('''
          ALTER TABLE ${WorkOrderProblemApiStrings.createWorkOrderTable}
          ADD COLUMN ${WorkOrderProblemApiStrings.message} TEXT NULL
          ''');
    await db.execute('''
          ALTER TABLE ${WorkOrderProblemApiStrings.createWorkOrderTable}
          ADD COLUMN ${WorkOrderProblemApiStrings.status} INTEGER NULL
          ''');

    await db.execute('''
          CREATE TABLE IF NOT EXISTS ${WorkOrderProblemApiStrings.problemListTable} (
            ${AppStrings.dbPrimaryId} INTEGER PRIMARY KEY,
            ${WorkOrderProblemApiStrings.workOrderTemplateID} INTEGER NOT NULL,
            ${WorkOrderProblemApiStrings.workOrderTemplateName} TEXT NOT NULL
          )
          ''');
  }

  Future _onUpgrade(Database db, int version, int newVersion) async {
    if (newVersion > 1) {
      List<Map<String, dynamic>> _columns = await db
          .rawQuery("PRAGMA table_info(${MeterApiStrings.meterListTable});");
      if (!(_columns.any((element) =>
          element["name"] == MeterApiStrings.lastReadGPSLongitude))) {
        await db.execute('''
          ALTER TABLE ${MeterApiStrings.meterListTable}
          ADD COLUMN ${MeterApiStrings.lastReadGPSLongitude} TEXT NULL
          ''');

        await db.execute('''
          ALTER TABLE ${MeterApiStrings.meterListTable}
          ADD COLUMN ${MeterApiStrings.lastReadGPSLatitude} TEXT NULL
          ''');

        await db.execute('''
        ALTER TABLE ${ReadingStrings.readingListTable}
          ADD COLUMN ${ReadingStrings.gPSLongitude} TEXT NULL
          ''');

        await db.execute('''
          ALTER TABLE ${ReadingStrings.readingListTable}
          ADD COLUMN ${ReadingStrings.gPSLatitude} TEXT NULL
          ''');
      }
    }
    if (newVersion > 2) {
      await db.execute('''
          CREATE TABLE IF NOT EXISTS ${MeterSkipReasonApiStrings.meterSkipReasonTable} (
            ${AppStrings.dbPrimaryId} INTEGER PRIMARY KEY,
            ${MeterSkipReasonApiStrings.meterID} INTEGER NOT NULL,
            ${MeterSkipReasonApiStrings.meterReadSkipReasonID} INTEGER NOT NULL,
            ${MeterSkipReasonApiStrings.notes} TEXT NOT NULL,
            ${MeterSkipReasonApiStrings.readDate} TEXT NOT NULL,
            ${MeterSkipReasonApiStrings.status} INTEGER NOT NULL,
            ${MeterSkipReasonApiStrings.userID} INTEGER NOT NULL
          )
          ''');

      await db.execute('''
          CREATE TABLE IF NOT EXISTS ${SkipReasonApiStrings.skipReasonTable} (
            ${AppStrings.dbPrimaryId} INTEGER PRIMARY KEY,
            ${SkipReasonApiStrings.skipReasonID} INTEGER NOT NULL,
            ${SkipReasonApiStrings.skipReason} TEXT NOT NULL,
            ${SkipReasonApiStrings.isNotesRequired} TEXT NOT NULL,
            ${SkipReasonApiStrings.isActive} TEXT NOT NULL,
            ${SkipReasonApiStrings.description} TEXT NOT NULL
          )
          ''');
      List<Map<String, dynamic>> _columns = await db
          .rawQuery("PRAGMA table_info(${MyRoutesApiStrings.myRoutesTable});");
      if (!(_columns.any(
          (element) => element["name"] == MyRoutesApiStrings.skipReasonID))) {
        await db.execute('''
          ALTER TABLE ${MyRoutesApiStrings.myRoutesTable}
          ADD COLUMN ${MyRoutesApiStrings.skipReasonID} INTEGER NULL
          ''');

        await db.execute('''
          ALTER TABLE ${MeterApiStrings.meterListTable}
          ADD COLUMN ${MeterApiStrings.meterReadSkipReasonID} INTEGER NULL
          ''');
        await db.execute('''
          ALTER TABLE ${MeterApiStrings.meterListTable}
          ADD COLUMN ${MeterApiStrings.meterReadSkipReasonNotes} TEXT NULL
          ''');

        await db.execute('''
          ALTER TABLE ${RouteApiStrings.routeListTable}
          ADD COLUMN ${RouteApiStrings.skipReasonMeterCount} INTEGER NULL
          ''');
      }
    }
    if (newVersion > 3) {
      List<Map<String, dynamic>> _columns = await db.rawQuery(
          "PRAGMA table_info(${WorkOrderProblemApiStrings.createWorkOrderTable});");
      if (!(_columns.any(
          (element) => element["name"] == WorkOrderProblemApiStrings.status))) {
        await db.execute('''
          ALTER TABLE ${WorkOrderProblemApiStrings.createWorkOrderTable}
          ADD COLUMN ${WorkOrderProblemApiStrings.message} TEXT NULL
          ''');
        await db.execute('''
          ALTER TABLE ${WorkOrderProblemApiStrings.createWorkOrderTable}
          ADD COLUMN ${WorkOrderProblemApiStrings.status} INTEGER NULL
          ''');

        await db.execute('''
          CREATE TABLE IF NOT EXISTS ${WorkOrderProblemApiStrings.problemListTable} (
            ${AppStrings.dbPrimaryId} INTEGER PRIMARY KEY,
            ${WorkOrderProblemApiStrings.workOrderTemplateID} INTEGER NOT NULL,
            ${WorkOrderProblemApiStrings.workOrderTemplateName} TEXT NOT NULL
          )
          ''');
      }
    }
  }

  ///Insert
  Future<int> insert(Map<String, dynamic> row, table) async {
    Database db = await instance.database;
    return await db.insert(table, row,
        conflictAlgorithm: ConflictAlgorithm.ignore);
  }

  Future<void> insertWorkOrder(Map<String, dynamic> row) async {
    Database db = await instance.database;
    String _table = WorkOrderProblemApiStrings.createWorkOrderTable;
    List<String> _columns = row.keys.toList();
    Set<dynamic> _values = row.values.toSet();
    await db.rawQuery(
        "INSERT OR REPLACE INTO $_table ${_columns.map((e) => e)} VALUES ${_values.map((e) => e)}");
  }

  ///Insert
  Future<int> insertReadings(Map<String, dynamic> row, table) async {
    Database db = await instance.database;
    return await db.insert(table, row);
  }

  ///Query
  Future<List<Map<String, dynamic>>> query(table) async {
    Database db = await instance.database;
    return await db.query(table);
  }

  Future<List<Map<String, dynamic>>> queryDistinctMeterLocationID(
      table, field) async {
    Database db = await instance.database;
    return await db.query(table, whereArgs: [field]);
  }

  ///Query by Community ID
  Future<List<Map<String, dynamic>>> queryById(table, id, field) async {
    Database db = await instance.database;
    return await db.query(table, where: '$field = ?', whereArgs: [id]);
  }

  ///Update by Id
  Future<int> update(
      table, Map<String, dynamic> row, String field, int id) async {
    Database db = await instance.database;
    return await db.update(table, row, where: '$field = ?', whereArgs: [id]);
  }

  Future<int> updateWithTwoParams(
    table,
    Map<String, dynamic> row,
    String firstField,
    int firstValue,
    String secondField,
    int secondValue,
  ) async {
    Database db = await instance.database;
    return await db.update(table, row,
        where: '$firstField = ? AND $secondField = ?',
        whereArgs: [firstValue, secondValue]);
  }

  ///delete
  Future<int> delete(int idd, columnName, table) async {
    Database db = await instance.database;
    return await db.delete(table, where: '$columnName = ?', whereArgs: [idd]);
  }

  ///delete with two params
  Future<int> deleteWithTwoParams(
      paramOne, paramTwo, columnNameOne, columnNameTwo, table) async {
    Database db = await instance.database;
    return await db.delete(table,
        where: '$columnNameOne = ? and $columnNameTwo = ?',
        whereArgs: [paramOne, paramTwo]);
  }

  ///delete DB
  Future<int> deleteDB(table) async {
    Database db = await instance.database;

    return await db.delete(table);
  }
}
