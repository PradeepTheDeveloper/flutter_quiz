import 'package:fserv/constants/app_constants.dart';
import 'package:fserv/model/gps_coordinates.dart';
import 'package:fserv/widgets/app_widgets.dart';
import 'package:location/location.dart';

Future<GpsCoordinates?> getGpsCoordinates() async {
  Location location = Location.instance;
  PermissionStatus permission;
  late LocationData _position;
  showLoader(LoaderStrings.pleaseWait);

  bool _serviceEnabled = await location.serviceEnabled();
  permission = await location.hasPermission();
  if (permission == PermissionStatus.denied) {
    permission = await location.requestPermission();
    if (permission == PermissionStatus.denied) {
      snackBar(SnackBarMessages.locationPermissionDenied);
    }
  }

  if (permission == PermissionStatus.deniedForever) {
    await showPermissionDenied(currentContext, false);
  }
  if (permission == PermissionStatus.granted ||
      permission == PermissionStatus.grantedLimited) {
    if (!_serviceEnabled) {
      _serviceEnabled = await location.requestService();
    }
    if (_serviceEnabled) {
      _position = await location.getLocation().timeout(
        const Duration(seconds: 20),
        onTimeout: () {
          return LocationData.fromMap({});
        },
      ).onError(
        (error, stackTrace) {
          return LocationData.fromMap({});
        },
      ).then((value) => value);

      return GpsCoordinates(_position.latitude?.toStringAsFixed(6),
          _position.longitude?.toStringAsFixed(6));
    }
  }
  return null;
}
