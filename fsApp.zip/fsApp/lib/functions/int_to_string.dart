String intToString(int? value) {
  return value == null ? "" : value.toString();
}

int stringToInt(String? value) {
  int intValue = int.parse(value.toString());
  return intValue;
}

String nullString(String? value) {
  return value ?? " ";
}

String doubleToString(double? value) {
  return value == null ? " " : value.toString();
}
