import 'package:fserv/constants/app_constants.dart';
import 'package:fserv/functions/api_functions/get_all_list.dart';
import 'package:fserv/functions/appfunctions.dart';
import 'package:fserv/route/route.dart';
import 'package:fserv/widgets/app_widgets.dart';

Future<bool> checkCommunityAccess(int communityID) async {
  if (await hasNetwork()) {
    showLoader(LoaderStrings.pleaseWait);

    await getActiveCommunity(
        loader: true, disableInternetSnack: true, sync: true);
    pop();
    if (communityList.containsKey(communityID)) {
      return true;
    } else {
      selectedCommunityID = communityList.keys.first;

      getAllListInCommunity(hasAccess: false);
      return false;
    }
  } else {
    snackBar(SnackBarMessages.checkInternet);
    return true;
  }
}
