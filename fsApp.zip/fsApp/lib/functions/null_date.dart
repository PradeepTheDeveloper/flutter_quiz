import 'package:fserv/functions/date_format.dart';

String nullDate(DateTime dateTime) {
  return dateFormatToBC(dateTime) == "01/01/1" ? "-" : dateFormatToBC(dateTime);
}
