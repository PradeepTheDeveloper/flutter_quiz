import '/config/appconfigs.dart';
import '/constants/app_constants.dart' show Pages, SecureStorageKeys, resumed;
import '/screens/appscreens.dart'
    show
        CreateWorkOrder,
        Dashboard,
        ModuleSelectScreen,
        Reading,
        WorkOrderDashBoard;

Future<dynamic> checkPausedState() async {
  dynamic _page;
  String lastPage = await CacheStorage.readString(SecureStorageKeys.lastRoute);
  if (lastPage == Pages.reading) {
    _page = const Reading();
  } else if (lastPage == Pages.createWorkOrder) {
    _page = const CreateWorkOrder();
  } else if (lastPage == Pages.workOrderDashBoard) {
    _page = const WorkOrderDashBoard();
  } else if (lastPage == Pages.moduleSelectPage) {
    _page = const ModuleSelectScreen();
  } else if (lastPage == Pages.dashboard) {
    _page = const Dashboard();
  }

  resumed = false;
  return _page;
}
