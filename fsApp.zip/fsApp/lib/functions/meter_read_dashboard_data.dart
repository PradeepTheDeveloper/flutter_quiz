import 'package:fserv/widgets/app_widgets.dart';

import '../constants/app_constants.dart';
import '../route/route.dart';
import 'api_functions/get_all_list.dart';
import 'appfunctions.dart';

Future<void> getMeterReadDashBoardData(dynamic page) async {
  await getToken(initialGet: true).then((value) async {
    if (meterReadPrivilege) {
      if (value.statusCode == 502) {
        List _community =
            await dbHelper.query(CommunityApiStrings.communityListTable);

        if (_community.isNotEmpty) {
          await getAllListInCommunity(hasAccess: true);

          await getProblemsList(disableInternetSnack: true);
          routeWithRemove(page: page);
        }
      } else if (value.statusCode == 200) {
        await getAllListInCommunity(hasAccess: true);

        routeWithRemove(page: page);
      } else if (value.statusCode != 401) {
        pop();
      }
    } else {
      pop();
      snackBar(SnackBarMessages.noPrivilegetoMeterReads);
    }
  });
}
