import 'package:fserv/config/prefs.dart';
import '../constants/app_constants.dart';

class Privileges {
  static const int showPreviousRead = 377;
  static const int editMeterComments = 368;
  static const int createWorkorder = 358;
  static const int meterRead = 274;
  static const int workOrder = 267;

  static Future<void> savePrivileges(List<int> privileges) async {
    if (showPreviousReadPrivilege != privileges.contains(showPreviousRead)) {
      showPreviousReadPrivilege = privileges.contains(showPreviousRead);
      CacheStorage.storeBool(SecureStorageKeys.showPreviousReadPrivilege,
          showPreviousReadPrivilege);
    }
    if (editMeterCommentsPrivilege != privileges.contains(editMeterComments)) {
      editMeterCommentsPrivilege = privileges.contains(editMeterComments);
      CacheStorage.storeBool(
          SecureStorageKeys.editMeterPrivilege, editMeterCommentsPrivilege);
    }
    if (createWorkorderPrivilege != privileges.contains(createWorkorder)) {
      createWorkorderPrivilege = privileges.contains(createWorkorder);
      CacheStorage.storeBool(
          SecureStorageKeys.createWorkorderPrivilege, createWorkorderPrivilege);
    }
    if (meterReadPrivilege != privileges.contains(meterRead)) {
      meterReadPrivilege = privileges.contains(meterRead);
      CacheStorage.storeBool(
          SecureStorageKeys.meterReadPrivilege, meterReadPrivilege);
    }
    if (workOrderPrivilege != privileges.contains(workOrder)) {
      workOrderPrivilege = privileges.contains(workOrder);
      CacheStorage.storeBool(
          SecureStorageKeys.workOrderPrivilege, workOrderPrivilege);
    }
  }
}
