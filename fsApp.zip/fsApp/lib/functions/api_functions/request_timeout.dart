// ignore_for_file: unused_catch_clause
import 'dart:convert';
import 'package:firebase_performance/firebase_performance.dart';
import 'package:flutter/foundation.dart';
import 'package:fserv/functions/privileges.dart';
import '/config/new_relic.dart';
import '/constants/app_constants.dart'
    show ApiResponseKeyStrings, LogAttributes, SnackBarMessages;
import '/constants/variables.dart';
import '/functions/appfunctions.dart';
import '/route/route.dart';
import '/widgets/app_widgets.dart';
import 'package:http/http.dart' as http show Response, post, get;

Future<http.Response> postRequest(
  Uri uri, {
  required Map<String, String> headers,
  required dynamic body,
  bool loader = true,
  bool disableNoInternetSnackBar = false,
  required Future<void> Function() success,
  Future<void> Function()? unAuthorised,
  Future<void> Function()? timeOut,
  required Future<void> Function() noInternet,
  Future<void> Function()? unknown,
  required void Function(dynamic) json,
}) async {
  int startTime = 0;
  late final HttpMetric _metric;
  if (kReleaseMode) {
    startTime = timeNow.microsecondsSinceEpoch;
    _metric = FirebasePerformance.instance
        .newHttpMetric(uri.toString(), HttpMethod.Post);

    _metric.start();
  }
  getToken();
  debugPrint("Url ----- $uri");
  debugPrint("Req Body ----- $body");
  debugPrint("Header ----- $headers");

  http.Response _response;
  try {
    _response = await http.post(uri, headers: headers, body: body).timeout(
        requestTimeout,
        onTimeout: () => http.Response(
            jsonEncode({"message": SnackBarMessages.timeout}), 408));

    debugPrint("Res-----${_response.body}");
  } on Exception catch (e) {
    FlutterError.reportError(FlutterErrorDetails(exception: e));

    _response = http.Response(
        jsonEncode({"message": SnackBarMessages.unknownError}), 502);
  }
  try {
    if (kReleaseMode) {
      int endTime = timeNow.microsecondsSinceEpoch;
      _metric.requestPayloadSize = body.toString().length;
      _metric.putAttribute(LogAttributes.operatingServer, uri.host);
      _metric.putAttribute(LogAttributes.userId, userID.toString());
      _metric.putAttribute(LogAttributes.api, uri.pathSegments.last);
      _metric.httpResponseCode = _response.statusCode;
      _metric.requestPayloadSize = _response.contentLength;
      _metric.stop();
      NewRelic.noticeHttpTransaction(
        url: uri.toString(),
        httpMethod: "Post",
        startTime: startTime,
        endTime: endTime,
        statusCode: _response.statusCode,
        bytesSent: body.length,
        bytesReceived: _response.body.length,
      );
    }
    dynamic _json = jsonDecode(_response.body);
    debugPrint("Body-----$_json");
    if (_response.statusCode == 200) {
      json.call(_json);
      setPrivileges(_response);

      await success();
    } else if (_response.statusCode == 401) {
      if (loader) pop();
      json.call(_json);

      if (_json[ApiResponseKeyStrings.userMessage] != null ||
          _json[ApiResponseKeyStrings.message] != null) {
        snackBar(_json[ApiResponseKeyStrings.userMessage] ??
            _json[ApiResponseKeyStrings.message]);
      }

      if (unAuthorised != null) await unAuthorised();
    } else if (_response.statusCode == 408) {
      if (loader) pop();
      snackBar(SnackBarMessages.timeout);
      if (timeOut != null) await timeOut();
    } else if (_response.statusCode == 502) {
      if (loader) pop();
      if (!disableNoInternetSnackBar) {
        snackBar(SnackBarMessages.checkInternet);
      }
      await noInternet();
    } else {
      if (loader) pop();
      if (unknown != null) await unknown();
    }
  } on Exception catch (e) {
    debugPrint("Error-----${e.toString()}");
    FlutterError.reportError(FlutterErrorDetails(exception: e));

    _response = http.Response("", 505);

    if (unknown != null) await unknown();
  }
  return _response;
}

Future<http.Response> getRequest(
  Uri uri, {
  required Map<String, String> headers,
  bool loader = true,
  bool disableNoInternetSnackBar = false,
  required Future<void> Function() success,
  Future<void> Function()? unAuthorised,
  Future<void> Function()? timeOut,
  required Future<void> Function() noInternet,
  Future<void> Function()? unknown,
  required void Function(dynamic) json,
}) async {
  int startTime = 0;
  late final HttpMetric _metric;
  if (kReleaseMode) {
    startTime = timeNow.microsecondsSinceEpoch;
    _metric = FirebasePerformance.instance
        .newHttpMetric(uri.toString(), HttpMethod.Get);
    _metric.start();
  }

  getToken();
  debugPrint("Url ----- $uri");
  debugPrint("Header ----- $headers");

  http.Response? _response;

  try {
    _response = await http.get(uri, headers: headers).timeout(requestTimeout,
        onTimeout: () => http.Response(
            jsonEncode({"message": SnackBarMessages.timeout}), 408));

    debugPrint("Res-----${_response.body}");
  } catch (e) {
    FlutterError.reportError(FlutterErrorDetails(exception: e));

    _response = http.Response(
        jsonEncode({"message": SnackBarMessages.unknownError}), 502);
  }
  try {
    if (kReleaseMode) {
      int endTime = timeNow.microsecondsSinceEpoch;

      _metric.putAttribute(LogAttributes.operatingServer, uri.host);
      _metric.putAttribute(LogAttributes.userId, userID.toString());
      _metric.putAttribute(LogAttributes.api, uri.pathSegments.last);
      _metric.httpResponseCode = _response.statusCode;
      _metric.responsePayloadSize = _response.contentLength;

      _metric.stop();
      NewRelic.noticeHttpTransaction(
        url: uri.toString(),
        httpMethod: "get",
        startTime: startTime,
        endTime: endTime,
        statusCode: _response.statusCode,
        bytesSent: 0,
        bytesReceived: _response.body.hashCode,
      );
    }
    dynamic _json = jsonDecode(_response.body);
    debugPrint("Body------$_json");

    if (_response.statusCode == 200) {
      json.call(_json);
      setPrivileges(_response);
      debugPrint('taskBinList1 sucess ${_response.statusCode}');
      await success();
    } else if (_response.statusCode == 401) {
      if (loader) pop();
      json.call(_json);
      if (_json[ApiResponseKeyStrings.userMessage] != null ||
          _json[ApiResponseKeyStrings.message] != null) {
        snackBar(_json[ApiResponseKeyStrings.userMessage] ??
            _json[ApiResponseKeyStrings.message]);
      }

      if (unAuthorised != null) await unAuthorised();
    } else if (_response.statusCode == 408) {
      if (loader) pop();
      snackBar(SnackBarMessages.timeout);
      if (timeOut != null) await timeOut();
    } else if (_response.statusCode == 502) {
      if (loader) pop();
      if (!disableNoInternetSnackBar) {
        snackBar(SnackBarMessages.checkInternet);
      }
      await noInternet();
    } else {
      if (loader) pop();
      if (unknown != null) await unknown();
    }
  } catch (e) {
    debugPrint("Error-----${e.toString()}");
    FlutterError.reportError(FlutterErrorDetails(exception: e));
    _response = http.Response("", 505);
    if (unknown != null) await unknown();
  }
  return _response;
}

void setPrivileges(http.Response response) {
  Map<String, String> _headers = response.headers;
  if (_headers.containsKey(ApiResponseKeyStrings.privilegeids)) {
    debugPrint(_headers[ApiResponseKeyStrings.privilegeids]);
    List<int> _privilegeids = _headers[ApiResponseKeyStrings.privilegeids]
        .toString()
        .split(",")
        .map((e) => int.parse(e))
        .toList();

    Privileges.savePrivileges(_privilegeids);
  }
}
