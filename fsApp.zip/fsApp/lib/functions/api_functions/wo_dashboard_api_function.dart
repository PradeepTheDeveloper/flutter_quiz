import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:fserv/config/appconfigs.dart' show AppHttpHeaders;
import 'package:fserv/functions/appfunctions.dart' show getRequest;
import 'package:fserv/constants/app_constants.dart';

import '../../model/work_order_taskbin.dart';
import '../../widgets/snackbar.dart';

Future<void> woDashboardAPIFunction({
  bool sync = false,
  bool disableInternetSnack = false,
}) async {
  debugPrint("--------woTaskbinApiFunction--------");

  dynamic _json;

  getRequest(
    woDashboardApiFunctionUri,
    disableNoInternetSnackBar: disableInternetSnack,
    headers: AppHttpHeaders.withAuthorization,
    json: (v) => _json = v,
    unknown: () async {
      snackBar(SnackBarMessages.unableToGetYourAssignedMeters);
    },
    success: () async {
      try {
        // Map<String, dynamic> json = jsonDecode(_json);
        TaskBinResponse response = TaskBinResponse.fromJson(_json);

        // Accessing the values

        // List<TaskBin> taskBinList = [];
        taskBinList.addAll(response.taskBinList);
      } catch (e) {
        // TODO: Handle the exception
      }
    },
    noInternet: () async {
      // readMyRoutesFromDB();
      snackBar(SnackBarMessages.checkInternet);
    },
  );
}
