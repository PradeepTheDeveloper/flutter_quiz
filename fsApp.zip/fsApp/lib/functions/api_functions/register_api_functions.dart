import 'package:flutter/material.dart';
import '/config/appconfigs.dart' show AppHttpHeaders, AppHttpBody, CacheStorage;
import '/functions/appfunctions.dart'
    show deleteUserData, parseJwtPayLoad, postRequest;
import '/constants/app_constants.dart';
import '/functions/bool_decode.dart';
import '/model/register_response.dart';
import '/route/route.dart';
import '/screens/appscreens.dart';
import '/widgets/app_widgets.dart';
import 'package:http/http.dart' as http;

Future<void> registerNewUser(String userName, String password) async {
  dynamic _json;
  debugPrint("--------registerNewUser--------");
  await postRequest(
    registerUri,
    headers: AppHttpHeaders.contentTypeJson,
    body: AppHttpBody.registerBody(
      userName,
      password,
    ),
    json: (v) => _json = v,
    unknown: () async {
      pop();
      snackBar(SnackBarMessages.unableToLogin);
    },
    unAuthorised: () async {
      pop();
    },
    success: () async {
      RegisterResponse response = RegisterResponse.fromJson(_json);
      userDeviceInformationID = response.userDeviceInformationID;
      snackBar(_json[ApiResponseKeyStrings.userMessage]);
      await CacheStorage.storeInt(
          SecureStorageKeys.userDeviceInformationID, userDeviceInformationID);

      billingCompanyID = response.billingCompanyID;
      CacheStorage.storeInt(
          SecureStorageKeys.billingCompanyID, billingCompanyID);

      loggedUserName = response.loggedUserName;
      CacheStorage.storeString(SecureStorageKeys.userName, loggedUserName);

      uniqueDeviceID = response.uniqueDeviceID;
      CacheStorage.storeString(
          SecureStorageKeys.uniqueDeviceID, uniqueDeviceID);

      isRegistered = true;
      await CacheStorage.storeBool(
          SecureStorageKeys.isRegistered, isRegistered);

      routeWithRemove(page: PinCreate.routeNamed);
    },
    timeOut: () async {
      pop();
    },
    noInternet: () async {
      pop();
    },
  );
}

Future<void> unregisterUser() async {
  debugPrint("--------unregisterUser--------");
  showLoader(LoaderStrings.pleaseWait);
  await postRequest(unRegisterUri,
      headers: AppHttpHeaders.withAuthorization,
      body: AppHttpBody.unregisterBody(),
      json: (v) {},
      unknown: () async {
        snackBar(SnackBarMessages.unableToDeleteTheUser);
      },
      success: () async {
        await deleteUserData();
      },
      noInternet: () async {},
      unAuthorised: () async {
        await deleteUserData();
      });
}

Future<http.Response> getToken({bool initialGet = false}) async {
  dynamic _json;
  http.Response _res;
  debugPrint("--------getToken--------");
  if (timeNow.difference(jwtTokenTimer).inMinutes >= jwtExpiryInMinute - 5 ||
      initialGet) {
    jwtTokenTimer = timeNow;

    _res = await postRequest(
      getJwtUri,
      headers: AppHttpHeaders.contentTypeJson,
      body: AppHttpBody.getJWTBody(),
      json: (v) => _json = v,
      success: () async {
        jwtToken = _json[ApiResponseKeyStrings.jwtToken]!;
        Map<String, dynamic> _decodedToken = parseJwtPayLoad(jwtToken);
        bcDateFormat = _decodedToken[JwtKeys.bcDateFormat].toLowerCase();
        bcTimeZone = _decodedToken[JwtKeys.bcTimeZone];
        mtrReadAppGPS = boolEncode(_decodedToken[JwtKeys.mtrReadAppGPS]);
        if (uniqueDeviceID.isEmpty) {
          uniqueDeviceID = _decodedToken[JwtKeys.uniqueDeviceID].toString();
          await CacheStorage.storeString(
              SecureStorageKeys.uniqueDeviceID, uniqueDeviceID);
        }

        jwtExpiryInMinute =
            ((_decodedToken[JwtKeys.exp] - _decodedToken[JwtKeys.nbf]) / 60)
                .round();
        await CacheStorage.storeString(SecureStorageKeys.jwtToken, jwtToken);
        await CacheStorage.storeBool(
            SecureStorageKeys.mtrReadAppGPS, mtrReadAppGPS);
        await CacheStorage.storeString(
            SecureStorageKeys.bcTimeZone, bcTimeZone);
        await CacheStorage.storeString(
            SecureStorageKeys.bcDateFormat, bcDateFormat);
      },

      
      unAuthorised: () async {
        if (_json[ApiResponseKeyStrings.errorCode] == "ERP005") {
          await deleteUserData();
        }
      },
      noInternet: () async {},
    );
  } else {
    _res = http.Response("", 200);
  }
  return _res;
}
