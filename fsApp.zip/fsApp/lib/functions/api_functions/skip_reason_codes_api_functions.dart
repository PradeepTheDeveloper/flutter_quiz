import 'package:flutter/material.dart';
import 'package:fserv/functions/api_functions/reading_api_functions.dart';
import 'package:fserv/config/appconfigs.dart' show AppHttpHeaders;
import 'package:fserv/functions/appfunctions.dart' show getRequest;
import 'package:fserv/constants/app_constants.dart';
import 'package:fserv/model/skip_reason.dart';

import '../../widgets/snackbar.dart';

Future<void> getSkipReasons({
  bool sync = false,
  bool disableInternetSnack = false,
}) async {
  debugPrint("--------getSkipReasons--------");
  dynamic _json;
  List<Map<String, dynamic>> _skipCodes =
      await dbHelper.query(SkipReasonApiStrings.skipReasonTable);

  if (_skipCodes.isEmpty || sync) {
    await getRequest(
      getSkipReasonCodesUri,
      disableNoInternetSnackBar: disableInternetSnack,
      headers: AppHttpHeaders.withAuthorization,
      json: (v) => _json = v,
      unknown: () async {
        snackBar(SnackBarMessages.unableToGetSkipReasons);
      },
      success: () async {
        if (sync) {
          dbHelper.deleteDB(SkipReasonApiStrings.skipReasonTable);
        }
        List<dynamic> _jsonData = List.from(_json.map((e) => e));

        skipReasonsList = Map.fromIterables(
            _jsonData.map((e) => e[SkipReasonApiStrings.skipReasonID]),
            _jsonData.map((e) => SkipReason.fromJson(e)));

        debugPrint('skipReasonList $skipReasonsList');
        await saveSkipReasonsToDB();
      },
      noInternet: () async {
        readSkipReasonsFromDB();
      },
    );
  } else {
    readSkipReasonsFromDB();
  }
}

Future<void> saveSkipReasonsToDB() async {
  for (var value in skipReasonsList.values) {
    await dbHelper.insert(value.toJson(), SkipReasonApiStrings.skipReasonTable);
  }
}

Future<void> readSkipReasonsFromDB() async {
  List<Map<String, dynamic>> _skipCodes =
      await dbHelper.query(SkipReasonApiStrings.skipReasonTable);

  skipReasonsList.addEntries(
    _skipCodes.map(
      (e) {
        return MapEntry(
            e[SkipReasonApiStrings.skipReasonID], SkipReason.fromJson(e));
      },
    ),
  );
}
