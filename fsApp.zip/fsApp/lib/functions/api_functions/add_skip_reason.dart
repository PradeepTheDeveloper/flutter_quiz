import 'dart:convert' show jsonEncode;
import 'package:flutter/cupertino.dart';
import 'package:fserv/config/appconfigs.dart' show AppHttpHeaders;
import 'package:fserv/constants/app_constants.dart';
import 'package:fserv/functions/appfunctions.dart' show dbHelper, postRequest;
import 'package:fserv/functions/save_api_res_decode.dart';
import 'package:fserv/model/meter_skip_reason_response.dart';
import 'package:fserv/widgets/app_widgets.dart' show snackBar;

Future<bool> addSkipReason({
  bool sync = false,
  bool returnIfSuccess = false,
}) async {
  dynamic _json;
  List<Map<String, dynamic>> _reads = await getUnsyncedSkipReason();
  debugPrint("--------addSkipReason--------");
  SaveApiResponse? _apires;
  if (_reads.isNotEmpty) {
    await postRequest(
      addSkipReasonUri,
      headers: AppHttpHeaders.withAuthorization,
      body: jsonEncode(_reads),
      json: (v) => _json = v,
      loader: false,
      disableNoInternetSnackBar: true,
      unknown: () async {
        _apires = SaveApiResponse.unexpectedError;
        snackBar(SnackBarMessages.unableToSkipMeter);
      },
      success: () async {
        if (sync) snackBar(SnackBarMessages.syncSuccess);
        List<AddMeterSkipReasonResponse> addSkip =
            List.from(_json.map((e) => AddMeterSkipReasonResponse.fromJson(e)));
        if (addSkip.isNotEmpty) {
          addSkip.forEach((e) async {
            if (e.returnValue <= -3 || e.returnValue == 0) {
              e.returnValue = -3;
            }
            Map<String, dynamic> row = {
              MeterSkipReasonApiStrings.status: e.returnValue,
            };
            _apires = saveApiresDecode(e.returnValue);

            if (e.meterID == meterID && !sync) {
              if (_apires == SaveApiResponse.meterNotFound) {
                snackBar(SnackBarMessages.meterdoesnotExist);
              } else if (_apires == SaveApiResponse.paramaterError) {
                snackBar(SnackBarMessages.skipReasonDoesNotExist);
              } else if (_apires == SaveApiResponse.success) {
                snackBar(SnackBarMessages.meterSkippedSuccessfully);
              } else {
                snackBar(SnackBarMessages.unableToSkipMeter);
              }
            }
            await dbHelper.update(
                MeterSkipReasonApiStrings.meterSkipReasonTable,
                row,
                MeterSkipReasonApiStrings.meterID,
                e.meterID);
          });
        } else {
          _apires = SaveApiResponse.success;
        }
      },
      noInternet: () async {
        _apires = SaveApiResponse.noInternet;
        !sync
            ? snackBar(SnackBarMessages.checkInternet)
            : snackBar(SnackBarMessages.checkInternetDataPush);
      },
    );
  } else {
    _apires = SaveApiResponse.success;
  }
  if ((returnIfSuccess && _apires == SaveApiResponse.success) ||
      (!returnIfSuccess && _apires != SaveApiResponse.paramaterError)) {
    return true;
  } else {
    return false;
  }
}

Future<List<Map<String, dynamic>>> getUnsyncedSkipReason() async {
  return await dbHelper.queryById(
    MeterSkipReasonApiStrings.meterSkipReasonTable,
    0,
    MeterSkipReasonApiStrings.status,
  );
}
