import 'package:fserv/constants/app_constants.dart';
import 'package:fserv/functions/api_functions/myroutes_api_funstions.dart';
import 'package:fserv/functions/api_functions/reading_api_functions.dart';
import 'package:fserv/functions/api_functions/skip_reason_codes_api_functions.dart';
import 'package:fserv/route/route.dart';
import 'package:fserv/screens/appscreens.dart';
import 'package:fserv/widgets/app_widgets.dart';

Future<void> getAllListInCommunity(
    {bool sync = false, required bool hasAccess}) async {
  showLoader(LoaderStrings.pleaseWait);
  bool done = true;
  int no = 0;
  int total = 0;
  canResume = false;
  await getActiveCommunity(
          loader: false, disableInternetSnack: true, sync: sync)
      .then((value) async {
    if (communityList.isNotEmpty && value.statusCode == 200) {
      await getRoute(
              communityID: selectedCommunityID,
              loader: false,
              sync: sync,
              disableInternetSnack: true)
          .then((value) async {
        pop();
        await getMyRoutes(sync: sync, disableInternetSnack: true);
        await getSkipReasons(sync: sync, disableInternetSnack: true);
        if (routeList != null) {
          if (routeList!.isNotEmpty) {
            pop();
            total = routeList!.length;
            for (var i = 0; i < routeList!.length; i++) {
              int element = routeList!.keys.toList()[i];
              no = i;
              showLoader(
                  "${LoaderStrings.pleaseWait}\nGetting meters from route $no/$total");

              await getMeter(
                routeId: element,
                disableInternetSnack: true,
                sync: sync,
                communityId: selectedCommunityID,
                loader: false,
              ).then((value) async {
                if (value.statusCode == 200) {
                  pop();
                  i;
                  done = true;
                } else if (value.statusCode == 502) {
                  no = total - i;
                  await dbHelper.delete(
                      element,
                      RouteApiStrings.meterLocationID,
                      RouteApiStrings.routeListTable);
                  routeList?.removeWhere((key, value) => key == element);
                  done = false;
                } else {
                  pop();
                  i;
                  done = true;
                }
              });
            }
          }
        }
      });
      if (!done) {
        snackBar(
            "$no/$total Routes are not loaded due to poor internet connection.\nDo sync with proper internet to get all routes",
            duration: 3);
      }
    }
    canResume = true;
    routeWithRemove(page: Dashboard.routeNamed);
    if (!hasAccess) {
      snackBar(SnackBarMessages.noAccessToThisCommunity);
    }
  });
}
