import 'package:flutter/cupertino.dart';
import 'package:fserv/functions/api_functions/reading_api_functions.dart';
import 'package:fserv/config/appconfigs.dart' show AppHttpHeaders;
import 'package:fserv/functions/appfunctions.dart' show getRequest;
import 'package:fserv/constants/app_constants.dart';
import 'package:fserv/model/my_routes.dart';

import '../../widgets/snackbar.dart';

Future<void> getMyRoutes({
  bool sync = false,
  bool disableInternetSnack = false,
}) async {
  debugPrint("--------getMyRoutes--------");

  dynamic _json;
  List<Map<String, dynamic>> myRoutes =
      await dbHelper.query(MyRoutesApiStrings.myRoutesTable);
  if (myRoutes.isEmpty || sync) {
    await getRequest(
      getMyroutesUri,
      disableNoInternetSnackBar: disableInternetSnack,
      headers: AppHttpHeaders.withAuthorization,
      json: (v) => _json = v,
      unknown: () async {
        snackBar(SnackBarMessages.unableToGetYourAssignedMeters);
      },
      success: () async {
        if (sync) {
          dbHelper.deleteDB(MyRoutesApiStrings.myRoutesTable);
        }
        List<dynamic> _jsonData = List.from(_json.map((e) => e));

        myRoutesList = Map.fromIterables(
            _jsonData.map((e) => e[MyRoutesApiStrings.meterLocationID]),
            _jsonData.map((e) => MyRoutes.fromJson(e)));
        await saveMyRoutesToDB();
      },
      noInternet: () async {
        readMyRoutesFromDB();
      },
    );
  } else {
    readMyRoutesFromDB();
  }
}

Future<void> saveMyRoutesToDB() async {
  for (var values in myRoutesList.values) {
    values.meterIDs.forEach((meterIDs) async {
      Map<String, dynamic> row = {
        MyRoutesApiStrings.meterLocationID: values.meterLocationID,
        MyRoutesApiStrings.meterIDs: meterIDs,
        MyRoutesApiStrings.status:
            values.readingCompletedMeterIDs.contains(meterIDs) ? 1 : 0,
        MyRoutesApiStrings.skipReasonID:
            values.skippedMeterIDs.contains(meterIDs) ? 1 : 0,
      };
      await dbHelper.insert(row, MyRoutesApiStrings.myRoutesTable);
    });
  }
}

Future<void> readMyRoutesFromDB() async {
  List<Map<String, dynamic>> _myRoutes =
      await dbHelper.query(MyRoutesApiStrings.myRoutesTable);
  List _meterLocationId =
      _myRoutes.map((e) => e[MyRoutesApiStrings.meterLocationID]).toList();
  _meterLocationId.forEach((element) {
    List _meterIds = _myRoutes
        .where((e) => e[MyRoutesApiStrings.meterLocationID] == element)
        .map((e) => e[MyRoutesApiStrings.meterIDs])
        .toList();

    List _readingCompletedMeterIDs = _myRoutes
        .where((e) =>
            e[MyRoutesApiStrings.meterLocationID] == element &&
            e[MyRoutesApiStrings.status] == 1)
        .map((e) => e[MyRoutesApiStrings.meterIDs])
        .toList();
    List _skippedMeterIDs = _myRoutes
        .where((e) =>
            e[MyRoutesApiStrings.meterLocationID] == element &&
            (e[MyRoutesApiStrings.skipReasonID] == 1 &&
                e[MyRoutesApiStrings.status] != 1))
        .map((e) => e[MyRoutesApiStrings.meterIDs])
        .toList();
    myRoutesList.addEntries([
      MapEntry(
        element,
        MyRoutes(
          meterLocationID: element,
          meterIDs: _meterIds,
          readingCompletedMeterIDs: _readingCompletedMeterIDs,
          skippedMeterIDs: _skippedMeterIDs,
        ),
      )
    ]);
  });
}

Future<void> updateMyRoutesToDB(row) async {
  await dbHelper.update(MyRoutesApiStrings.myRoutesTable, row,
      MyRoutesApiStrings.meterIDs, meterID);
}
