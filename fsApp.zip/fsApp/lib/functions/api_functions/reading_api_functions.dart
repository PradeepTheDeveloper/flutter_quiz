import 'dart:convert' show jsonEncode;
import 'package:flutter/material.dart';
import 'package:fserv/config/appconfigs.dart' show AppHttpHeaders;
import 'package:fserv/constants/app_constants.dart';
import 'package:fserv/db/database_helper.dart';
import 'package:fserv/functions/appfunctions.dart'
    show dateTimeToBcTimeZone, getRequest, postRequest;
import 'package:fserv/model/appmodels.dart';
import 'package:http/http.dart' as http;
import 'package:fserv/widgets/app_widgets.dart' show showLoader, snackBar;
import '../save_api_res_decode.dart';

final dbHelper = FSDatabaseHelper.instance;
Future<http.Response> getActiveCommunity({
  bool sync = false,
  bool loader = true,
  bool disableInternetSnack = false,
}) async {
  debugPrint("--------getActiveCommunity--------");
  dynamic _json;
  http.Response _res;

  List<Map<String, dynamic>> community =
      await dbHelper.query(CommunityApiStrings.communityListTable);
  if (community.isEmpty || sync) {
    _res = await getRequest(
      getActiveCommunityListUrl,
      disableNoInternetSnackBar: disableInternetSnack,
      loader: loader,
      headers: AppHttpHeaders.withAuthorization,
      json: (v) => _json = v,
      unknown: () async {
        snackBar(SnackBarMessages.unableToGetCommunities);
      },
      success: () async {
        if (sync) {
          dbHelper.deleteDB(CommunityApiStrings.communityListTable);
        }
        List<ActiveCommunity> jsonData =
            List.from(_json.map((e) => ActiveCommunity.fromJson(e)));
        for (var e in jsonData) {
          Map<String, dynamic> row = {
            CommunityApiStrings.communityName: e.communityName,
            CommunityApiStrings.communityID: e.communityID,
          };

          await dbHelper.insert(row, CommunityApiStrings.communityListTable);
        }
        await dbHelper
            .query(CommunityApiStrings.communityListTable)
            .then((value) {
          communityList = Map<int, ActiveCommunity>.fromIterables(
              value.map((e) => e[CommunityApiStrings.communityID]),
              value.map((e) => ActiveCommunity.fromJson(e)));
          if (selectedCommunityID == 0 ||
              !communityList.keys.contains(selectedCommunityID)) {
            selectedCommunityID = communityList.keys.first;
          }
        });
      },
      noInternet: () async {
        if (sync) {
          communityList = Map<int, ActiveCommunity>.fromIterables(
              community.map((e) => e[CommunityApiStrings.communityID]),
              community.map((e) => ActiveCommunity.fromJson(e)));
          if (selectedCommunityID == 0 ||
              !communityList.keys.contains(selectedCommunityID)) {
            selectedCommunityID = communityList.keys.first;
          }
        }
      },
    );
  } else {
    showLoader(LoaderStrings.pleaseWait);

    communityList = Map<int, ActiveCommunity>.fromIterables(
        community.map((e) => e[CommunityApiStrings.communityID]),
        community.map((e) => ActiveCommunity.fromJson(e)));
    if (selectedCommunityID == 0 ||
        !communityList.keys.contains(selectedCommunityID)) {
      selectedCommunityID = communityList.keys.first;
    }
    _res = http.Response("", 200);
  }
  return _res;
}

Future<void> getRoute({
  required int communityID,
  bool sync = false,
  bool loader = true,
  bool disableInternetSnack = false,
}) async {
  debugPrint("--------getRoute--------");
  dynamic _json;

  List<Map<String, dynamic>> _routes = await dbHelper.queryById(
      RouteApiStrings.routeListTable, communityID, RouteApiStrings.communityID);
  if (_routes.isEmpty || sync) {
    await getRequest(
      getRoutesList,
      loader: loader,
      headers: AppHttpHeaders.withAuthorization,
      json: (v) => _json = v,
      disableNoInternetSnackBar: disableInternetSnack,
      unknown: () async {
        snackBar(SnackBarMessages.unableToGetRoutes);
      },
      success: () async {
        if (sync) {
          dbHelper.deleteDB(RouteApiStrings.routeListTable);
        }
        List _temp = _json.map((e) => e).toList();
        routeList = Map.fromIterables(
            _temp.map((e) => e[RouteApiStrings.meterLocationID]),
            _temp.map((e) => CommunityRoutes.fromJson(e)));
        if (routeList!.isNotEmpty) {
          routeList?.forEach((key, e) async {
            await dbHelper.insert(e.toJson(), RouteApiStrings.routeListTable);
          });
          if (!sync || !routeList!.keys.contains(meterLocationID)) {
            meterLocationID = routeList!.keys.first;
          }
        }
      },
      noInternet: () async {
        routeList = null;
        if (sync) {
          routeList = Map.fromIterables(
              _routes.map((e) => e[RouteApiStrings.meterLocationID]),
              _routes.map((e) => CommunityRoutes.fromJson(e)));
          if (!sync || !routeList!.keys.contains(meterLocationID)) {
            meterLocationID = routeList!.keys.first;
          }
        }
      },
    );
  } else {
    routeList = Map.fromIterables(
        _routes.map((e) => e[RouteApiStrings.meterLocationID]),
        _routes.map((e) => CommunityRoutes.fromJson(e)));

    if (!sync || !routeList!.keys.contains(meterLocationID)) {
      meterLocationID = routeList!.keys.first;
    }
  }
}

Future<http.Response> getMeter({
  required int routeId,
  bool loader = true,
  required int communityId,
  bool disableInternetSnack = false,
  bool sync = false,
}) async {
  debugPrint("--------getMeter---------");
  dynamic _json;
  http.Response _res;

  List<Map<String, dynamic>> _meters = await dbHelper.queryById(
      MeterApiStrings.meterListTable, routeId, MeterApiStrings.routeId);
  if (_meters.isEmpty || sync) {
    _res = await getRequest(getMetersByRoutes(routeId),
        headers: AppHttpHeaders.withAuthorization,
        json: (v) => _json = v,
        loader: loader,
        disableNoInternetSnackBar: disableInternetSnack,
        unknown: () async {
          snackBar(SnackBarMessages.unableToGetMeters);
        },
        success: () async {
          if (sync) {
            await dbHelper.delete(routeId, MeterApiStrings.routeId,
                MeterApiStrings.meterListTable);
          }
          List _temp = _json.map((e) => e).toList();
          meterList = Map.fromIterables(
              _temp.map((e) => e[MeterApiStrings.meterID]),
              _temp.map((e) => Meter.fromJson(e)));

          if (meterList.isNotEmpty) {
            meterList.forEach((key, e) async {
              Map<String, dynamic> row = {
                MeterApiStrings.communityID: communityId,
                MeterApiStrings.routeId: routeId,
              };
              row.addAll(e.toJson());
              dbHelper.insert(row, MeterApiStrings.meterListTable);
            });

            sortList();

            updateList();

            if (!sync || !meterList.keys.contains(meterID)) {
              if (todoMeterList.isNotEmpty) {
                meterID = todoMeterList.first;
                meterIndex = 0;
              } else if (completedMeterList.isNotEmpty) {
                meterID = completedMeterList.first;
                meterIndex = 0;
              }
            }
          }
        },
        noInternet: () async {});
  } else {
    meterList = Map.fromIterables(
        _meters.map((e) => e[MeterApiStrings.meterID]),
        _meters.map((e) => Meter.fromJson(e)));

    sortList();

    updateList();

    if (todoMeterList.isNotEmpty) {
      meterID = todoMeterList.first;
      meterIndex = 0;
    } else if (completedMeterList.isNotEmpty) {
      meterID = completedMeterList.first;
      meterIndex = 0;
    } else if (skippedMeterList.isNotEmpty) {
      meterID = skippedMeterList.first;
      meterIndex = 0;
    }
    _res = http.Response("", 200);
  }
  return _res;
}

Future<bool> addMeterReading({
  bool sync = false,
  bool returnIfSuccess = false,
}) async {
  dynamic _json;
  List<Map<String, dynamic>> _reads = await getUnsyncedReadings();
  debugPrint("--------addMeterReading--------");
  SaveApiResponse? _apires;

  if (_reads.isNotEmpty) {
    await postRequest(
      addMeterReadingWithNotesUrl,
      headers: AppHttpHeaders.withAuthorization,
      body: jsonEncode(_reads),
      json: (v) => _json = v,
      loader: false,
      disableNoInternetSnackBar: true,
      unknown: () async {
        _apires = SaveApiResponse.unexpectedError;
        snackBar(SnackBarMessages.unableToSaveReading);
      },
      success: () async {
        if (sync) snackBar(SnackBarMessages.syncSuccess);

        List<AddReadResponse> addReadings =
            List.from(_json.map((e) => AddReadResponse.fromJson(e)));
        if (addReadings.isNotEmpty) {
          // ignore: avoid_function_literals_in_foreach_calls
          addReadings.forEach((e) async {
            if (e.returnValue <= -3 || e.returnValue == 0) {
              e.returnValue = -3;
            }
            _apires = saveApiresDecode(e.returnValue);
            if (e.meterID == meterID && !sync) {
              if (_apires == SaveApiResponse.meterNotFound) {
                snackBar(SnackBarMessages.meterdoesnotExist);
              } else if (_apires == SaveApiResponse.paramaterError) {
                snackBar(SnackBarMessages.enterValidInput);
              } else if (_apires == SaveApiResponse.success) {
                snackBar(SnackBarMessages.readingSavedSuccessfully);
              } else {
                snackBar(SnackBarMessages.unableToSaveReading);
              }
            }
            Map<String, dynamic> row = {
              ReadingStrings.message: e.message,
              ReadingStrings.meterReadingID: e.returnValue,
            };
            await dbHelper.update(ReadingStrings.readingListTable, row,
                ReadingStrings.meterID, e.meterID);
          });
        } else {
          _apires = SaveApiResponse.success;
        }
      },
      noInternet: () async {
        _apires = SaveApiResponse.noInternet;

        !(sync)
            ? snackBar(SnackBarMessages.checkInternet)
            : snackBar(SnackBarMessages.checkInternetDataPush);
      },
    );
  } else {
    _apires = SaveApiResponse.success;
  }
  if ((returnIfSuccess && _apires == SaveApiResponse.success) ||
      (!returnIfSuccess && _apires != SaveApiResponse.paramaterError)) {
    return true;
  } else {
    return false;
  }
}

void updateList() {
  if (meterList.isNotEmpty) {
    if (allRoutesGlobal) {
      completedMeterList = meterList.values
          .where((element) => element.readCount! > 0)
          .map((e) => e.meterID)
          .toList();

      todoMeterList = meterList.values
          .where((e) {
            return e.readCount! <= 0 && e.meterReadSkipReasonID! <= 0;
          })
          .map((e) => e.meterID)
          .toList();

      skippedMeterList = meterList.values
          .where((e) {
            return e.meterReadSkipReasonID! > 0 && e.readCount! <= 0;
          })
          .map((e) => e.meterID)
          .toList();
    } else {
      if (myRoutesList.isNotEmpty &&
          myRoutesList.keys.contains(meterLocationID)) {
        completedMeterList = meterList.keys
            .where((element) => myRoutesList[meterLocationID]!
                .readingCompletedMeterIDs
                .contains(element))
            .map((e) => e)
            .toList();

        skippedMeterList = meterList.keys
            .where((element) =>
                myRoutesList[meterLocationID]!
                    .skippedMeterIDs
                    .contains(element) &&
                !myRoutesList[meterLocationID]!
                    .readingCompletedMeterIDs
                    .contains(element))
            .map((e) => e)
            .toList();

        todoMeterList = meterList.keys
            .where((element) =>
                myRoutesList[meterLocationID]!.meterIDs.contains(element) &&
                !myRoutesList[meterLocationID]!
                    .skippedMeterIDs
                    .contains(element))
            .where((element) =>
                !completedMeterList.contains(element) &&
                !skippedMeterList.contains(element))
            .map((e) => e)
            .toList();
      }
    }
    debugPrint(meterListType.toString());
    debugPrint("todo--- $todoMeterList");
    debugPrint("completed--- $completedMeterList");
    debugPrint("skipped--- $skippedMeterList");
    debugPrint(
        "Alt Route - ${skippedMeterList.map((e) => meterList[e]?.altRouteOrder)}");
    debugPrint(
        "Route - ${skippedMeterList.map((e) => meterList[e]?.routeOrder)}");
  }
  if ((meterListType == MeterListType.completed &&
          completedMeterList.isEmpty) ||
      (meterListType == MeterListType.skipped && skippedMeterList.isEmpty)) {
    meterListType = MeterListType.todo;
  }
}

void sortList() {
  Map<int, Meter> _list = meterList;
  Iterable<MapEntry<int, Meter>> _sL;
  if (routeOrder) {
    _sL = _list.entries.toList()
      ..sort((first, next) {
        MapEntry<int, Meter> a;
        MapEntry<int, Meter> b;
        if (ascendingOrder) {
          a = first;
          b = next;
        } else {
          a = next;
          b = first;
        }
        int result = a.value.routeOrder!.compareTo(b.value.routeOrder!);
        if (result == 0) {
          result = a.value.meterID.compareTo(b.value.meterID);
        }
        return result;
      });
  } else {
    _sL = _list.entries.toList()
      ..sort((first, next) {
        MapEntry<int, Meter> a;
        MapEntry<int, Meter> b;
        if (ascendingOrder) {
          a = first;
          b = next;
        } else {
          a = next;
          b = first;
        }
        int result = a.value.altRouteOrder!.compareTo(b.value.altRouteOrder!);
        if (result == 0) {
          result = a.value.meterID.compareTo(b.value.meterID);
        }
        return result;
      });
  }
  meterList
    ..clear()
    ..addEntries(_sL);
}

Future<void> updateLocalList({String? notes, int? skipReasonId}) async {
  List<Map<String, dynamic>> readings = skipReasonId == 0
      ? await getUnsyncedReadings()
      : await getUnsyncedSkipReason();
  String _meterIdString = skipReasonId == 0
      ? MeterApiStrings.meterID
      : MeterSkipReasonApiStrings.meterID;
  readings.forEach((e) async {
    if (meterList.keys.any((element) => element == e[_meterIdString])) {
      meterList.update(e[_meterIdString], (value) {
        if (skipReasonId == 0) {
          return value
            ..meterNotes = notes ?? value.meterNotes
            ..lastReadDate = dateTimeToBcTimeZone(timeNow).toString()
            ..lastReading = e[ReadingStrings.presentReading]
            ..lastReadingLatitude = e[ReadingStrings.gPSLatitude]
            ..lastReadingLongitude = e[ReadingStrings.gPSLongitude]
            ..readCount = meterList[e[_meterIdString]]!.readCount! + 1;
        } else {
          return value..meterReadSkipReasonID = skipReasonId;
        }
      });

      await dbHelper.update(
          MeterApiStrings.meterListTable,
          meterList[e[_meterIdString]]!.toJson(),
          MeterApiStrings.meterID,
          e[_meterIdString]);
    }
  });

  updateList();

  int _completedMeterount = meterList.isEmpty
      ? 0
      : meterList.values.where((e) => e.readCount! > 0).toList().length;
  int _skippedMeterount = meterList.isEmpty
      ? 0
      : meterList.values
          .where((e) => e.meterReadSkipReasonID! > 0 && e.readCount! <= 0)
          .toList()
          .length;

  routeList?.update(meterLocationID, (value) {
    return value
      ..completedMeterCount = _completedMeterount
      ..skipReasonMeterCount = _skippedMeterount;
  });

  await dbHelper.update(
      RouteApiStrings.routeListTable,
      routeList![meterLocationID]!.toJson(),
      RouteApiStrings.meterLocationID,
      meterLocationID);
}

Future<List<Map<String, dynamic>>> getUnsyncedReadings() async {
  return await dbHelper.queryById(
      ReadingStrings.readingListTable, 0, ReadingStrings.meterReadingID);
}

Future<List<Map<String, dynamic>>> getUnsyncedSkipReason() async {
  return await dbHelper.queryById(
    MeterSkipReasonApiStrings.meterSkipReasonTable,
    0,
    MeterSkipReasonApiStrings.status,
  );
}
