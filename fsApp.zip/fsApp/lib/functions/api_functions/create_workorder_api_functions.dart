import 'dart:convert' show jsonEncode;
import 'package:flutter/material.dart';
import '/config/appconfigs.dart' show AppHttpHeaders;
import '/functions/api_functions/reading_api_functions.dart';
import '/functions/appfunctions.dart' show getRequest, postRequest;
import '/constants/app_constants.dart';
import '/model/appmodels.dart' show WorkOrderProblem, WorkOrder;
import '/route/route.dart';
import '/widgets/app_widgets.dart' show snackBar;
import '../../screens/gather_reads/create_work_order_page.dart';
import '../../model/addreadingresponse.dart';
import '../save_api_res_decode.dart';

Future<void> getProblemsList({
  bool disableInternetSnack = false,
  bool sync = false,
}) async {
  debugPrint("--------getProblemsList--------");

  dynamic _json = [];
  List<Map<String, dynamic>> _problem =
      await dbHelper.query(WorkOrderProblemApiStrings.problemListTable);
  if (_problem.isEmpty || sync) {
    await getRequest(
      getProblemListUrl,
      headers: AppHttpHeaders.withAuthorization,
      loader: false,
      disableNoInternetSnackBar: disableInternetSnack,
      json: (v) => _json = v,
      unknown: () async {
        snackBar(SnackBarMessages.unableToGetProblemsList);
      },
      success: () async {
        if (sync) {
          dbHelper.deleteDB(WorkOrderProblemApiStrings.problemListTable);
        }
        problemsList =
            List.from(_json.map((e) => WorkOrderProblem.fromJson(e)));
        for (var e in problemsList) {
          await dbHelper.insert(
              e.toJson(), WorkOrderProblemApiStrings.problemListTable);
        }
      },
      noInternet: () async {
        problemsList =
            _problem.map((e) => WorkOrderProblem.fromJson(e)).toList();
      },
    );
  } else {
    problemsList = _problem.map((e) => WorkOrderProblem.fromJson(e)).toList();
  }
}

Future<void> getWorkOrderList({
  bool disableLoader = false,
  bool sync = false,
  bool disableInternetSnack = false,
}) async {
  debugPrint("--------getWorkOrderList--------");
  dynamic _json = [];

  List<Map<String, dynamic>> workorders = await dbHelper.queryById(
    WorkOrderApiStrings.workOrderTable,
    meterID,
    WorkOrderApiStrings.meterId,
  );
  if (workorders.isEmpty || sync) {
    await getRequest(getWorkOrderListUrl,
        headers: AppHttpHeaders.withAuthorization,
        loader: !disableLoader,
        disableNoInternetSnackBar: disableInternetSnack,
        json: (v) => _json = v,
        unknown: () async {
          snackBar(SnackBarMessages.unableToGetWorkorders);
        },
        success: () async {
          if (sync) {
            dbHelper.delete(meterID, MeterApiStrings.meterID,
                WorkOrderApiStrings.workOrderTable);
          }
          if (_json.isNotEmpty) {
            workOrderList = List<WorkOrder>.from(_json.map((e) {
              Map<String, dynamic> _jsonW = Map<String, dynamic>.from(e);
              _jsonW.addEntries([
                MapEntry(WorkOrderApiStrings.meterId, meterID),
              ]);
              return WorkOrder.fromJson(_jsonW);
            }));

            for (var element in workOrderList) {
              dbHelper.insert(
                  element.toJson(), WorkOrderApiStrings.workOrderTable);
            }
          } else {
            workOrderList = [];
          }
        },
        noInternet: () async {
          workOrderList = List<WorkOrder>.from(
              workorders.map((e) => WorkOrder.fromJson(e)));

          if (problemsList.isNotEmpty && !sync) {
            routeWithRemove(page: CreateWorkOrder.routeNamed);
          }
        });
  } else {
    workOrderList =
        List<WorkOrder>.from(workorders.map((e) => WorkOrder.fromJson(e)));
  }
}

Future<bool> createWorkOrder({
  bool sync = false,
  bool returnIfSuccess = false,
}) async {
  dynamic _json;
  debugPrint("--------createWorkOrder--------");
  List<Map<String, dynamic>> _orders = await getUnsyncedWorkOrders();
  List<int> _meterIds = [];
  for (var element in _orders) {
    if (!_meterIds.contains(element[WorkOrderProblemApiStrings.meterID])) {
      _meterIds.add(element[WorkOrderProblemApiStrings.meterID]);
    }
  }
  Map<int, List<int>> _list = {};

  for (int i in _meterIds) {
    _list.addEntries([
      MapEntry(
          i,
          _orders
              .where(
                  (element) => element[WorkOrderProblemApiStrings.meterID] == i)
              .map((e) =>
                  e[WorkOrderProblemApiStrings.workOrderTemplateID] as int)
              .toList())
    ]);
  }

  SaveApiResponse? _apires;

  if (_list.isNotEmpty) {
    for (int i = 0; i < _list.length; i++) {
      int _meterID = _list.keys.toList()[i];
      List<int> _problemCodes = _list.values.toList()[i];
      await postRequest(
        createWorkOrderUrl(_meterID.toString()),
        headers: AppHttpHeaders.withAuthorization,
        disableNoInternetSnackBar: true,
        body: jsonEncode(_problemCodes),
        json: (v) => _json = v,
        unknown: () async {
          _apires = SaveApiResponse.unexpectedError;
          snackBar(SnackBarMessages.unableToCreateWorkorder);
        },
        success: () async {
          CreateWorkOrderResponse workOrders =
              CreateWorkOrderResponse.fromJson(_json);
          workOrders.meterID = _list.keys.toList()[i];
          bool _showSnackBar = workOrders.meterID == meterID && !sync;
          if (workOrders.isSuccess && _showSnackBar) {
            snackBar(SnackBarMessages.workOrdersCreatedSuccessfully);
          }
          if (workOrders.woResponseInfos.isNotEmpty) {
            List<String> _notExist = [];
            // ignore: avoid_function_literals_in_foreach_calls
            workOrders.woResponseInfos.forEach((e) async {
              _apires = saveApiresDecode(e.returnValue);
              if (_apires == SaveApiResponse.paramaterError) {
                _notExist.add(problemsList
                        .firstWhere(
                          (element) => element.id == e.workOrderTemplateID,
                          orElse: () => WorkOrderProblem(id: 0, name: ""),
                        )
                        .name ??
                    "");
              }
              if (e.returnValue <= -3 || e.returnValue == 0) {
                e.returnValue = -3;
              }

              if (_apires == SaveApiResponse.meterNotFound) {
                // ignore: avoid_function_literals_in_foreach_calls
                _problemCodes.forEach(
                  (element) async {
                    Map<String, dynamic> row = {
                      WorkOrderProblemApiStrings.message: e.message,
                      WorkOrderProblemApiStrings.status: e.returnValue,
                    };
                    await dbHelper.updateWithTwoParams(
                      WorkOrderProblemApiStrings.createWorkOrderTable,
                      row,
                      WorkOrderProblemApiStrings.meterID,
                      workOrders.meterID,
                      WorkOrderProblemApiStrings.workOrderTemplateID,
                      element,
                    );
                  },
                );
              } else if (_apires == SaveApiResponse.success) {
                await dbHelper.deleteWithTwoParams(
                  workOrders.meterID,
                  e.workOrderTemplateID,
                  WorkOrderProblemApiStrings.meterID,
                  WorkOrderProblemApiStrings.workOrderTemplateID,
                  WorkOrderProblemApiStrings.createWorkOrderTable,
                );
              } else {
                Map<String, dynamic> row = {
                  WorkOrderProblemApiStrings.message: e.message,
                  WorkOrderProblemApiStrings.status: e.returnValue,
                };
                await dbHelper.updateWithTwoParams(
                  WorkOrderProblemApiStrings.createWorkOrderTable,
                  row,
                  WorkOrderProblemApiStrings.meterID,
                  workOrders.meterID,
                  WorkOrderProblemApiStrings.workOrderTemplateID,
                  e.workOrderTemplateID,
                );
              }
            });

            if (_showSnackBar) {
              if (_apires == SaveApiResponse.meterNotFound) {
                snackBar(SnackBarMessages.meterdoesnotExist);
              } else if (_notExist.isNotEmpty) {
                if ((_notExist.length > 1 || _problemCodes.length > 1) &&
                    _notExist.length != _problemCodes.length) {
                  snackBar(SnackBarMessages.problemsDoesNotExist(_notExist),
                      duration: 3);
                } else {
                  snackBar(SnackBarMessages.problemDoesNotExist(_notExist),
                      duration: 3);
                }
              }
            }
          }
        },
        noInternet: () async {
          _apires = SaveApiResponse.noInternet;
        },
      );
    }
    if (_apires == SaveApiResponse.noInternet) {
      !sync
          ? snackBar(SnackBarMessages.checkInternet)
          : snackBar(SnackBarMessages.checkInternetDataPush);
    }
  } else {
    _apires = SaveApiResponse.success;
  }
  if ((returnIfSuccess && _apires == SaveApiResponse.success) ||
      (!returnIfSuccess && _apires != SaveApiResponse.paramaterError)) {
    return true;
  } else {
    return false;
  }
}

Future<List<Map<String, dynamic>>> getUnsyncedWorkOrders() async {
  return await dbHelper.queryById(
    WorkOrderProblemApiStrings.createWorkOrderTable,
    0,
    WorkOrderProblemApiStrings.status,
  );
}
