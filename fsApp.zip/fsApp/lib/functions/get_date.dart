import 'package:fserv/functions/date_format.dart';

String dateToString(DateTime readDate) {
  String date;

  if (readDate.toString() == "1111-11-11 00:00:00.000") {
    date = "";
  } else if (readDate.toString().isEmpty) {
    date = "";
  } else {
    date = dateFormatToBC(readDate);
  }
  return date;
}
