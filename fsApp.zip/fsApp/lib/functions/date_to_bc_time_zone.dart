import 'package:fserv/constants/app_constants.dart';
import 'package:instant/instant.dart' show formatDate, dateTimeToZone;

String dateToBcTimeZone(DateTime dateTime) =>
    formatDate(date: dateTimeToBcTimeZone(dateTime));

DateTime dateTimeToBcTimeZone(DateTime dateTime) =>
    dateTimeToZone(zone: bcTimeZone, datetime: dateTime);
