import 'package:firebase_crashlytics/firebase_crashlytics.dart';
import 'package:flutter/cupertino.dart';

import '../config/new_relic.dart';

Future<void> setLogAttributes(String name, dynamic value) async {
  try {
    await NewRelic.setAttribute(name, value.toString());
    await FirebaseCrashlytics.instance.setCustomKey(name, value);
  } on Exception catch (e) {
    debugPrint("$e");
  }
}
