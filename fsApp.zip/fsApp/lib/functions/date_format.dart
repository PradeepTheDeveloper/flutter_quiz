import 'package:fserv/constants/app_constants.dart' show bcDateFormat;

String dateFormatToBC(DateTime dateTime) {
  String date = "";

  List<String> format = bcDateFormat.split("/");
  for (int i = 0; i < format.length; i++) {
    if (format[i].contains("m")) {
      date += dateTime.month.toString().length == 1
          ? dateTime.month.toString().padLeft(2, "0")
          : dateTime.month.toString();
    } else if (format[i].contains("d")) {
      date += dateTime.day.toString().length == 1
          ? dateTime.day.toString().padLeft(2, "0")
          : dateTime.day.toString();
    } else {
      date += dateTime.year.toString();
    }
    if (i != format.length - 1) {
      date += "/";
    }
  }

  return date;
}
