import 'package:fserv/screens/appscreens.dart';

import '../constants/variables.dart';

List<int> searchInMeterList(
    SearchBy searchBy, List<int> list, String searchString) {
  return meterList.entries
      .where((element) {
        if (searchBy == SearchBy.meterNo) {
          return element.value.meterNo!
              .toLowerCase()
              .contains(searchString.toLowerCase());
        } else {
          return element.value.addressLineOne!
              .toLowerCase()
              .contains(searchString.toLowerCase());
        }
      })
      .map((e) => e.key)
      .toList();
}
