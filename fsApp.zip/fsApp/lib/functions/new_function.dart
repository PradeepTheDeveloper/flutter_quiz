import 'package:newrelic_mobile/newrelic_mobile.dart';

newRelics(String e) {
  NewrelicMobile.instance.recordError(
    e,
    StackTrace.current,
    attributes: {"name": e},
  );
}
