import 'package:fserv/config/appconfigs.dart' show CacheStorage;
import 'package:fserv/constants/app_constants.dart';
import 'package:fserv/functions/api_functions/reading_api_functions.dart';
import 'package:fserv/route/route.dart';
import 'package:fserv/screens/splash.dart';
import 'package:fserv/widgets/app_widgets.dart';

Future<void> deleteUserData() async {
  await dbHelper.deleteDB(CommunityApiStrings.communityListTable);
  await dbHelper.deleteDB(WorkOrderProblemApiStrings.problemListTable);
  await dbHelper.deleteDB(RouteApiStrings.routeListTable);
  await dbHelper.deleteDB(MeterApiStrings.meterListTable);
  await dbHelper.deleteDB(ReadingStrings.readingListTable);
  await dbHelper.deleteDB(WorkOrderApiStrings.workOrderTable);
  await dbHelper.deleteDB(MyRoutesApiStrings.myRoutesTable);
  await dbHelper.deleteDB(SkipReasonApiStrings.skipReasonTable);
  await dbHelper.deleteDB(MeterSkipReasonApiStrings.meterSkipReasonTable);

  snackBar(SnackBarMessages.unregisteredSuccessfully);

  await Future.delayed(const Duration(seconds: 1), () async {
    routeList = {};
    meterList = {};
    problemsList = [];
    myRoutesList = {};
    workOrderList = [];
    todoMeterList = [];
    communityList = {};
    completedMeterList = [];
    createdWorkOrderList = [];
    skipReasonsList = {};
    skippedMeterList = [];
    url = '';
    await CacheStorage.cache.deleteAll().then((value) {
      routeWithRemove(page: SplashScreen.routeNamed);
    });
  });
}
