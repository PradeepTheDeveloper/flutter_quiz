bool boolEncode(String value) =>
    value == "true" || value == "True" ? true : false;
