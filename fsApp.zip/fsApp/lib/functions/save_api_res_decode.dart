import 'package:fserv/constants/app_constants.dart';

SaveApiResponse saveApiresDecode(int res, {bool showMessage = false}) {
  SaveApiResponse _apiRes;
  if (res == -1) {
    _apiRes = SaveApiResponse.meterNotFound;
  } else if (res == -2) {
    _apiRes = SaveApiResponse.paramaterError;
  } else if (res > 0) {
    _apiRes = SaveApiResponse.success;
  } else if (res == 0) {
    _apiRes = SaveApiResponse.failed;
  } else {
    _apiRes = SaveApiResponse.unexpectedError;
  }
  return _apiRes;
}
