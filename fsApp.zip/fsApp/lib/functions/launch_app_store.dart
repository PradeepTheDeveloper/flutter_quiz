import 'dart:io';

import 'package:url_launcher/url_launcher.dart';

launchAppStore() async {
  const packageName = 'com.starnik.smrt';
  if (Platform.isAndroid) {
    const url =
        'https://play.google.com/store/apps/details?id=$packageName'; // android app URL
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      throw 'Could not launch $url';
    }
  } else if (Platform.isIOS) {
    const url =
        'https://apps.apple.com/us/app/smrt/id1234567890'; // iOS app URL
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      throw 'Could not launch $url';
    }
  } else {
    throw 'Platform not supported';
  }
}
