import '/config/appconfigs.dart' show CacheStorage, getDeviceInfo;
import '/constants/app_constants.dart';
import '/functions/set_log_attributes.dart';

Future<void> getAllStorageValues() async {
  isRegistered = await CacheStorage.readBool(SecureStorageKeys.isRegistered);

  pinCreated = await CacheStorage.readBool(SecureStorageKeys.pinCreated);

  isScanned = await CacheStorage.readBool(SecureStorageKeys.isScanned);

  deviceInfo = await getDeviceInfo();

  if (isRegistered) {
    userID = int.parse(await CacheStorage.readString(SecureStorageKeys.userID));

    jwtToken = await CacheStorage.readString(SecureStorageKeys.jwtToken);

    url = await CacheStorage.readString(SecureStorageKeys.url);

    loggedUserName = await CacheStorage.readString(SecureStorageKeys.userName);

    uniqueDeviceID =
        await CacheStorage.readString(SecureStorageKeys.uniqueDeviceID);

    billingCompanyID =
        await CacheStorage.readInt(SecureStorageKeys.billingCompanyID);

    userDeviceInformationID =
        await CacheStorage.readInt(SecureStorageKeys.userDeviceInformationID);

    bcTimeZone = await CacheStorage.readString(SecureStorageKeys.bcTimeZone);

    bcDateFormat =
        await CacheStorage.readString(SecureStorageKeys.bcDateFormat);

    await setLogAttributes(LogAttributes.operatingServer, Uri.parse(url).host);

    await setLogAttributes(LogAttributes.userId, userID.toString());

    await setLogAttributes(LogAttributes.userName, loggedUserName);

    await setLogAttributes(LogAttributes.userDeviceInformationID,
        userDeviceInformationID.toString());

    await setLogAttributes(LogAttributes.deviceID, deviceInfo.deviceId);

    await setLogAttributes(LogAttributes.billingCompanyID, billingCompanyID);

    if (pinCreated) {
      loginPin = await CacheStorage.readString(SecureStorageKeys.loginPin);

      mtrReadAppGPS =
          await CacheStorage.readBool(SecureStorageKeys.mtrReadAppGPS);

      showPreviousReadPrivilege = await CacheStorage.readBool(
          SecureStorageKeys.showPreviousReadPrivilege);

      createWorkorderPrivilege = await CacheStorage.readBool(
          SecureStorageKeys.createWorkorderPrivilege);

      editMeterCommentsPrivilege =
          await CacheStorage.readBool(SecureStorageKeys.editMeterPrivilege);

      meterReadPrivilege =
          await CacheStorage.readBool(SecureStorageKeys.meterReadPrivilege);

      workOrderPrivilege =
          await CacheStorage.readBool(SecureStorageKeys.workOrderPrivilege);
    }
  }
}
