import 'dart:convert';
import 'package:firebase_remote_config/firebase_remote_config.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fserv/constants/app_constants.dart';
import 'package:fserv/functions/new_function.dart';
import 'package:package_info/package_info.dart';

import '../constants/remote_config_keys.dart';
import 'get_all_values.dart';

int version = 0;
int updateType = 0;
List versionKeys = [];
int currentVersion = 0;
bool flexUpdate1 = false;
bool forceUpdate1 = false;
Future<void> checkForUpdate() async {
  await getAllStorageValues();
  final FirebaseRemoteConfig remoteConfig = FirebaseRemoteConfig.instance;
  final PackageInfo packageInfo = await PackageInfo.fromPlatform();
  try {
    await remoteConfig.setConfigSettings(RemoteConfigSettings(
      fetchTimeout: const Duration(minutes: 1),
      minimumFetchInterval: const Duration(minutes: 1),
    ));

    await remoteConfig.fetchAndActivate();

    Map<String, dynamic> appUpdateCodes = jsonDecode(
        remoteConfig.getValue(RemoteConfigKeys.appUpdateCodes).asString());

    try {
      Map<String, dynamic> versionList = appUpdateCodes;
      currentVersion = int.parse(packageInfo.buildNumber);

      versionList.forEach((key, value) {
        version = int.parse(key);
        updateType = value;

        if (currentVersion < version) {
          versionKeys.add(updateType);
        }
      });
      getUpDateType();
    } catch (e) {
      FlutterError.reportError(FlutterErrorDetails(exception: e));
      newRelics(e.toString());
      debugPrint("testing catch $e");
    }
  } on Exception catch (e) {
    debugPrint("checkForUpdate Error = ${e.toString()}");
    isAppUpdated = true;
    FlutterError.reportError(FlutterErrorDetails(exception: e));
    newRelics(e.toString());
    getData();
  }
}

void getUpDateType() {
  debugPrint("testing  value  $versionKeys");

  forceUpdate1 = versionKeys.contains(3);
  flexUpdate1 = versionKeys.contains(2);

  debugPrint(
      "values for flex update_1 $flexUpdate1 force_update_1: $forceUpdate1");
  if (forceUpdate1 == true) {
    debugPrint("testing  Force update required");

    forceUpdate = true;
    flexUpdate = false;
  } else if (flexUpdate1 == true) {
    debugPrint("testing  Flex update available");
    forceUpdate = false;
    flexUpdate = true;

    debugPrint("testing  Flex update available");
  } else {
    forceUpdate = false;
    flexUpdate = false;
    debugPrint("checking the else");
  }
  getData();
}
