import 'package:flutter/material.dart';
import 'package:fserv/constants/app_constants.dart';
import 'package:fserv/route/route.dart';

import 'package:permission_handler/permission_handler.dart';

Future showPermissionDenied(BuildContext context, bool camera) => showDialog(
      context: context,
      builder: (context) {
        return Center(
          child: SizedBox(
            height: height * 0.2,
            width: width * 0.9,
            child: Material(
              child: DecoratedBox(
                decoration: BoxDecoration(
                    color: AppColors.white,
                    borderRadius: BorderRadius.circular(10)),
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Text(
                        camera
                            ? AppStrings.cameraPermissionString
                            : AppStrings.locationPermissionString,
                        textAlign: TextAlign.center,
                        style: AppStyles.dialogText,
                      ),
                      TextButton(
                        onPressed: () async {
                          pop();
                          await openAppSettings();
                        },
                        child: const Text(
                          AppStrings.openSettings,
                          style: TextStyle(color: AppColors.blue, fontSize: 20),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );

showReadingConfirm({required String message, required VoidCallback onTap}) {
  showDialog(
    context: currentContext,
    barrierDismissible: false,
    builder: (context) {
      return AlertDialog(
        title: const Center(
            child: Text(
          "Confirm Reading",
          style: AppStyles.alertBoldHeading,
        )),
        content: Text(
          message,
          textAlign: TextAlign.center,
          style: AppStyles.alertDialogText,
        ),
        actions: [
          ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.grey,
              ),
              onPressed: () async {
                pop();
              },
              child: const Text("Cancel",
                  style: TextStyle(color: AppColors.white, fontSize: 20))),
          ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.green,
              ),
              onPressed: onTap,
              child: const Text("Accept",
                  style: TextStyle(color: AppColors.white, fontSize: 20))),
        ],
      );
    },
  );
}
