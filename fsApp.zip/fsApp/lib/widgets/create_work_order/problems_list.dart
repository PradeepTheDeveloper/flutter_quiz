import 'package:flutter/material.dart';
import '/bloc/app_bloc.dart';
import '/constants/app_constants.dart';
import '/functions/api_functions/create_workorder_api_functions.dart';
import '/model/meter.dart';
import '/route/route.dart';
import '../../functions/api_functions/reading_api_functions.dart';
import '../../screens/gather_reads/create_work_order_page.dart';
import '../app_widgets.dart';

class ProblemsList extends StatefulWidget {
  final Meter info;
  const ProblemsList({Key? key, required this.info}) : super(key: key);

  @override
  State<ProblemsList> createState() => _ProblemsListState();
}

class _ProblemsListState extends State<ProblemsList> {
  late List<int> _selectedProblem;
  late AppBloc<List<int>> _bloc;

  @override
  void initState() {
    _selectedProblem = [];
    _bloc = AppBloc<List<int>>()..data = _selectedProblem;
    super.initState();
  }

  @override
  void dispose() {
    _bloc.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return _bloc.stream((context) {
      return Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
            flex: 6,
            child: problemsList.isNotEmpty
                ? ListView.builder(
                    itemCount: problemsList.length,
                    itemBuilder: (context, i) => InkWell(
                      onTap: () {
                        if (!_selectedProblem.contains(problemsList[i].id)) {
                          _selectedProblem.add(problemsList[i].id);
                          _bloc.change(_selectedProblem);
                        } else {
                          _selectedProblem.remove(problemsList[i].id);
                          _bloc.change(_selectedProblem);
                        }
                      },
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 10),
                        child: Center(
                          child: SizedBox(
                            height: height * 0.08,
                            width: width * 0.8,
                            child: DecoratedBox(
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(5),
                                  color:
                                      _bloc.data!.contains(problemsList[i].id)
                                          ? AppColors.yellow
                                          : null),
                              child: Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Align(
                                  alignment: Alignment.centerLeft,
                                  child: Text(
                                    problemsList[i].name!,
                                    style:
                                        _bloc.data!.contains(problemsList[i].id)
                                            ? AppStyles.selectedProlem
                                            : AppStyles.unSlectedProblem,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  )
                : const Center(
                    child: Text(AppStrings.noWorkOrderTemplatesAvailable),
                  ),
          ),
          Flexible(
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 10),
              child: Button(
                  width: width * 0.8,
                  height: height * 0.06,
                  onPress: () async {
                    if (_selectedProblem.isEmpty) {
                      snackBar(SnackBarMessages.pleaseSelectAProblem);
                    } else {
                      showLoader(LoaderStrings.pleaseWait);
                      await saveWorkordertolocal(_selectedProblem);
                      await createWorkOrder().then((value) async {
                        _selectedProblem.clear();
                        _bloc.change(_selectedProblem);
                        if (value) {
                          await getWorkOrderList(sync: true).then((value) {
                            routeWithRemove(page: CreateWorkOrder.routeNamed);
                          });
                        } else {
                          pop();
                        }
                      });
                    }
                  },
                  text: AppStrings.createWorkOrder,
                  tStyle: AppStyles.buttonStyle),
            ),
          )
        ],
      );
    });
  }
}

Future<void> saveWorkordertolocal(List<int> problems) async {
  for (var element in problems) {
    Map<String, dynamic> row = {
      WorkOrderProblemApiStrings.meterID: meterID,
      WorkOrderProblemApiStrings.workOrderTemplateID: element,
      WorkOrderProblemApiStrings.status: 0,
    };
    await dbHelper.insertWorkOrder(row);
  }
}
