import 'package:flutter/material.dart';
import 'package:fserv/constants/app_constants.dart';
import 'package:fserv/model/work_order_taskbin.dart';

class WorkOrderTaskbinCard extends StatefulWidget {
  final TaskBin workOrder;
  const WorkOrderTaskbinCard({Key? key, required this.workOrder})
      : super(key: key);

  @override
  State<WorkOrderTaskbinCard> createState() => _WorkOrderTaskbinCardState();
}

class _WorkOrderTaskbinCardState extends State<WorkOrderTaskbinCard> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 15),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(8.0),
          color: AppColors.grey,
        ),
        padding: const EdgeInsets.only(right: 30, left: 10),
        height: height * 0.06,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              widget.workOrder.taskbinName,
              style: AppStyles.workOrderTaskbinName,
            ),
            Text(
              '${widget.workOrder.workOrderCount}',
              style: AppStyles.workOrderTaskbinCount,
            )
          ],
        ),
      ),
    );
  }
}
