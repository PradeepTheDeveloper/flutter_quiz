import 'package:flutter/material.dart';
import 'package:fserv/constants/app_constants.dart';
import 'package:fserv/model/work_order.dart';
import 'package:fserv/widgets/create_work_order/work_order_card.dart';

class WorkOrderListView extends StatelessWidget {
  final List<WorkOrder>? list;
  const WorkOrderListView({Key? key, required this.list}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return (list == null)
        ? const Center(
            child: Text(AppStrings.connectToFetchData),
          )
        : (list!.isEmpty)
            ? const Center(
                child: Text(AppStrings.noRecordsFound),
              )
            : ListView.builder(
                itemCount: list!.length,
                itemBuilder: (context, i) {
                  return WorkOrderCard(
                    workOrder: list![i],
                  );
                },
              );
  }
}
