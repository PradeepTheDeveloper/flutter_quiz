import 'package:flutter/material.dart';
import 'package:fserv/constants/app_constants.dart';
import 'package:fserv/functions/null_date.dart';
import 'package:fserv/model/work_order.dart';

class WorkOrderCard extends StatelessWidget {
  final WorkOrder workOrder;
  const WorkOrderCard({Key? key, required this.workOrder}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: height * 0.235,
      child: Card(
        color: AppColors.black,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 25),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              Stack(
                children: [
                  Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        workOrder.priority,
                        style: WorkOrderCardStyles.priority,
                      )),
                  Align(
                      alignment: Alignment.center,
                      child: Text(
                        workOrder.meterWorkOrderID.toString(),
                        style: WorkOrderCardStyles.workId,
                      ))
                ],
              ),
              Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text(
                    "${workOrder.task.split(" ")[0]} - ",
                    style: WorkOrderCardStyles.taskCode,
                  ),
                  Flexible(
                    child: Text(
                      workOrder.task.split(" ").sublist(1).toList().join(" "),
                      style: WorkOrderCardStyles.task,
                      softWrap: true,
                    ),
                  ),
                ],
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  Column(
                    children: [
                      const Text(
                        "Created Date",
                        style: WorkOrderCardStyles.dateLable,
                      ),
                      Text(
                        nullDate(workOrder.createdDate),
                        style: WorkOrderCardStyles.date,
                      ),
                    ],
                  ),
                  Column(
                    children: [
                      const Text(
                        "Future Start Date",
                        style: WorkOrderCardStyles.dateLable,
                      ),
                      Text(
                        nullDate(workOrder.futureStartDate),
                        style: WorkOrderCardStyles.date,
                      ),
                    ],
                  ),
                  Column(
                    children: [
                      const Text(
                        "Completed Date",
                        style: WorkOrderCardStyles.dateLable,
                      ),
                      Text(
                        nullDate(workOrder.completedDate),
                        style: WorkOrderCardStyles.date,
                      ),
                    ],
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
