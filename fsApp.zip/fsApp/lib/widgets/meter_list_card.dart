import 'package:flutter/material.dart';
import 'package:fserv/constants/app_constants.dart';
import 'package:fserv/model/meter.dart';

class MeterListCard extends StatelessWidget {
  final Meter meter;
  const MeterListCard({Key? key, required this.meter}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 10),
      child: SizedBox(
        width: width * 0.88,
        child: DecoratedBox(
          decoration: BoxDecoration(
              color: meter.readCount! > 0
                  ? AppColors.meterListCompletedCard
                  : meter.meterReadSkipReasonID! > 0 && meter.readCount! <= 0
                      ? AppColors.meterListSkippedCard
                      : AppColors.meterListTodoCard,
              borderRadius: BorderRadius.circular(10)),
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 15),
            child: Text(
              "${meter.meterNo}\n ${meter.addressLineOne}",
              textAlign: TextAlign.center,
              style: MeterListCardStyles.text,
            ),
          ),
        ),
      ),
    );
  }
}
