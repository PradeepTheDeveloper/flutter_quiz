import 'dart:io' show Platform;
import 'package:flutter/material.dart';
import 'package:fserv/bloc/app_bloc.dart';
import 'package:fserv/constants/app_constants.dart';
import 'package:fserv/widgets/app_widgets.dart';

int? _lastTimeBackButtonWasTapped;
const exitTimeInMillis = 2000;

class DoubleBackToClose extends StatelessWidget {
  final Widget child;
  final FocusNode? focusNode;
  final AppBloc<bool>? keyBoardVisibility;

  const DoubleBackToClose(
      {Key? key, required this.child, this.keyBoardVisibility, this.focusNode})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    if (Platform.isAndroid) {
      return WillPopScope(
        onWillPop: () => _handleWillPop(context),
        child: child,
      );
    } else {
      return child;
    }
  }

  Future<bool> _handleWillPop(BuildContext context) async {
    final _currentTime = timeNow.millisecondsSinceEpoch;

    if (_lastTimeBackButtonWasTapped != null &&
        (_currentTime - _lastTimeBackButtonWasTapped!) < exitTimeInMillis) {
      removeSnackBar(context);
      return true;
    } else {
      if (keyBoardVisibility == null && focusNode == null) {
        _lastTimeBackButtonWasTapped = timeNow.millisecondsSinceEpoch;
        removeSnackBar(context);
        snackBar(SnackBarMessages.pressBackagaintoexit);
        return false;
      } else if (focusNode != null) {
        if (focusNode!.hasFocus) {
          focusNode!.unfocus();
          return false;
        } else {
          _lastTimeBackButtonWasTapped = timeNow.millisecondsSinceEpoch;
          removeSnackBar(context);
          snackBar(SnackBarMessages.pressBackagaintoexit);
          return false;
        }
      } else {
        if (keyBoardVisibility!.data!) {
          keyBoardVisibility!.change(false);
          return false;
        } else {
          _lastTimeBackButtonWasTapped = timeNow.millisecondsSinceEpoch;
          removeSnackBar(context);
          snackBar(SnackBarMessages.pressBackagaintoexit);
          return false;
        }
      }
    }
  }
}
