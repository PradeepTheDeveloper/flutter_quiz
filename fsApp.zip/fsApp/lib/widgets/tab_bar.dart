import 'package:flutter/material.dart';
import 'package:fserv/constants/app_constants.dart';

class AppTabBar extends StatelessWidget {
  final String tab1;
  final String tab2;
  final String? tab3;
  final TabController controller;
  const AppTabBar({
    Key? key,
    required this.tab1,
    required this.tab2,
    this.tab3,
    required this.controller,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Flexible(
      child: SizedBox(
        height: height * 0.07,
        width: width * 0.85,
        child: DecoratedBox(
          decoration: BoxDecoration(
            color: AppColors.inactiveTabColor,
            borderRadius: BorderRadius.circular(10),
          ),
          child: TabBar(
            unselectedLabelColor: AppColors.inactiveTabText,
            labelColor: AppColors.activeTabText,
            labelStyle: AppStyles.tabTextStyle,
            indicator: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: AppColors.activeTabColor),
            controller: controller,
            tabs: [
              Tab(
                text: tab1,
              ),
              Tab(
                text: tab2,
              ),
              if (tab3 != null)
                Tab(
                  text: tab3,
                ),
            ],
          ),
        ),
      ),
    );
  }
}
