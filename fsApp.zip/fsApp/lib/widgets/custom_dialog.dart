import 'package:flutter/material.dart';
import '../constants/color.dart';

showCustomDialog(BuildContext context,
    {required widget,
    AlignmentGeometry? rightAlign,
    AlignmentGeometry? leftAlign,
    bool barrierDismissible = false}) {
  return showGeneralDialog(
    context: context,
    barrierLabel: '',
    barrierDismissible: barrierDismissible,
    barrierColor: AppColors.black,
    transitionDuration: const Duration(milliseconds: 400),
    pageBuilder: (_, __, ___) {
      return Padding(
        padding: (leftAlign != null &&
                rightAlign != null &&
                leftAlign == Alignment.bottomLeft &&
                rightAlign == Alignment.bottomRight)
            ? const EdgeInsets.symmetric(horizontal: 70, vertical: 200)
            : const EdgeInsets.all(20),
        child: widget,
      );
    },
    transitionBuilder: (_, anim, __, child) {
      Tween<Offset> tween;
      if (anim.status == AnimationStatus.reverse) {
        tween = Tween(begin: const Offset(-1, 0), end: Offset.zero);
      } else {
        tween = Tween(begin: const Offset(1, 0), end: Offset.zero);
      }

      return SlideTransition(
        position: tween.animate(anim),
        child: FadeTransition(opacity: anim, child: child),
      );
    },
  );
}
