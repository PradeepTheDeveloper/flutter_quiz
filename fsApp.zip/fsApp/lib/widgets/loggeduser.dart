import 'package:flutter/material.dart';
import '/constants/app_constants.dart';
import '/widgets/app_widgets.dart';

class LoggedUser extends StatelessWidget {
  const LoggedUser({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(top: height * 0.03, bottom: 25.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                Padding(
                  padding: const EdgeInsets.only(left: 16.0),
                  child: TextWidget(
                      text: AppStrings.loggedHint,
                      style: AppStyles.loggedStyle),
                ),
                const Spacer(),
              ],
            ),
          ),
          TextWidget(text: loggedUserName, style: AppStyles.userStyle),
        ],
      ),
    );
  }
}
