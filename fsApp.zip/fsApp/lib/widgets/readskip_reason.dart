import 'package:flutter/material.dart';
import 'package:fserv/bloc/app_bloc.dart';
import 'package:fserv/constants/app_constants.dart';
import 'package:fserv/model/skip_reason.dart';
import 'package:fserv/route/route.dart';
import 'package:fserv/widgets/app_widgets.dart';

Future skipCodesDialog(
        BuildContext context, void Function(int, String) onDone) =>
    showDialog(
      context: context,
      builder: (context) {
        return SkipCodeDialog(
          onDone: onDone,
        );
      },
    );

class SkipCodeDialog extends StatefulWidget {
  final void Function(int, String) onDone;
  const SkipCodeDialog({
    Key? key,
    required this.onDone,
  }) : super(key: key);

  @override
  State<SkipCodeDialog> createState() => _SkipCodeDialogState();
}

class _SkipCodeDialogState extends State<SkipCodeDialog> {
  late final TextEditingController _controller;
  late final FocusNode _focusNode;
  late final AppBloc<SkipReason> _skipCodeBloc;
  @override
  void initState() {
    _controller = TextEditingController();
    _skipCodeBloc = AppBloc<SkipReason>();
    _focusNode = FocusNode();
    super.initState();
  }

  @override
  void dispose() {
    _controller.dispose();
    _skipCodeBloc.close();
    _focusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    List<SkipReason> _skipReasons = skipReasonsList.values
        .where(
          (element) => element.isActive,
        )
        .toList();
    return Scaffold(
      backgroundColor: AppColors.transparent,
      body: _skipCodeBloc.stream(
        (context) {
          bool _notesRequired = _skipCodeBloc.data?.isNotesRequired ?? false;
          if (_notesRequired) {
            _focusNode.requestFocus();
          }
          return Stack(
            alignment: Alignment.center,
            children: [
              InkWell(
                  onTap: () {
                    pop();
                  },
                  child: SizedBox(
                    height: height,
                    width: width,
                  )),
              ConstrainedBox(
                constraints: BoxConstraints(
                  maxHeight: height * 0.6,
                  minHeight: height * 0.2,
                  maxWidth: width * 0.9,
                ),
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    color: AppColors.black,
                    borderRadius: BorderRadius.circular(5),
                  ),
                  child: Padding(
                    padding: EdgeInsets.all(width * 0.05),
                    child: Stack(
                      alignment: Alignment.topCenter,
                      children: [
                        Padding(
                          padding: EdgeInsets.only(
                              top: height * 0.05, bottom: height * 0.06),
                          child: SingleChildScrollView(
                            child: Column(
                              children: [
                                SingleChildScrollView(
                                  child: Column(
                                    children: [
                                      for (var i = 0;
                                          i < _skipReasons.length;
                                          i++)
                                        InkWell(
                                          onTap: () {
                                            _skipCodeBloc
                                                .change(_skipReasons[i]);
                                            if (!_skipReasons[i]
                                                .isNotesRequired) {
                                              widget.onDone.call(
                                                  _skipReasons[i].skipReasonID,
                                                  _controller.text);
                                            }
                                          },
                                          child: Padding(
                                            padding: const EdgeInsets.all(8.0),
                                            child: DecoratedBox(
                                              decoration: BoxDecoration(
                                                color: AppColors.green,
                                                borderRadius:
                                                    BorderRadius.circular(5),
                                              ),
                                              child: SizedBox(
                                                width: width * 0.75,
                                                child: Padding(
                                                  padding: EdgeInsets.all(
                                                      height * 0.01),
                                                  child: Text(
                                                    _skipReasons[i].skipReason,
                                                    textAlign: TextAlign.center,
                                                    softWrap: true,
                                                    style:
                                                        AppStyles.buttonStyle,
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                    ],
                                  ),
                                )
                              ],
                            ),
                          ),
                        ),
                        Column(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Text(
                              AppStrings.selectSkipReason,
                              style: AppStyles.boldHeading,
                            ),
                            if (_notesRequired) const Spacer(),
                            if (_notesRequired)
                              Row(
                                children: [
                                  InputTextFormField(
                                    controller: _controller,
                                    keyboardType: TextInputType.text,
                                    hint: AppStrings.skipNotes,
                                    color: AppColors.lightWhite,
                                    alignText: TextAlign.left,
                                    maxLength: 50,
                                    focusNode: _focusNode,
                                    textStyle: AppStyles.signInTextStyle,
                                    onSubmit: (value) {
                                      if (value.isNotEmpty &&
                                          !emptyTextValidation(value)) {
                                        widget.onDone.call(
                                            _skipCodeBloc.data!.skipReasonID,
                                            value);
                                      } else {
                                        snackBar(SnackBarMessages
                                            .enterValidSkipNotes);
                                      }
                                    },
                                    contentPadding:
                                        EdgeInsets.only(left: width * 0.05),
                                    width: width * 0.8,
                                    suffixIcon: IconButton(
                                      onPressed: () {
                                        String _value = _controller.text;
                                        if (_value.isNotEmpty &&
                                            !emptyTextValidation(_value)) {
                                          widget.onDone.call(
                                              _skipCodeBloc.data!.skipReasonID,
                                              _value);
                                        } else {
                                          snackBar(SnackBarMessages
                                              .enterValidSkipNotes);
                                        }
                                      },
                                      icon: const Icon(
                                        Icons.check_circle,
                                        color: AppColors.green,
                                        size: 34,
                                      ),
                                    ),
                                  ),
                                ],
                              )
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}
