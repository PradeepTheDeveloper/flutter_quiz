import 'package:flutter/material.dart';
import 'package:fserv/constants/app_constants.dart';

class InputTextFormField extends StatelessWidget {
  final int? maxLines;
  final int? maxLength;
  final double? height;
  final double width;
  final Color color;
  final TextEditingController controller;
  final VoidCallback? onTap;
  final void Function(String)? onSubmit;
  final bool? readOnly;
  final FocusNode? focusNode;
  final TextAlign? alignText;
  final String hint;
  final Widget? suffixIcon;
  final TextInputType keyboardType;
  final TextStyle? textStyle;
  final bool? obscureText;
  final EdgeInsetsGeometry? contentPadding;
  final bool? enable;
  final bool? showCursor;
  final bool? autofocus;
  const InputTextFormField(
      {Key? key,
      required this.controller,
      this.height,
      this.readOnly,
      this.focusNode,
      this.onSubmit,
      this.maxLength,
      this.onTap,
      this.autofocus,
      this.enable,
      this.obscureText,
      this.showCursor,
      this.suffixIcon,
      this.contentPadding,
      required this.keyboardType,
      required this.hint,
      required this.color,
      required this.width,
      this.maxLines,
      this.textStyle,
      this.alignText})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: width,
      height: height,
      child: TextFormField(
        controller: controller,
        focusNode: focusNode,
        maxLines: maxLines,
        autofocus: autofocus ?? false,
        textAlign: alignText ?? TextAlign.center,
        readOnly: readOnly ?? false,
        showCursor: showCursor,
        onTap: onTap,
        maxLength: maxLength,
        enabled: enable,
        obscureText: obscureText ?? false,
        enableSuggestions: false,
        autocorrect: false,
        keyboardType: keyboardType,
        style: textStyle ?? AppStyles.cardTextStyle,
        validator: (value) {
          if (value!.isEmpty || emptyTextValidation(value)) {
            return "Enter valid $hint";
          }
          return null;
        },
        onFieldSubmitted: onSubmit,
        textInputAction: TextInputAction.done,
        decoration: InputDecoration(
            contentPadding: contentPadding ?? const EdgeInsets.all(2),
            filled: true,
            hintText: hint,
            hintStyle: textStyle,
            fillColor: color,
            counterText: "",
            suffixIcon: suffixIcon,
            focusColor: Colors.transparent,
            border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(4.0),
                borderSide: const BorderSide(color: Colors.transparent)),
            focusedBorder: const OutlineInputBorder(
                borderSide: BorderSide(color: Colors.transparent)),
            enabledBorder: const OutlineInputBorder(
                borderSide: BorderSide(color: Colors.transparent))),
      ),
    );
  }
}
