import 'package:flutter/material.dart'
    show ScrollBehavior, Widget, BuildContext, AxisDirection;

class ScrollConfig extends ScrollBehavior {
  Widget buildViewportChrome(
      BuildContext context, Widget child, AxisDirection axisDirection) {
    return child;
  }
}
