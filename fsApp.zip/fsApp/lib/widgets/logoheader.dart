import 'package:flutter/material.dart';
import '/constants/app_constants.dart';

class LogoHeader extends StatelessWidget {
  const LogoHeader({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
        padding: EdgeInsets.symmetric(vertical: 8.0, horizontal: width * 0.15),
        child: SizedBox(
          height: height * 0.12,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Image.asset(Images.starnikLogo),
              const Text(AppStrings.logoSloganText,
                  style: AppStyles.sloganStyle),
            ],
          ),
        ));
  }
}
