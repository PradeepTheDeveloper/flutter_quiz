import 'package:flutter/material.dart';
import 'package:fserv/constants/app_constants.dart';
import 'package:fserv/route/route.dart';

Future<dynamic> showBottom({
  required BuildContext context,
  required VoidCallback? onTap,
  required Widget child,
  bool? whenComplete,
}) =>
    showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        builder: (context) => BottomOverlay(
              onTap: onTap,
              child: child,
            )).whenComplete(() {
      if (whenComplete ?? false) {
        currentContext = context;
      }
    });

class BottomOverlay extends StatelessWidget {
  final VoidCallback? onTap;
  final Widget child;
  const BottomOverlay({
    Key? key,
    required this.onTap,
    required this.child,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Stack(
        children: [
          InkWell(
            onTap: () {
              pop();
            },
            child: SizedBox(
              width: width,
              height: height,
            ),
          ),
          Align(
            alignment: Alignment.bottomCenter,
            child: SizedBox(
              width: double.infinity,
              child: DecoratedBox(
                decoration: const BoxDecoration(
                    borderRadius:
                        BorderRadius.vertical(top: Radius.circular(20)),
                    color: AppColors.grey),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    InkWell(
                      onTap: onTap,
                      child: Container(
                        height: 5,
                        width: width * 0.2,
                        margin: const EdgeInsets.only(top: 10),
                        decoration: BoxDecoration(
                            color: AppColors.white,
                            borderRadius: BorderRadius.circular(100)),
                      ),
                    ),
                    child,
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
