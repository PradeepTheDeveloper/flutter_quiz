import 'package:flutter/material.dart';
import 'package:fserv/constants/app_constants.dart';
import 'package:fserv/widgets/app_widgets.dart';

class Button extends StatelessWidget {
  final double height;
  final double width;
  final VoidCallback onPress;
  final String text;
  final TextStyle tStyle;
  final IconData? icon;
  const Button({
    Key? key,
    required this.width,
    required this.height,
    required this.onPress,
    required this.text,
    required this.tStyle,
    this.icon,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: height,
      width: width,
      child: ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: AppColors.green,
            foregroundColor: AppColors.white,
          ),
          onPressed: onPress,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (icon != null)
                Icon(
                  icon,
                  color: AppColors.black,
                ),
              Expanded(
                child: FittedBox(
                  fit: BoxFit.scaleDown,
                  child: TextWidget(
                    text: text,
                    style: tStyle,
                  ),
                ),
              )
            ],
          )),
    );
  }
}
