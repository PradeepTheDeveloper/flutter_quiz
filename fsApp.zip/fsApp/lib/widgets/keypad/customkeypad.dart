import 'package:flutter/material.dart';
import 'package:fserv/bloc/app_bloc.dart';
import 'package:fserv/constants/app_constants.dart';
import 'package:fserv/widgets/scroll_config.dart';

class AppPinEntryKeyBoard extends StatelessWidget {
  final Widget child;
  final TextEditingController controller;
  final FocusNode? focusNode;
  final VoidCallback onDone;
  final bool save;
  final ScrollController scrollController;
  final int maxLength;
  final AppBloc<bool> keyboardBloc;
  const AppPinEntryKeyBoard({
    Key? key,
    required this.child,
    required this.onDone,
    required this.controller,
    required this.save,
    this.focusNode,
    required this.maxLength,
    required this.keyboardBloc,
    required this.scrollController,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return keyboardBloc.stream((context) {
      if (keyboardBloc.connectionState != ConnectionState.waiting) {
        scroll(keyboardBloc.data ?? false);
      }
      return SizedBox(
        width: width,
        height: height,
        child: ScrollConfiguration(
          behavior: ScrollConfig(),
          child: SingleChildScrollView(
            physics: const NeverScrollableScrollPhysics(),
            controller: scrollController,
            child: Column(
              children: [
                SizedBox(
                  height: keyboardBloc.data ?? false ? height * 0.86 : height,
                  child: Align(alignment: Alignment.topCenter, child: child),
                ),
                SizedBox(
                  height: height * 0.38,
                  child: CustomKeyboard(
                    allowDecimal: false,
                    allowNegative: false,
                    onTextInput: (myText) {
                      if (controller.text.length != maxLength) {
                        _insertText(myText: myText, controller: controller);
                      }
                    },
                    onBackspace: () {
                      _backspace(controller: controller);
                    },
                    onSubmit: onDone,
                    save: save,
                  ),
                )
              ],
            ),
          ),
        ),
      );
    });
  }

  void scroll(bool show) async {
    if (show) {
      await scrollController.animateTo(height * 0.6,
          duration: const Duration(milliseconds: 500), curve: Curves.ease);
    } else {
      await scrollController.animateTo(
          scrollController.position.minScrollExtent,
          duration: const Duration(milliseconds: 500),
          curve: Curves.ease);
    }
  }
}

class AppKeyBoard extends StatelessWidget {
  final Widget child;
  final TextEditingController controller;
  final VoidCallback onDone;
  final VoidCallback? onSkip;
  final bool save;
  final bool? allowDecimal;
  final bool? allowNegative;
  final bool? allowSkip;
  final int maxLength;
  final AppBloc<bool> keyboardBloc;
  const AppKeyBoard({
    Key? key,
    required this.child,
    required this.onDone,
    required this.controller,
    required this.save,
    this.allowDecimal,
    this.allowNegative,
    this.allowSkip,
    this.onSkip,
    required this.maxLength,
    required this.keyboardBloc,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return keyboardBloc.stream((context) {
      return SizedBox(
          width: width,
          height: height,
          child: Stack(
            alignment: Alignment.bottomCenter,
            children: [
              child,
              AnimatedPositioned(
                  duration: const Duration(milliseconds: 300),
                  bottom: keyboardBloc.data ?? false ? 0 : -500,
                  child: CustomKeyboard(
                    allowDecimal: allowDecimal,
                    allowNegative: allowNegative,
                    allowSkip: allowSkip,
                    onSkip: onSkip,
                    onTextInput: (myText) {
                      if (controller.text.length != maxLength) {
                        _insertText(myText: myText, controller: controller);
                      }
                    },
                    onBackspace: () {
                      _backspace(controller: controller);
                    },
                    onSubmit: onDone,
                    save: save,
                  )),
            ],
          ));
    });
  }
}

void _insertText(
    {required String myText, required TextEditingController controller}) {
  final text = controller.text;
  final textSelection = controller.selection;
  final newText = text.replaceRange(
    textSelection.start,
    textSelection.end,
    myText,
  );
  final myTextLength = myText.length;
  controller.text = newText;
  controller.selection = textSelection.copyWith(
    baseOffset: textSelection.start + myTextLength,
    extentOffset: textSelection.start + myTextLength,
  );
}

void _backspace({required TextEditingController controller}) {
  final text = controller.text;
  final textSelection = controller.selection;
  final selectionLength = textSelection.end - textSelection.start;

  if (selectionLength > 0) {
    final newText = text.replaceRange(
      textSelection.start,
      textSelection.end,
      '',
    );
    controller.text = newText;
    controller.selection = textSelection.copyWith(
      baseOffset: textSelection.start,
      extentOffset: textSelection.start,
    );
    return;
  }

  if (textSelection.start == 0) {
    // ignore: invalid_use_of_visible_for_testing_member, invalid_use_of_protected_member
    controller.notifyListeners();
    return;
  }

  final previousCodeUnit = text.codeUnitAt(textSelection.start - 1);
  final offset = _isUtf16Surrogate(previousCodeUnit) ? 2 : 1;
  final newStart = textSelection.start - offset;
  final newEnd = textSelection.start;
  final newText = text.replaceRange(
    newStart,
    newEnd,
    '',
  );
  controller.text = newText;
  controller.selection = textSelection.copyWith(
    baseOffset: newStart,
    extentOffset: newStart,
  );
}

bool _isUtf16Surrogate(int value) {
  return value & 0xF800 == 0xD800;
}

class CustomKeyboard extends StatelessWidget {
  final ValueSetter<String> onTextInput;
  final VoidCallback onBackspace;
  final VoidCallback onSubmit;
  final VoidCallback? onSkip;
  final bool? allowNegative;
  final bool? allowDecimal;
  final bool? allowSkip;

  final bool save;
  const CustomKeyboard({
    Key? key,
    required this.onTextInput,
    required this.onBackspace,
    required this.onSubmit,
    this.onSkip,
    required this.save,
    this.allowNegative,
    this.allowDecimal,
    this.allowSkip,
  }) : super(key: key);

  void _textInputHandler(String text) => onTextInput.call(text);

  void _backspaceHandler() => onBackspace.call();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: width,
      color: AppColors.grey,
      padding: EdgeInsets.only(bottom: width * 0.03),
      child: Row(
        children: [
          SizedBox(
            width: width * 0.75,
            child: Column(
              children: [
                buildRowOne(),
                buildRowTwo(),
                buildRowThree(),
                buildRowFour(),
              ],
            ),
          ),
          buildRowFive()
        ],
      ),
    );
  }

  Row buildRowOne() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        TextKey(
          text: '1',
          onTextInput: _textInputHandler,
        ),
        TextKey(
          text: '2',
          onTextInput: _textInputHandler,
        ),
        TextKey(
          text: '3',
          onTextInput: _textInputHandler,
        ),
      ],
    );
  }

  Row buildRowTwo() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        TextKey(
          text: '4',
          onTextInput: _textInputHandler,
        ),
        TextKey(
          text: '5',
          onTextInput: _textInputHandler,
        ),
        TextKey(
          text: '6',
          onTextInput: _textInputHandler,
        ),
      ],
    );
  }

  Row buildRowThree() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        TextKey(
          text: '7',
          onTextInput: _textInputHandler,
        ),
        TextKey(
          text: '8',
          onTextInput: _textInputHandler,
        ),
        TextKey(
          text: '9',
          onTextInput: _textInputHandler,
        ),
      ],
    );
  }

  Column buildRowFive() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        save
            ? SaveKey(
                onTap: onSubmit,
              )
            : DoneKey(
                onTap: onSubmit,
              ),
        BackspaceKey(
          onBackspace: _backspaceHandler,
        ),
      ],
    );
  }

  Row buildRowFour() {
    return Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
      allowDecimal ?? false
          ? TextKey(
              text: '.',
              onTextInput: _textInputHandler,
            )
          : SizedBox(
              height: 45,
              width: width * 0.22,
            ),
      TextKey(
        text: '0',
        onTextInput: _textInputHandler,
      ),
      allowNegative ?? false
          ? TextKey(
              text: '-',
              onTextInput: _textInputHandler,
            )
          : allowSkip ?? false
              ? SaveKey(
                  onTap: onSkip,
                  skipKey: allowSkip,
                )
              : SizedBox(
                  height: 45,
                  width: width * 0.22,
                ),
    ]);
  }
}

class TextKey extends StatelessWidget {
  const TextKey({
    Key? key,
    required this.text,
    required this.onTextInput,
  }) : super(key: key);

  final String text;
  final ValueSetter<String> onTextInput;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(top: height * 0.02),
      child: InkWell(
        onTap: () {
          onTextInput.call(text);
        },
        child: Container(
          height: height * 0.07,
          width: width * 0.2,
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12), color: AppColors.yellow),
          child: Center(
              child: Text(
            text,
            style: AppStyles.keyBoardKey,
          )),
        ),
      ),
    );
  }
}

class BackspaceKey extends StatelessWidget {
  const BackspaceKey({
    Key? key,
    required this.onBackspace,
  }) : super(key: key);

  final VoidCallback onBackspace;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(top: width * 0.03),
      child: InkWell(
        onTap: () {
          onBackspace.call();
        },
        child: Container(
          height: height * 0.07,
          width: width * 0.22,
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              color: AppColors.backSpaceColor),
          child: const Icon(Icons.backspace, color: AppColors.black),
        ),
      ),
    );
  }
}

class SaveKey extends StatelessWidget {
  final VoidCallback? onTap;
  final bool? skipKey;
  const SaveKey({
    Key? key,
    this.onTap,
    this.skipKey,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(top: height * 0.02),
      child: InkWell(
        onTap: onTap,
        child: Container(
            width: width * 0.2,
            height: skipKey ?? false ? height * 0.07 : height * 0.25,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              color: skipKey ?? false ? AppColors.blue : AppColors.green,
            ),
            child: Center(
                child: Text(
              skipKey ?? false ? AppStrings.skip : AppStrings.save,
              style: AppStyles.keyBoardKey
                  .copyWith(color: skipKey ?? false ? AppColors.white : null),
            ))),
      ),
    );
  }
}

class DoneKey extends StatelessWidget {
  final VoidCallback onTap;
  const DoneKey({
    Key? key,
    required this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(top: height * 0.02),
      child: InkWell(
        onTap: onTap,
        child: Container(
          width: width * 0.2,
          height: height * 0.25,
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12), color: AppColors.green),
          child: const Center(
              child: Text(
            AppStrings.done,
            style: AppStyles.keyBoardKey,
          )),
        ),
      ),
    );
  }
}
