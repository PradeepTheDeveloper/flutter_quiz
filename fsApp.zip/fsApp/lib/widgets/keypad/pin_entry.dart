import 'package:flutter/material.dart';
import 'package:fserv/bloc/app_bloc.dart';
import 'package:fserv/constants/app_constants.dart';

int j = 0;
String _pin = "";

class LoginPin extends StatelessWidget {
  final List<TextEditingController> controllers;
  final List<FocusNode> focusNodes;
  final ValueSetter<String> onComplete;
  final ValueSetter<String> onChanged;
  final ValueSetter<TextEditingController> onTap;
  final AppBloc<bool> showPinBloc;
  const LoginPin({
    Key? key,
    required this.onComplete,
    required this.onChanged,
    required this.onTap,
    required this.controllers,
    required this.focusNodes,
    required this.showPinBloc,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    j = 0;
    return showPinBloc.stream((context) {
      return SizedBox(
        width: width * 0.6,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          mainAxisSize: MainAxisSize.min,
          children: [
            for (int i = 0; i < 4; i++)
              PinEntry(
                  controller: controllers[i],
                  showPin: showPinBloc.data!,
                  focusNode: focusNodes[i],
                  start: i == 0 ? true : false,
                  position: i,
                  end: i == 4 ? true : false,
                  onTap: () {
                    onTextchanged(i);
                    onTap.call(controllers[i]);
                  }),
          ],
        ),
      );
    });
  }

  void onTextchanged(int i) {
    j = 0;
    _pin = controllers.fold(
        "", (previousValue, element) => previousValue + element.text);
    ++j;
    onChanged.call(_pin);
    empty() {
      if (j == 0) {
        if (i > 0 && controllers[i].text.isEmpty) {
          onTextchanged(i - 1);
        }
      }
      if (i < 3) {
        if (controllers[i].text.isNotEmpty && controllers[i + 1].text.isEmpty) {
          onTextchanged(i + 1);
          controllers[i].removeListener(empty);
        }
      }

      if (controllers.every((element) => element.text.isNotEmpty) && j == 0) {
        _pin = controllers.fold(
            "", (previousValue, element) => previousValue + element.text);
        onComplete.call(_pin);
        controllers[i].removeListener(empty);
        focusNodes[i].nextFocus();
      }
    }

    filled() {
      if (controllers[i].text.isEmpty) {
        onTextchanged(i);

        if (controllers.every((element) => element.text.isNotEmpty)) {
          _pin = controllers.fold(
              "", (previousValue, element) => previousValue + element.text);
          onComplete.call(_pin);
          controllers[i].removeListener(filled);
          focusNodes[i].unfocus();
        }

        controllers[i].removeListener(filled);
      }
    }

    if (i <= 3) {
      focusNodes[i].requestFocus();
      onTap.call(controllers[i]);
      controllers[i]
          .addListener(controllers[i].text.isNotEmpty ? filled : empty);
    }
  }
}

class PinEntry extends StatefulWidget {
  final TextEditingController controller;
  final FocusNode focusNode;
  final bool? end;
  final bool? start;
  final VoidCallback onTap;
  final int position;
  final bool showPin;
  const PinEntry({
    Key? key,
    required this.controller,
    required this.focusNode,
    required this.onTap,
    required this.showPin,
    this.end,
    this.start,
    required this.position,
  }) : super(key: key);

  @override
  State<PinEntry> createState() => _PinEntryState();
}

class _PinEntryState extends State<PinEntry> {
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: width * 0.1,
      child: InkWell(
        onTap: () {
          widget.onTap.call();
        },
        child: IgnorePointer(
          child: TextField(
              controller: widget.controller,
              focusNode: widget.focusNode,
              obscureText: !widget.showPin,
              readOnly: true,
              showCursor: true,
              textAlign: TextAlign.center,
              keyboardType: TextInputType.number,
              style:
                  const TextStyle(fontSize: 30, color: AppColors.pinFieldText),
              cursorColor: AppColors.cursorColor,
              decoration: InputDecoration(
                counterText: "",
                contentPadding: const EdgeInsets.all(5),
                fillColor: AppColors.lightWhite,
                filled: true,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(5),
                ),
                focusedBorder: const OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.transparent),
                ),
              )),
        ),
      ),
    );
  }
}
