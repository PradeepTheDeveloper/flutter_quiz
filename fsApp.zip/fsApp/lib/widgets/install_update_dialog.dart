import 'package:flutter/material.dart';
import '/constants/app_constants.dart';
import '/route/route.dart';

Future installUpdateDialog() {
  isAppUpdated = true;
  return showDialog(
      context: currentContext,
      builder: (context) {
        return Center(
          child: SizedBox(
            height: height * 0.15,
            width: width * 0.9,
            child: Material(
              child: DecoratedBox(
                decoration: BoxDecoration(
                    color: AppColors.white,
                    borderRadius: BorderRadius.circular(10)),
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      const Text(
                        AppStrings.installUpdateMessage,
                        textAlign: TextAlign.center,
                        style: AppStyles.dialogText,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          TextButton(
                            onPressed: () async {
                              pop();
                            },
                            child: const Text(
                              AppStrings.install,
                              style: TextStyle(
                                  color: AppColors.blue, fontSize: 20),
                            ),
                          ),
                          TextButton(
                            onPressed: () async {
                              pop();
                            },
                            child: const Text(
                              AppStrings.remindMeLater,
                              style:
                                  TextStyle(color: AppColors.red, fontSize: 20),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        );
      });
}
