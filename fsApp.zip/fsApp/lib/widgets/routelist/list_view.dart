import 'package:flutter/material.dart';
import 'package:fserv/constants/app_constants.dart';
import 'package:fserv/functions/appfunctions.dart';
import 'package:fserv/model/appmodels.dart';
import 'package:fserv/route/route.dart';
import 'package:fserv/screens/appscreens.dart';
import 'package:fserv/widgets/app_widgets.dart';

class AllRouteListView extends StatelessWidget {
  final List<CommunityRoutes> list;
  final MeterListType listType;
  const AllRouteListView({
    Key? key,
    required this.list,
    required this.listType,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
        itemCount: list.length,
        itemBuilder: (context, i) {
          int _progress = listType == MeterListType.todo
              ? (list[i].completedMeterCount ?? 0) +
                  (list[i].skipReasonMeterCount ?? 0)
              : listType == MeterListType.completed
                  ? list[i].completedMeterCount ?? 0
                  : list[i].skipReasonMeterCount ?? 0;
          return InkWell(
              child: RouteTodoCard(
                name: list[i].meterLocationName,
                inProgress: _progress,
                total: list[i].meterCount,
              ),
              onTap: () async {
                if (await checkCommunityAccess(list[i].communityID)) {
                  allRoutesGlobal = true;

                  meterLocationID = list[i].meterLocationID;
                  meterLocationName = list[i].meterLocationName;
                  showLoader(LoaderStrings.pleaseWait);
                  await getMeter(
                    routeId: meterLocationID,
                    communityId: selectedCommunityID,
                  ).then((value) {
                    if (value.statusCode == 200 && meterList.isNotEmpty) {
                      meterListType = listType;
                      if (currentMeterList.isNotEmpty) {
                        routeWithRemove(page: Reading.routeNamed);
                      } else {
                        pop();
                      }
                    } else {
                      pop();
                    }
                  });
                }
              });
        });
  }
}

class MyRouteListView extends StatelessWidget {
  final List<CommunityRoutes> list;
  final Map<int, MyRoutes>? myMeterList;
  final MeterListType listType;
  const MyRouteListView({
    Key? key,
    required this.list,
    required this.myMeterList,
    required this.listType,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: list.length,
      itemBuilder: (context, i) {
        int _progress = listType == MeterListType.todo
            ? (myMeterList![list[i].meterLocationID]!
                    .readingCompletedMeterIDs
                    .length) +
                (myMeterList![list[i].meterLocationID]!.skippedMeterIDs.length)
            : listType == MeterListType.completed
                ? myMeterList![list[i].meterLocationID]!
                    .readingCompletedMeterIDs
                    .length
                : myMeterList![list[i].meterLocationID]!.skippedMeterIDs.length;
        return InkWell(
          child: RouteTodoCard(
            name: list[i].meterLocationName,
            inProgress: _progress,
            total: myMeterList![list[i].meterLocationID]!.meterIDs.length,
          ),
          onTap: () async {
            if (await checkCommunityAccess(list[i].communityID)) {
              allRoutesGlobal = false;

              meterLocationID = list[i].meterLocationID;
              meterLocationName = list[i].meterLocationName;
              showLoader(LoaderStrings.pleaseWait);

              await getMeter(
                routeId: meterLocationID,
                communityId: selectedCommunityID,
              ).then(
                (value) {
                  if (value.statusCode == 200 && meterList.isNotEmpty) {
                    meterListType = listType;
                    if (currentMeterList.isNotEmpty) {
                      routeWithRemove(page: Reading.routeNamed);
                    } else {
                      pop();
                    }
                  }
                },
              );
            }
          },
        );
      },
    );
  }
}
