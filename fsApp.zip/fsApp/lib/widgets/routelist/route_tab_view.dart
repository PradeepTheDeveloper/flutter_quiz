import 'package:flutter/material.dart';
import 'package:fserv/constants/app_constants.dart';
import 'package:fserv/model/appmodels.dart';
import 'package:fserv/widgets/routelist/list_view.dart';

class AllRouteListTab extends StatelessWidget {
  final List<CommunityRoutes>? list;
  final TabController controller;
  const AllRouteListTab(
      {Key? key, required this.list, required this.controller})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    List<CommunityRoutes>? _todoList = list != null
        ? list!
            .where((element) =>
                ((element.completedMeterCount ?? 0) +
                    (element.skipReasonMeterCount ?? 0)) <
                element.meterCount)
            .toList()
        : null;

    List<CommunityRoutes>? _skippedList = list != null
        ? list!
            .where((element) => ((element.skipReasonMeterCount ?? 0) > 0))
            .toList()
        : null;
    List<CommunityRoutes>? _completedList = list != null
        ? list!
            .where((element) => (element.completedMeterCount ?? 0) > 0)
            .toList()
        : null;

    return TabBarView(
      controller: controller,
      children: [
        _todoList == null
            ? const Center(child: Text(RoutesTabMessages.connectInternet))
            : _todoList.isEmpty
                ? const Center(child: Text(RoutesTabMessages.noRoutes))
                : AllRouteListView(
                    list: _todoList,
                    listType: MeterListType.todo,
                  ),
        _completedList == null
            ? const Center(child: Text(RoutesTabMessages.connectInternet))
            : _completedList.isEmpty
                ? const Center(child: Text(RoutesTabMessages.noCompletedRoutes))
                : AllRouteListView(
                    list: _completedList,
                    listType: MeterListType.completed,
                  ),
        _skippedList == null
            ? const Center(child: Text(RoutesTabMessages.connectInternet))
            : _skippedList.isEmpty
                ? const Center(child: Text(RoutesTabMessages.noSkippedRoutes))
                : AllRouteListView(
                    list: _skippedList,
                    listType: MeterListType.skipped,
                  ),
      ],
    );
  }
}

class MyRouteListTab extends StatelessWidget {
  final Map<int, MyRoutes>? meterList;
  final TabController controller;
  const MyRouteListTab({
    Key? key,
    required this.meterList,
    required this.controller,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Map<int, MyRoutes>? _skippedList = meterList != null
        ? {
            for (var e in meterList!.values.where((element) =>
                element.skippedMeterIDs.isNotEmpty &&
                !(element.skippedMeterIDs.any(
                  (e) => element.readingCompletedMeterIDs.contains(e),
                ))))
              e.meterLocationID: e
          }
        : null;

    Map<int, MyRoutes>? _completedList = meterList != null
        ? {
            for (var e in meterList!.values.where(
                (element) => element.readingCompletedMeterIDs.isNotEmpty))
              e.meterLocationID: e
          }
        : null;
    Map<int, MyRoutes>? _todoList = meterList != null
        ? {
            for (var e in meterList!.values.where((element) {
              return ((_skippedList?[element.meterLocationID]
                              ?.skippedMeterIDs
                              .length ??
                          0) +
                      (_completedList?[element.meterLocationID]
                              ?.readingCompletedMeterIDs
                              .length ??
                          0) <
                  meterList![element.meterLocationID]!.meterIDs.length);
            }))
              e.meterLocationID: e
          }
        : null;
    return TabBarView(
      controller: controller,
      children: [
        _todoList == null
            ? const Center(child: Text(RoutesTabMessages.connectInternet))
            : _todoList.isEmpty
                ? const Center(child: Text(RoutesTabMessages.noAssignedRoutes))
                : MyRouteListView(
                    myMeterList: meterList,
                    list: _todoList.keys.map((e) => routeList![e]!).toList(),
                    listType: MeterListType.todo,
                  ),
        _completedList == null
            ? const Center(child: Text(RoutesTabMessages.connectInternet))
            : _completedList.isEmpty
                ? const Center(child: Text(RoutesTabMessages.noCompletedRoutes))
                : MyRouteListView(
                    myMeterList: meterList,
                    listType: MeterListType.completed,
                    list:
                        _completedList.keys.map((e) => routeList![e]!).toList(),
                  ),
        _skippedList == null
            ? const Center(child: Text(RoutesTabMessages.connectInternet))
            : _skippedList.isEmpty
                ? const Center(child: Text(RoutesTabMessages.noSkippedRoutes))
                : MyRouteListView(
                    myMeterList: meterList,
                    listType: MeterListType.skipped,
                    list: _skippedList.keys.map((e) => routeList![e]!).toList(),
                  ),
      ],
    );
  }
}
