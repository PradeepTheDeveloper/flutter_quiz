import 'package:flutter/material.dart';
import 'package:fserv/constants/app_constants.dart';

class RouteTodoCard extends StatelessWidget {
  final String name;
  final int inProgress;
  final int total;
  const RouteTodoCard(
      {Key? key,
      required this.name,
      required this.inProgress,
      required this.total})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    double percentage = total != 0 ? inProgress / total : 1;
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: SizedBox(
        width: width * 0.9,
        child: DecoratedBox(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              gradient: LinearGradient(
                  colors: [
                    AppColors.green.withOpacity(0.5),
                    AppColors.routeListCardColor,
                  ],
                  tileMode: TileMode.clamp,
                  stops: [percentage, percentage - 1]),
              color: AppColors.routeListCardColor,
            ),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 15),
              child: Center(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        if (percentage == 1)
                          const Padding(
                            padding: EdgeInsets.only(right: 6),
                            child: Icon(
                              Icons.check_circle,
                              color: AppColors.iconColor,
                            ),
                          ),
                        SizedBox(
                          width: width * 0.65,
                          child: Text(
                            name,
                            style: AppStyles.routeCardTitle,
                          ),
                        ),
                      ],
                    ),
                    Text(
                      "$inProgress/$total",
                      style: percentage == 1
                          ? AppStyles.routeCardTitle.copyWith(fontSize: 14)
                          : AppStyles.routeCardStatus,
                    ),
                  ],
                ),
              ),
            )),
      ),
    );
  }
}
