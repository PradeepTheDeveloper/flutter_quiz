import 'package:flutter/material.dart';
import 'package:fserv/constants/styles.dart';
import 'package:fserv/widgets/text.dart';

class TitleValueText extends StatelessWidget {
  final String label;
  final String value;
  const TitleValueText({Key? key, required this.label, required this.value})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          Expanded(
            child: Padding(
              padding:
                  const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
              child: TextWidget(
                  text: label, style: AppStyles.readPageMeterTextStyle),
            ),
          ),
          Expanded(
            child: Padding(
              padding:
                  const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
              child: TextWidget(
                text: value,
                textAlign: TextAlign.right,
                style: AppStyles.readPagelightWhiteTextStyle,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
