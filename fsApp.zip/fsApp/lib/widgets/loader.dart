import 'package:flutter/material.dart';
import 'package:fserv/constants/app_constants.dart';
import 'package:fserv/widgets/app_widgets.dart';

Future showLoader(
  String text,
) {
  return showDialog(
    context: currentContext,
    barrierDismissible: false,
    builder: (BuildContext context) {
      return WillPopScope(
        onWillPop: () async => false,
        child: Scaffold(
          backgroundColor: Colors.black.withOpacity(0.2),
          body: Material(
            color: Colors.black.withOpacity(0.2),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const Spinner(
                  size: 50,
                  color: AppColors.pinFieldFocus,
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Text(
                    text,
                    textAlign: TextAlign.center,
                    style: AppStyles.boldHeading,
                  ),
                )
              ],
            ),
          ),
        ),
      );
    },
  );
}
