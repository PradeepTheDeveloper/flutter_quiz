import 'package:flutter/material.dart';
import 'package:fserv/constants/app_constants.dart';
import 'dart:math' as math show pi;
import 'package:fserv/widgets/app_widgets.dart';

class CustomAppBar extends StatelessWidget {
  final String title;
  final TextStyle titleStyle;
  final IconData? leadinIcon;
  final IconData? trailingIcon;
  final VoidCallback? leadingOnTap;
  final VoidCallback? trailingOnTap;
  final VoidCallback? titleOnTap;

  const CustomAppBar(
      {Key? key,
      required this.title,
      required this.titleStyle,
      this.leadinIcon,
      this.trailingIcon,
      this.leadingOnTap,
      this.trailingOnTap,
      this.titleOnTap})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return AppBar(
      title: InkWell(
          onTap: titleOnTap, child: TextWidget(text: title, style: titleStyle)),
      backgroundColor: AppColors.appBarColor,
      centerTitle: true,
      leading: InkWell(
        child: Icon(
          leadinIcon,
          size: 25,
        ),
        onTap: leadingOnTap,
      ),
      actions: [
        Transform.rotate(
          angle: math.pi / 4,
          child: InkWell(
            child: Icon(
              trailingIcon,
              size: 36,
            ),
            onTap: trailingOnTap,
          ),
        )
      ],
    );
  }
}
