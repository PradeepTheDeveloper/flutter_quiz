import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fserv/constants/app_constants.dart';
import 'package:fserv/widgets/app_widgets.dart';

class Footer extends StatelessWidget {
  const Footer({
    Key? key,
    required this.height,
  }) : super(key: key);

  final double height;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () async {
        await const MethodChannel('urlLaunch')
            .invokeMethod("launchUrl", urlToLaunch(AppStrings.starnikUrl));
      },
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          const TextWidget(
            text: AppStrings.powerText,
            style: AppStyles.footerStyle,
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8.0),
            child: SizedBox(
                height: height * 0.02, child: Image.asset(Images.footerLogo)),
          ),
        ],
      ),
    );
  }
}
