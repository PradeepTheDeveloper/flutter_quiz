import 'package:flutter/material.dart';
import 'package:fserv/constants/app_constants.dart';
import 'package:fserv/functions/api_functions/get_all_list.dart';
import 'package:fserv/functions/appfunctions.dart';

class DropDown extends StatelessWidget {
  final double width;
  final Color dropdownColor;
  final Color bgColor;
  final TextStyle tStyle;
  final List<String> list;

  const DropDown(
      {Key? key,
      required this.width,
      required this.list,
      required this.dropdownColor,
      required this.bgColor,
      required this.tStyle})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: width,
      child: DecoratedBox(
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(5), color: bgColor),
        child: DropdownButton<String>(
          style: DropDownStyles.lable,
          borderRadius: BorderRadius.circular(5),
          isDense: true,
          isExpanded: true,
          value: communityList[selectedCommunityID]!.communityName,
          dropdownColor: dropdownColor,
          icon: const Icon(
            Icons.keyboard_arrow_down_outlined,
            color: Colors.black,
          ),
          iconSize: 40,
          elevation: 0,
          onChanged: (v) async {
            selectedCommunityID = communityList.values
                .firstWhere((e) => e.communityName == v)
                .communityID;

            if (await checkCommunityAccess(selectedCommunityID)) {
              await getAllListInCommunity(hasAccess: true);
            }
          },
          items: List.generate(
            list.length,
            (index) => DropdownMenuItem(
              child: Padding(
                padding: EdgeInsets.all(height * 0.006),
                child: Text(
                  list[index],
                  style: tStyle,
                ),
              ),
              value: list[index],
            ),
          ),
        ),
      ),
    );
  }
}
