import 'package:flutter/material.dart';
import 'package:fserv/constants/app_constants.dart';
import 'package:fserv/widgets/app_widgets.dart';

snackBar(String text, {int duration = 2}) {
  final snackBar = SnackBar(
    margin: EdgeInsets.only(
        bottom: height * 0.02, left: width * 0.05, right: width * 0.05),
    behavior: SnackBarBehavior.floating,
    content: TextWidget(
      text: text,
      textAlign: TextAlign.center,
      style: AppStyles.footerStyle.copyWith(
        fontSize: 16,
        color: AppColors.black,
        fontWeight: FontWeight.w500,
      ),
    ),
    duration: Duration(seconds: duration),
    backgroundColor: AppColors.white,
  );
  ScaffoldMessenger.of(currentContext).showSnackBar(snackBar);
}

removeSnackBar(context) {
  ScaffoldMessenger.of(currentContext).removeCurrentSnackBar();
}
