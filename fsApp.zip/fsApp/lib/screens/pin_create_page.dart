import 'package:flutter/material.dart';
import '/bloc/app_bloc.dart';
import '/config/appconfigs.dart';
import '/constants/app_constants.dart';
import '/route/route.dart';
import '/screens/appscreens.dart';
import '/widgets/app_widgets.dart';

class PinCreate extends StatefulWidget {
  static const routeNamed = '/PinCreate';

  const PinCreate({Key? key}) : super(key: key);

  @override
  State<PinCreate> createState() => _PinCreateState();
}

class _PinCreateState extends State<PinCreate> {
  late String _pin1;
  late String _pin2;

  late AppBloc<bool> _keyBoardBloc;
  late AppBloc<bool> _showPinBloc;
  late AppBloc<TextEditingController> _controlBloc;

  late ScrollController _scrollController;
  late List<TextEditingController> _createPinControllers;
  late List<TextEditingController> _reenterPinControllers;
  late List<FocusNode> _createPinFocusNodes;
  late List<FocusNode> _reenterPinFocusnodes;

  @override
  void initState() {
    _createPinControllers =
        List.generate(4, (index) => TextEditingController());
    _reenterPinControllers =
        List.generate(4, (index) => TextEditingController());
    _createPinFocusNodes = List.generate(4, (index) => FocusNode());
    _reenterPinFocusnodes = List.generate(4, (index) => FocusNode());
    _scrollController = ScrollController();
    _pin1 = "";
    _pin2 = "";
    _keyBoardBloc = AppBloc<bool>()..data = false;
    _showPinBloc = AppBloc<bool>()..data = false;
    _controlBloc = AppBloc<TextEditingController>()
      ..data = TextEditingController();
    super.initState();
  }

  @override
  void dispose() {
    for (TextEditingController element in _createPinControllers) {
      element.dispose();
    }
    for (TextEditingController element in _reenterPinControllers) {
      element.dispose();
    }
    for (FocusNode element in _createPinFocusNodes) {
      element.dispose();
    }
    for (FocusNode element in _reenterPinFocusnodes) {
      element.dispose();
    }
    _keyBoardBloc.close();
    _showPinBloc.close();
    _controlBloc.close();
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    currentContext = context;
    return DoubleBackToClose(
      keyBoardVisibility: _keyBoardBloc,
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        body: _controlBloc.stream((context) {
          return AppKeyBoard(
              maxLength: 1,
              allowDecimal: false,
              allowNegative: false,
              keyboardBloc: _keyBoardBloc,
              controller: _controlBloc.data!,
              onDone: () {
                _keyBoardBloc.change(false);
                submitGo();
              },
              save: false,
              child: _keyBoardBloc.stream(
                ((context) {
                  return ScrollConfiguration(
                    behavior: ScrollConfig(),
                    child: SingleChildScrollView(
                      child: Padding(
                        padding: EdgeInsets.only(
                          top: 16,
                          bottom: _keyBoardBloc.data!
                              ? height * 0.4
                              : height * 0.25,
                        ),
                        child: Column(
                          children: [
                            const SafeArea(child: LogoHeader()),
                            const LoggedUser(),
                            Padding(
                              padding: EdgeInsets.only(
                                  bottom: 15, top: height * 0.01),
                              child: TextWidget(
                                text: AppStrings.createPin,
                                style: AppStyles.pinTextStyle,
                              ),
                            ),
                            const SizedBox(
                              height: 10.0,
                            ),
                            LoginPin(
                              showPinBloc: _showPinBloc,
                              controllers: _createPinControllers,
                              focusNodes: _createPinFocusNodes,
                              onTap: (TextEditingController controller) {
                                _controlBloc.change(controller);
                                _keyBoardBloc.change(true);
                              },
                              onComplete: (pin) {
                                _pin1 = pin;
                                _keyBoardBloc.change(false);
                              },
                              onChanged: (pin) {
                                _pin1 = pin;
                              },
                            ),
                            Padding(
                              padding: const EdgeInsets.symmetric(vertical: 15),
                              child: TextWidget(
                                text: AppStrings.reEnterPin,
                                style: AppStyles.pinTextStyle,
                              ),
                            ),
                            LoginPin(
                              showPinBloc: _showPinBloc,
                              controllers: _reenterPinControllers,
                              focusNodes: _reenterPinFocusnodes,
                              onTap: (TextEditingController controller) {
                                _controlBloc.change(controller);
                                _keyBoardBloc.change(true);
                              },
                              onComplete: (pin) async {
                                _pin2 = pin;
                                _keyBoardBloc.change(false);
                                await Future.delayed(
                                    const Duration(milliseconds: 300));

                                submitGo();
                              },
                              onChanged: (pin) {
                                _pin2 = pin;
                              },
                            ),
                            _showPinBloc.stream((context) {
                              return Padding(
                                padding: const EdgeInsets.only(top: 40),
                                child: Row(
                                  children: [
                                    const Spacer(),
                                    InkWell(
                                      splashColor: Colors.transparent,
                                      enableFeedback: false,
                                      onTap: () {
                                        _showPinBloc
                                            .change(!_showPinBloc.data!);
                                      },
                                      child: Row(
                                        children: [
                                          Icon(_showPinBloc.data!
                                              ? Icons.visibility_off_rounded
                                              : Icons.visibility_rounded),
                                          Padding(
                                            padding:
                                                const EdgeInsets.only(left: 8),
                                            child: TextWidget(
                                              text: !_showPinBloc.data!
                                                  ? AppStrings.showPin
                                                  : AppStrings.hidePin,
                                              style: AppStyles.boldHeading,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    const Spacer()
                                  ],
                                ),
                              );
                            }),
                            Padding(
                              padding: EdgeInsets.symmetric(
                                  horizontal: width * 0.05, vertical: 12),
                              child: Button(
                                height: height * 0.06,
                                width: width * 0.9,
                                text: AppStrings.submitGo,
                                tStyle: AppStyles.buttonStyle,
                                onPress: () {
                                  submitGo();
                                },
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                }),
              ));
        }),
      ),
    );
  }

  void submitGo() async {
    if (_pin1.length == 4 && _pin2.length == 4 && _pin1 == _pin2) {
      loginPin = _pin1;
      CacheStorage.storeString(SecureStorageKeys.loginPin, _pin1);
      pinCreated = true;
      CacheStorage.storeBool(SecureStorageKeys.pinCreated, pinCreated);

      routeWithRemove(page: PinLoginPage.routeNamed);
    } else if (_pin1.length == 4 && _pin2.length == 4 && _pin1 != _pin2) {
      routeWithRemove(page: PinCreate.routeNamed);
      snackBar(SnackBarMessages.pinsNotMatch);
    } else {
      snackBar(SnackBarMessages.enterValidPin);
    }
  }
}
