import 'package:flutter/material.dart';
import 'package:fserv/screens/appscreens.dart';
import 'package:get/get.dart';
import '../../model/work_order_taskbin.dart';
import '../../widgets/create_work_order/work_order_taskbin_card.dart';
import '/widgets/app_widgets.dart';
import '../../constants/app_constants.dart';
import '../../route/route.dart';

class WorkOrderDashBoard extends StatefulWidget {
  const WorkOrderDashBoard({Key? key}) : super(key: key);
  final String title = Pages.workOrderDashBoard;
  static const routeNamed = '/WorkOrderDashBoard';

  @override
  State<WorkOrderDashBoard> createState() => _WorkOrderDashBoardState();
}

class _WorkOrderDashBoardState extends State<WorkOrderDashBoard> {
  @override
  Widget build(BuildContext context) {
    return DoubleBackToClose(
      child: Scaffold(
        backgroundColor: AppColors.appBackgroundColor,
        body: Column(
          children: [
            Container(
              height: height * 0.15,
              decoration: const BoxDecoration(
                color: AppColors.green,
                borderRadius: BorderRadius.only(
                  bottomLeft: Radius.circular(20),
                  bottomRight: Radius.circular(20),
                ),
              ),
              child: Padding(
                padding: const EdgeInsets.all(10.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    const Text(
                      AppStrings.workOrders,
                      style: AppStyles.workOrder,
                    ),
                    InkWell(
                      onTap: () {
                        routeWithoutRemove(
                            page: SettingsPage.routeNamed,
                            arguments: WorkOrderDashBoard.routeNamed);
                      },
                      child: const Icon(
                        Icons.settings_outlined,
                        color: AppColors.grey,
                        size: 25,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Expanded(
              child: ListView.builder(
                itemCount: taskBinList.length,
                itemBuilder: (context, index) {
                  TaskBin workOrder = taskBinList[index];
                  return GestureDetector(
                      onTap: () {
                        int id = workOrder.taskbinID;
                        debugPrint('Clicked ID: $id');
                        Get.snackbar(
                            "${workOrder.taskbinID}", workOrder.taskbinName,
                            backgroundColor: AppColors.blue);
                      },
                      child: WorkOrderTaskbinCard(workOrder: workOrder));
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
