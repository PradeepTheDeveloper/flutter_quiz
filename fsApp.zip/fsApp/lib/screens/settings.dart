import 'package:flutter/material.dart';
import 'package:fserv/screens/appscreens.dart';
import 'package:get/get.dart';
import '../functions/api_functions/wo_dashboard_api_function.dart';
import '../functions/meter_read_dashboard_data.dart';
import '/constants/app_constants.dart';
import '/functions/api_functions/add_skip_reason.dart';
import '/functions/appfunctions.dart';
import '/widgets/app_widgets.dart';
import '/route/route.dart';

class SettingsPage extends StatelessWidget {
  static const routeNamed = "/SettingsPage";
  late final dynamic returnPage;
  SettingsPage(this.returnPage, {Key? key}) : super(key: key);
  final String title = Pages.settings;

  @override
  Widget build(BuildContext context) {
    currentContext = context;

    return WillPopScope(
      onWillPop: () async {
        routeWithRemove(page: Get.arguments);

        return false;
      },
      child: Scaffold(
        appBar: AppBar(
            leading: GestureDetector(
                onTap: () {
                  routeWithRemove(page: Get.arguments);
                },
                child: const Icon(
                  Icons.arrow_back,
                )),
            title: const TextWidget(
              text: AppStrings.settings,
              style: AppStyles.appBarTextStyle,
            )),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Button(
                  width: width * 0.6,
                  height: height * 0.06,
                  onPress: () async {
                    showLoader(LoaderStrings.pleaseWait);
                    await getMeterReadDashBoardData(Dashboard.routeNamed);
                  },
                  text: AppStrings.gatherReadings,
                  tStyle: AppStyles.buttonStyle,
                ),
                const SizedBox(
                  height: 25,
                ),
                Button(
                  width: width * 0.6,
                  height: height * 0.06,
                  onPress: () async {
                    showLoader(LoaderStrings.pleaseWait);
                    await woDashboardAPIFunction(sync: true);
                    routeWithRemove(page: WorkOrderDashBoard.routeNamed);
                    // debugPrint('taskbinlist111 $taskBinList1');

                    
                  },
                  text: AppStrings.workOrders,
                  tStyle: AppStyles.buttonStyle,
                ),
                const SizedBox(
                  height: 25,
                ),
                Button(
                  width: width * 0.6,
                  height: height * 0.06,
                  onPress: () {},
                  text: AppStrings.completedWorkOrder,
                  tStyle: AppStyles.buttonStyle,
                ),
                const SizedBox(
                  height: 20,
                ),
                const Divider(
                  color: AppColors
                      .lightWhite, // Customize the color of the divider
                  thickness: 1, // Specify the thickness of the divider
                ),
                const SizedBox(
                  height: 20,
                ),
                Button(
                  width: width * 0.6,
                  height: height * 0.06,
                  onPress: () async {
                    showLoader(LoaderStrings.pleaseWait);
                    if (await hasNetwork()) {
                      await addMeterReading(
                        sync: true,
                        returnIfSuccess: true,
                      ).then((value) async {
                        if (value) {
                          await addSkipReason(
                            sync: true,
                            returnIfSuccess: true,
                          ).then((value) async {
                            if (value) {
                              await createWorkOrder(
                                sync: true,
                                returnIfSuccess: true,
                              ).then((value) async {
                                if (value) {
                                  await unregisterUser();
                                } else {
                                  pop();
                                }
                              });
                            } else {
                              pop();
                            }
                          });
                        } else {
                          pop();
                        }
                      });
                    } else {
                      pop();
                      snackBar(SnackBarMessages.checkInternetDataPush);
                    }
                  },
                  text: AppStrings.deleteUser,
                  tStyle: AppStyles.buttonStyle,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
