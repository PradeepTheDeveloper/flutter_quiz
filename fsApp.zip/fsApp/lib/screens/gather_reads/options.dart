import 'package:flutter/material.dart';
import 'package:fserv/bloc/app_bloc.dart';
import 'package:fserv/constants/app_constants.dart';
import 'package:fserv/widgets/app_widgets.dart';

class Options extends StatefulWidget {
  final VoidCallback onApply;

  const Options({
    Key? key,
    required this.onApply,
  }) : super(key: key);

  @override
  State<Options> createState() => _OptionsState();
}

class _OptionsState extends State<Options> {
  late final AppBloc<bool> _routeOrderBloc;
  late final AppBloc<bool> _ascendingSortBloc;

  @override
  void initState() {
    _routeOrderBloc = AppBloc<bool>()..data = routeOrder;
    _ascendingSortBloc = AppBloc<bool>()..data = ascendingOrder;
    super.initState();
  }

  @override
  void dispose() {
    _routeOrderBloc.close();
    _ascendingSortBloc.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: height * 0.35,
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 16.0),
            child: TextWidget(
                text: AppStrings.advancedOptions,
                style: AppStyles.boldHeading.copyWith(fontSize: 18)),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(AppStrings.sortBy, style: AppStyles.subHeading),
                _ascendingSortBloc.stream((context) {
                  return IconButton(
                    onPressed: () {
                      ascendingOrder = !ascendingOrder;
                      _ascendingSortBloc.change(ascendingOrder);
                    },
                    icon: ImageIcon(
                      AssetImage(
                        _ascendingSortBloc.data!
                            ? CustomIcon.ascending
                            : CustomIcon.descending,
                      ),
                    ),
                  );
                })
              ],
            ),
          ),
          _routeOrderBloc.stream((context) => Padding(
                padding: EdgeInsets.symmetric(vertical: height * 0.01),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    InkWell(
                      onTap: () {
                        routeOrder = true;

                        _routeOrderBloc.change(routeOrder);
                      },
                      child: Chip(
                        padding: EdgeInsets.all(width * 0.025),
                        backgroundColor: _routeOrderBloc.data!
                            ? AppColors.yellow
                            : Colors.transparent,
                        label: TextWidget(
                            text: AppStrings.routeOrder,
                            style: AppStyles.subHeading.copyWith(
                                color: _routeOrderBloc.data!
                                    ? Colors.black
                                    : Colors.white,
                                fontWeight: FontWeight.bold)),
                      ),
                    ),
                    InkWell(
                      onTap: () {
                        routeOrder = false;

                        _routeOrderBloc.change(routeOrder);
                      },
                      child: Chip(
                        padding: EdgeInsets.all(width * 0.025),
                        backgroundColor: _routeOrderBloc.data!
                            ? Colors.transparent
                            : AppColors.yellow,
                        label: TextWidget(
                            text: AppStrings.altRouteOrder,
                            style: AppStyles.subHeading.copyWith(
                                color: _routeOrderBloc.data!
                                    ? Colors.white
                                    : Colors.black,
                                fontWeight: FontWeight.bold)),
                      ),
                    ),
                  ],
                ),
              )),
          Padding(
            padding: EdgeInsets.only(top: height * 0.04),
            child: Button(
                width: width * 0.9,
                height: height * 0.05,
                onPress: widget.onApply,
                text: AppStrings.apply,
                tStyle: AppStyles.buttonStyle),
          )
        ],
      ),
    );
  }
}
