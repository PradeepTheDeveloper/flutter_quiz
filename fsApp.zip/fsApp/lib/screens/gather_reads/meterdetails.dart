import 'package:flutter/material.dart';
import 'package:fserv/constants/app_constants.dart';
import 'package:fserv/functions/int_to_string.dart';
import 'package:fserv/model/meter.dart';
import 'package:fserv/widgets/text.dart';

class MeterDetails extends StatelessWidget {
  final Meter info;
  const MeterDetails({Key? key, required this.info}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Flexible(
      child: SizedBox(
        width: width * 0.7,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 16.0),
              child: RichText(
                textAlign: TextAlign.center,
                text: TextSpan(
                    text: info.meterNo,
                    style: AppStyles.appBarTextStyle,
                    children: [
                      TextSpan(
                          text: "\n(ID: ${intToString(info.meterID)})",
                          style: AppStyles.subHeading
                              .copyWith(color: AppColors.white, fontSize: 18))
                    ]),
              ),
            ),
            const Padding(
              padding: EdgeInsets.only(top: 20),
              child: TextWidget(
                  text: AppStrings.address,
                  style: AppStyles.readPageMeterTextStyle),
            ),
            Padding(
              padding:
                  const EdgeInsets.symmetric(vertical: 8.0, horizontal: 32.0),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  if (info.addressLineOne != null)
                    if (info.addressLineOne!.isNotEmpty)
                      Text(
                        "${info.addressLineOne},",
                        style: AppStyles.readPagelightWhiteTextStyle,
                        textAlign: TextAlign.center,
                      ),
                  if (info.addressLineTwo != null)
                    if (info.addressLineTwo!.isNotEmpty)
                      Text(
                        "${info.addressLineTwo},",
                        style: AppStyles.readPagelightWhiteTextStyle,
                        textAlign: TextAlign.center,
                      ),
                  if (info.addressLineThree != null)
                    if (info.addressLineThree!.isNotEmpty)
                      Text(
                        "${info.addressLineThree},",
                        style: AppStyles.readPagelightWhiteTextStyle,
                        textAlign: TextAlign.center,
                      ),
                  if ((info.city ?? "").isNotEmpty ||
                      (info.state ?? "").isNotEmpty ||
                      (info.zip5 ?? "").isNotEmpty)
                    Text(
                      "${info.city}, ${info.state} ${info.zip5}${(info.zip4 ?? "").isNotEmpty ? " - ${info.zip4}" : ""}",
                      style: AppStyles.readPagelightWhiteTextStyle,
                      textAlign: TextAlign.center,
                    ),
                ],
              ),
            ),
            const Padding(
              padding: EdgeInsets.only(top: 20),
              child: TextWidget(
                  text: AppStrings.premise,
                  style: AppStyles.readPageMeterTextStyle),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: TextWidget(
                  text: info.apartmentName ?? "-",
                  textAlign: TextAlign.center,
                  style: AppStyles.readPagelightWhiteTextStyle),
            ),
            const Padding(
              padding: EdgeInsets.only(top: 20),
              child: TextWidget(
                  text: AppStrings.accountName,
                  style: AppStyles.readPageMeterTextStyle),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 8, bottom: 20),
              child: TextWidget(
                  text: info.residentName ?? "-",
                  textAlign: TextAlign.center,
                  style: AppStyles.readPagelightWhiteTextStyle),
            ),
          ],
        ),
      ),
    );
  }
}
