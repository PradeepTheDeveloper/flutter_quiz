import 'package:flutter/material.dart';
import 'package:fserv/screens/gather_reads/meter_list_view.dart';
import '../../functions/appfunctions.dart';
import '/bloc/app_bloc.dart';
import '/constants/app_constants.dart';
import '/functions/search_in_meter_list.dart';
import '/widgets/app_widgets.dart';
import '../../route/route.dart';
import 'options.dart';

enum SearchListOptions { cleared, result, onSearch, noResult }

enum SearchBy { meterNo, address }

class MeterListSheet extends StatefulWidget {
  final ValueSetter<int> onSelect;

  const MeterListSheet({Key? key, required this.onSelect}) : super(key: key);

  @override
  State<MeterListSheet> createState() => _MeterListSheetState();
}

class _MeterListSheetState extends State<MeterListSheet>
    with TickerProviderStateMixin {
  late final TextEditingController _searchController;
  late final FocusNode _searchFocusNode;
  late AppBloc<List<int>> _todoBloc;
  late AppBloc<List<int>> _completedBloc;
  late AppBloc<List<int>> _skippedBloc;
  late AppBloc<SearchListOptions> _searchBloc;
  late AppBloc<SearchBy> _searchByMeterBloc;
  late final TabController _meterListTabController;
  late final TabController _searchByTabController;
  late int tabIndex = 0;
  List<int> _searchList = [];
  @override
  void initState() {
    super.initState();
    _searchFocusNode = FocusNode();
    _searchController = TextEditingController();
    _todoBloc = AppBloc<List<int>>()..data = todoMeterList;
    _searchBloc = AppBloc<SearchListOptions>()
      ..data = SearchListOptions.cleared;
    _searchByMeterBloc = AppBloc<SearchBy>()..data = SearchBy.address;
    _completedBloc = AppBloc<List<int>>()..data = completedMeterList;
    _skippedBloc = AppBloc<List<int>>()..data = skippedMeterList;
    _meterListTabController = TabController(
      initialIndex: meterListType.index,
      length: 3,
      vsync: this,
    );
    _searchByTabController = TabController(
      initialIndex: 0,
      length: 2,
      vsync: this,
    );
    _searchByTabController.addListener(searchControllerChange);
    _meterListTabController.addListener(meterControllerChange);
  }

  searchControllerChange() {
    _searchController.clear();
    _searchByMeterBloc.change(_searchByTabController.index == 1
        ? SearchBy.meterNo
        : SearchBy.address);
  }

  meterControllerChange() {
    tabIndex = _meterListTabController.index;
  }

  @override
  void dispose() {
    _searchFocusNode.dispose();
    _searchController.dispose();
    _todoBloc.close();
    _searchBloc.close();
    _searchByMeterBloc.close();
    _completedBloc.close();
    _skippedBloc.close();
    _meterListTabController.dispose();
    _searchByTabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    currentContext = context;
    return Flexible(child: _searchBloc.stream((context) {
      return _searchByMeterBloc.stream((context) {
        return Padding(
          padding: EdgeInsets.only(bottom: bottomInset),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Padding(
                padding: EdgeInsets.all(height * 0.02),
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    if (_searchBloc.data == SearchListOptions.cleared ||
                        _searchBloc.data == SearchListOptions.result)
                      Align(
                          alignment: Alignment.centerRight,
                          child: IconButton(
                            onPressed: () {
                              showBottom(
                                context: context,
                                onTap: () {},
                                child: Options(
                                  onApply: () {
                                    sortList();
                                    updateList();

                                    _todoBloc.change(todoMeterList);
                                    _completedBloc.change(completedMeterList);
                                    _skippedBloc.change(skippedMeterList);

                                    widget.onSelect.call(meterID);
                                  },
                                ),
                              );
                            },
                            icon: const Icon(Icons.sort),
                          )),
                    if (_searchBloc.data == SearchListOptions.cleared)
                      Align(
                          alignment: Alignment.centerLeft,
                          child: IconButton(
                            onPressed: () {
                              _searchFocusNode.requestFocus();
                              _searchBloc.change(SearchListOptions.onSearch);
                            },
                            icon: const Icon(Icons.search),
                          )),
                    if (_searchBloc.data == SearchListOptions.result)
                      Align(
                          alignment: Alignment.centerLeft,
                          child: IconButton(
                            onPressed: () {
                              _searchBloc.change(SearchListOptions.cleared);
                            },
                            icon: const Icon(Icons.delete_sweep_rounded),
                          )),
                    Align(
                      alignment: Alignment.center,
                      child: Text(
                        (_searchBloc.data == SearchListOptions.cleared ||
                                _searchBloc.data == SearchListOptions.result)
                            ? "Meter List"
                            : AppStrings.search,
                        style: AppStyles.boldHeading
                            .copyWith(color: AppColors.lightgrey, fontSize: 18),
                      ),
                    )
                  ],
                ),
              ),
              if (_searchBloc.data == SearchListOptions.onSearch ||
                  _searchBloc.data == SearchListOptions.noResult)
                Padding(
                  padding: EdgeInsets.all(height * 0.01),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(
                        height: height * 0.06,
                        width: width * 0.55,
                        child: DecoratedBox(
                          decoration: BoxDecoration(
                            color: AppColors.lightWhite,
                            borderRadius: BorderRadius.circular(4.0),
                          ),
                          child: InputTextFormField(
                            controller: _searchController,
                            focusNode: _searchFocusNode,
                            color: AppColors.lightWhite,
                            autofocus: true,
                            width: width * 0.55,
                            maxLines: 1,
                            maxLength:
                                _searchByMeterBloc.data == SearchBy.meterNo
                                    ? 50
                                    : 100,
                            onSubmit: (value) {
                              conductsearch();
                            },
                            hint: _searchByMeterBloc.data == SearchBy.meterNo
                                ? AppStrings.meterNo
                                : AppStrings.address,
                            keyboardType: TextInputType.text,
                            textStyle: AppStyles.signInTextStyle,
                            alignText: TextAlign.center,
                          ),
                        ),
                      ),
                      Button(
                          width: width * 0.25,
                          height: height * 0.06,
                          onPress: () {
                            conductsearch();
                          },
                          text: AppStrings.search,
                          tStyle: AppStyles.buttonStyle.copyWith(fontSize: 18)),
                      SizedBox(
                        height: height * 0.06,
                        width: width * 0.1,
                        child: IconButton(
                          padding: EdgeInsets.only(right: width * 0.1),
                          onPressed: () {
                            _searchBloc.change(SearchListOptions.cleared);
                            _searchController.clear();
                          },
                          icon: const Icon(Icons.close),
                          iconSize: 24,
                        ),
                      ),
                    ],
                  ),
                ),
              if (_searchBloc.data == SearchListOptions.cleared ||
                  _searchBloc.data == SearchListOptions.result)
                SizedBox(
                    height: height * 0.4,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 15),
                      child: TabBarView(
                          controller: _meterListTabController,
                          children: [
                            _todoBloc.stream((context) {
                              List<int> _todo = [];
                              if (_searchBloc.data ==
                                  SearchListOptions.cleared) {
                                _todo = _todoBloc.data ?? [];
                              } else if (_searchBloc.data ==
                                  SearchListOptions.result) {
                                _todo = _searchList
                                    .where((element) =>
                                        _todoBloc.data!.contains(element))
                                    .toList();
                              }
                              return MeterListView(
                                onSelect: (int id) {
                                  meterListType = MeterListType.todo;
                                  widget.onSelect.call(id);
                                },
                                list: _todo,
                              );
                            }),
                            _completedBloc.stream((context) {
                              List<int> _completed = [];

                              if (_searchBloc.data ==
                                  SearchListOptions.cleared) {
                                _completed = _completedBloc.data ?? [];
                              } else if (_searchBloc.data ==
                                  SearchListOptions.result) {
                                _completed = _searchList
                                    .where((element) =>
                                        _completedBloc.data!.contains(element))
                                    .toList();
                              }
                              return MeterListView(
                                onSelect: (int id) {
                                  meterListType = MeterListType.completed;
                                  widget.onSelect.call(id);
                                },
                                list: _completed,
                              );
                            }),
                            _skippedBloc.stream((context) {
                              List<int> _skipped = [];

                              if (_searchBloc.data ==
                                  SearchListOptions.cleared) {
                                _skipped = _skippedBloc.data ?? [];
                              } else if (_searchBloc.data ==
                                  SearchListOptions.result) {
                                _skipped = _searchList
                                    .where((element) =>
                                        _skippedBloc.data!.contains(element))
                                    .toList();
                              }
                              return MeterListView(
                                onSelect: (int id) {
                                  meterListType = MeterListType.skipped;
                                  widget.onSelect.call(id);
                                },
                                list: _skipped,
                              );
                            }),
                          ]),
                    )),
              if (_searchBloc.data == SearchListOptions.noResult)
                Padding(
                  padding: EdgeInsets.symmetric(vertical: height * 0.04),
                  child: const Text(AppStrings.noMatchingRecordsFound),
                ),
              if (_searchBloc.data == SearchListOptions.onSearch ||
                  _searchBloc.data == SearchListOptions.noResult)
                Padding(
                  padding: EdgeInsets.only(left: height * 0.04),
                  child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      AppStrings.searchBy,
                      style: AppStyles.boldHeading
                          .copyWith(color: AppColors.lightgrey, fontSize: 18),
                    ),
                  ),
                ),
              SizedBox(
                height: height * 0.14,
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 20),
                  child: SizedBox(
                    height: height * 0.07,
                    width: width * 0.85,
                    child: DecoratedBox(
                      decoration: BoxDecoration(
                        color: AppColors.black,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: TabBar(
                          unselectedLabelColor: AppColors.inactiveTabText,
                          labelColor: AppColors.activeTabText,
                          labelStyle: AppStyles.tabTextStyle,
                          controller: _searchBloc.data ==
                                      SearchListOptions.onSearch ||
                                  _searchBloc.data == SearchListOptions.noResult
                              ? _searchByTabController
                              : _meterListTabController,
                          indicator: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              color: AppColors.activeTabColor),
                          tabs: [
                            Tab(
                              text: _searchBloc.data ==
                                          SearchListOptions.onSearch ||
                                      _searchBloc.data ==
                                          SearchListOptions.noResult
                                  ? AppStrings.address
                                  : AppStrings.todo,
                            ),
                            Tab(
                              text: _searchBloc.data ==
                                          SearchListOptions.onSearch ||
                                      _searchBloc.data ==
                                          SearchListOptions.noResult
                                  ? AppStrings.meterNo
                                  : AppStrings.completed,
                            ),
                            if (_searchBloc.data == SearchListOptions.cleared ||
                                _searchBloc.data == SearchListOptions.result)
                              const Tab(
                                text: AppStrings.skipped,
                              ),
                          ]),
                    ),
                  ),
                ),
              )
            ],
          ),
        );
      });
    }));
  }

  Future<void> conductsearch() async {
    if (_searchController.text.isNotEmpty) {
      showLoader(LoaderStrings.pleaseWait);
      _searchList = [];
      _searchList = searchInMeterList(_searchByMeterBloc.data!,
          meterList.keys.toList(), _searchController.text);

      pop();
      if (_searchList.length == 1) {
        if (_todoBloc.data!.contains(_searchList.first)) {
          meterListType = MeterListType.todo;
          widget.onSelect.call(_searchList.first);
        } else if (_completedBloc.data!.contains(_searchList.first)) {
          meterListType = MeterListType.completed;
          widget.onSelect.call(_searchList.first);
        } else if (_skippedBloc.data!.contains(_searchList.first)) {
          meterListType = MeterListType.skipped;
          widget.onSelect.call(_searchList.first);
        } else {
          _searchBloc.change(SearchListOptions.noResult);
        }
      } else if (_searchList.isEmpty) {
        _searchBloc.change(SearchListOptions.noResult);
      } else {
        if (_todoBloc.data!.contains(_searchList.first) == false &&
            _completedBloc.data!.contains(_searchList.first) == false &&
            _skippedBloc.data!.contains(_searchList.first) == false) {
          _searchBloc.change(SearchListOptions.noResult);
        } else {
          _searchController.clear();
          _searchBloc.change(SearchListOptions.result);
        }
      }
    } else {
      snackBar(
        AppStrings.pleaseEnterVaild(
          _searchByMeterBloc.data == SearchBy.meterNo
              ? AppStrings.meterNo
              : AppStrings.address,
        ),
      );
    }
  }
}
