import 'package:flutter/material.dart';
import '../../constants/variables.dart';
import '../../widgets/meter_list_card.dart';

class MeterListView extends StatelessWidget {
  final List<dynamic> list;
  final ValueSetter<int> onSelect;
  const MeterListView({Key? key, required this.list, required this.onSelect})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        children: [
          Expanded(
            flex: 6,
            child: ListView.builder(
              itemCount: list.length,
              itemBuilder: (context, i) => InkWell(
                  onTap: () async {
                    onSelect.call(list[i]);
                  },
                  child: MeterListCard(meter: meterList[list[i]]!)),
            ),
          ),
        ],
      ),
    );
  }
}
