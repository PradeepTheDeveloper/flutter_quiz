import 'package:flutter/material.dart';
import '/constants/app_constants.dart';
import '/functions/api_functions/add_skip_reason.dart';
import '/functions/api_functions/get_all_list.dart';
import '/functions/appfunctions.dart';
import '/route/route.dart';
import '/screens/appscreens.dart';
import '/widgets/app_widgets.dart';

class Dashboard extends StatefulWidget {
  const Dashboard({Key? key}) : super(key: key);
  final String title = Pages.dashboard;
  static const routeNamed = '/Dashboard';

  @override
  State<Dashboard> createState() => _DashboardState();
}

class _DashboardState extends State<Dashboard> with TickerProviderStateMixin {
  late TabController _mainController;

  late TabController _meterListTypeController;

  @override
  void initState() {
    super.initState();

    _mainController = TabController(
      initialIndex: allRoutesGlobal ? 1 : 0,
      length: 2,
      vsync: this,
    );

    _meterListTypeController = TabController(
      initialIndex: 0,
      length: 3,
      vsync: this,
    );

    _mainController.addListener(() {
      _mainController.index == 0
          ? allRoutesGlobal = false
          : allRoutesGlobal = true;
    });
  }

  @override
  void dispose() {
    super.dispose();
    _mainController.dispose();
    _meterListTypeController.dispose();
  }

  @override
  Widget build(BuildContext context) {
    currentContext = context;
    debugPrint("My Routes D Skip ${myRoutesList.values.map((e) => {
          e.meterLocationID: e.skippedMeterIDs
        })}");
    debugPrint("My Routes D Meter ${myRoutesList.values.map((e) => {
          e.meterLocationID: e.meterIDs
        })}");
    debugPrint("My Routes D Comp ${myRoutesList.values.map((e) => {
          e.meterLocationID: e.readingCompletedMeterIDs
        })}");

    return DoubleBackToClose(
      child: Scaffold(
        appBar: AppBar(
          title: const TextWidget(
            text: AppStrings.gatherReadings,
            style: AppStyles.appBarTextStyle,
          ),
          leading: InkWell(
            onTap: () async {
              showLoader(LoaderStrings.pleaseWait);
              await addMeterReading(sync: true).then(
                (value) async => await addSkipReason(sync: true).then(
                  (value) async =>
                      await getAllListInCommunity(sync: true, hasAccess: true)
                          .then((value) async {
                    showLoader(LoaderStrings.pleaseWait);
                    await createWorkOrder(sync: true)
                        .then(
                            (value) async => await getProblemsList(sync: true))
                        .then((value) =>
                            routeWithRemove(page: Dashboard.routeNamed));
                  }),
                ),
              );
            },
            child: const Icon(
              Icons.sync,
              size: 25,
            ),
          ),
          actions: [
            SizedBox(
              width: width * 0.18,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  InkWell(
                    onTap: () async {
                      showLoader(LoaderStrings.pleaseWait);
                      await addMeterReading(sync: true);
                      await addSkipReason(sync: true);
                      await createWorkOrder(sync: true);
                      routeWithRemove(page: PinLoginPage.routeNamed);
                    },
                    child: const Icon(
                      Icons.logout,
                      size: 25,
                    ),
                  ),
                  InkWell(
                    onTap: () {
                      routeWithoutRemove(
                          page: SettingsPage.routeNamed,
                          arguments: Dashboard.routeNamed);
                    },
                    child: const Icon(
                      Icons.settings,
                      size: 25,
                    ),
                  ),
                ],
              ),
            )
          ],
        ),
        body: Padding(
          padding: EdgeInsets.symmetric(
              horizontal: width * 0.05, vertical: height * 0.03),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              Flexible(
                  flex: 1,
                  child: Column(
                    children: [
                      Padding(
                        padding: EdgeInsets.only(bottom: height * 0.005),
                        child: const Text(
                          AppStrings.community,
                          style: AppStyles.boldHeading,
                        ),
                      ),
                      DropDown(
                        width: width * 0.9,
                        list: communityList.values
                            .map((e) => e.communityName)
                            .toList(),
                        bgColor: AppColors.yellow,
                        dropdownColor: AppColors.yellow,
                        tStyle: AppStyles.dropdownTextStyle,
                      ),
                    ],
                  )),
              AppTabBar(
                tab1: AppStrings.myRoutes,
                tab2: AppStrings.allRoutes,
                controller: _mainController,
              ),
              Expanded(
                flex: 6,
                child: Padding(
                  padding: EdgeInsets.only(
                      top: height * 0.02, bottom: height * 0.018),
                  child: TabBarView(controller: _mainController, children: [
                    MyRouteListTab(
                      meterList: routeList != null
                          ? {
                              for (var element in myRoutesList.entries.where(
                                  (element) =>
                                      routeList!.containsKey(element.key)))
                                element.key: element.value
                            }
                          : {},
                      controller: _meterListTypeController,
                    ),
                    AllRouteListTab(
                      list: routeList?.values.toList(),
                      controller: _meterListTypeController,
                    ),
                  ]),
                ),
              ),
              AppTabBar(
                tab1: AppStrings.todo,
                tab2: AppStrings.completed,
                tab3: AppStrings.skipped,
                controller: _meterListTypeController,
              )
            ],
          ),
        ),
      ),
    );
  }
}
