import 'package:flutter/material.dart';
import 'package:fserv/bloc/app_bloc.dart';
import 'package:fserv/constants/app_constants.dart';
import 'package:fserv/functions/api_functions/add_skip_reason.dart';
import 'package:fserv/functions/api_functions/skip_reason_codes_api_functions.dart';
import 'package:fserv/functions/appfunctions.dart';
import 'package:fserv/functions/get_location.dart';
import 'package:fserv/model/meter.dart';
import 'package:fserv/model/meter_skip_reason.dart';
import 'package:fserv/route/route.dart';
import 'package:fserv/screens/appscreens.dart';
import 'package:fserv/widgets/app_widgets.dart';
import 'dart:io' as io;
import 'dart:math' as math show pi;
import 'package:fserv/widgets/readskip_reason.dart';
import 'package:url_launcher/url_launcher.dart';

bool _lastInTodo = false;
String readingLatitude = "";
String readingLongitude = "";

class Reading extends StatefulWidget {
  const Reading({Key? key}) : super(key: key);
  final String title = Pages.reading;
  static const routeNamed = '/Reading';

  @override
  State<Reading> createState() => _ReadingState();
}

class _ReadingState extends State<Reading> {
  late TextEditingController _controller;
  late FocusNode _focusNode;
  late TextEditingController _notesController;
  late AppBloc<bool> _boolBloc;
  late AppBloc<bool> _notesBloc;
  late AppBloc<int> _meterBloc;
  late Meter _info;

  late FocusNode _notesFocus;

  @override
  void initState() {
    _controller = TextEditingController();
    _focusNode = FocusNode();
    _notesFocus = FocusNode();
    _notesController = TextEditingController();
    _boolBloc = AppBloc<bool>()..data = false;
    _notesBloc = AppBloc<bool>()..data = true;
    _meterBloc = AppBloc<int>()..data = meterIndex;
    readingLatitude = "";
    readingLongitude = "";

    _notesFocus.addListener(() {
      if (_notesFocus.hasFocus) {
        _focusNode.unfocus();
        _boolBloc.change(false);
        _notesBloc.change(false);
      } else {
        _notesBloc.change(true);
      }
    });

    super.initState();
  }

  @override
  void dispose() {
    _controller.dispose();
    _focusNode.dispose();
    _notesController.dispose();
    _boolBloc.close();
    _notesBloc.close();
    _meterBloc.close();
    _notesFocus.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    currentContext = context;

    return WillPopScope(onWillPop: () async {
      if (_boolBloc.data!) {
        _focusNode.unfocus();
        _boolBloc.change(false);
      } else {
        routeWithRemove(page: Dashboard.routeNamed);
      }
      return false;
    }, child: _meterBloc.stream((context) {
      meterID = currentMeterList[_meterBloc.data!];
      _info = meterList[meterID]!;
      _controller.clear();
      bool lastMeter = meterIndex == currentMeterList.length - 1;
      bool firstMeter = meterIndex == 0;
      _notesController.text = nullString(_info.meterNotes);
      if (!_notesFocus.hasFocus) {
        _focusNode.requestFocus();
        Future.delayed(const Duration(milliseconds: 100), () {
          _boolBloc.change(true);
        });
      }

      return Scaffold(
        resizeToAvoidBottomInset: false,
        appBar: AppBar(
          title: InkWell(
            onTap: () {
              showBottom(
                context: context,
                onTap: () {},
                child: MeterListSheet(
                  onSelect: (int index) {
                    meterIndex = currentMeterList.indexOf(index);
                    _meterBloc.change(meterIndex);
                    pop();
                  },
                ),
                whenComplete: true,
              );
            },
            child: TextWidget(
              text: _info.meterNo.toString(),
              style: AppStyles.appBarTextStyle,
            ),
          ),
          leading: InkWell(
            onTap: () async {
              routeWithRemove(page: Dashboard.routeNamed);
              _meterBloc.change(0);
            },
            child: const Icon(
              Icons.arrow_back,
              size: 25,
            ),
          ),
          actions: [
            SizedBox(
              width: width * 0.18,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(right: 8.0),
                    child: InkWell(
                      onTap: () async {
                        showLoader(LoaderStrings.pleaseWait);
                        await addMeterReading(sync: true).then((value) async {
                          await addSkipReason(sync: true);
                          await createWorkOrder(sync: true);

                          await getWorkOrderList(
                              sync: true, disableInternetSnack: true);

                          await getMyRoutes(
                              sync: true, disableInternetSnack: true);

                          await getSkipReasons(
                              sync: true, disableInternetSnack: true);

                          await getMeter(
                            routeId: meterLocationID,
                            communityId: selectedCommunityID,
                            sync: true,
                          );
                        });
                        if (currentMeterList.isEmpty || meterList.isEmpty) {
                          snackBar(SnackBarMessages.noMetersinThisRoute);
                          routeWithRemove(page: Dashboard.routeNamed);
                        } else {
                          routeWithRemove(page: Reading.routeNamed);
                        }
                      },
                      child: const Icon(
                        Icons.sync,
                        size: 30,
                      ),
                    ),
                  ),
                  InkWell(
                    onTap: () async {
                      appPausedTime = timeNow;
                      double? latitude = double.tryParse(_info.latitude);
                      double? longitude = double.tryParse(_info.longitude);
                      bool canLaunchUrl = false;
                      if ((!_info.latitude.contains(RegExp(r'[A-Za-z]')) &&
                              !_info.longitude.contains(RegExp(r'[A-Za-z]')))
                          ? (latitude != null
                                  ? (latitude.clamp(-90, 90) == latitude &&
                                      _info.latitude.length < 18)
                                  : false) &&
                              (longitude != null
                                  ? (longitude.clamp(-180, 180) == longitude &&
                                      _info.longitude.length < 18)
                                  : false)
                          : false) {
                        if (io.Platform.isIOS) {
                          String url =
                              'https://maps.apple.com/?ll=${_info.latitude},${_info.longitude}&q=${_info.latitude},${_info.longitude}';

                          canLaunchUrl = await canLaunch(url);
                          if (canLaunchUrl) {
                            await launch(url);
                          } else {
                            await launch(
                                'https://maps.apple.com/?ll=${_info.latitude},${_info.longitude}&q=${_info.latitude},${_info.longitude}');
                          }
                        } else {
                          await launch(
                              'https://www.google.com/maps/search/?api=1&query=${_info.latitude},${_info.longitude}');
                        }
                      } else {
                        String addressLineOne = _info.addressLineOne ?? '';
                        String query = addressLineOne.contains(" ")
                            ? "${_info.addressLineOne?.replaceAll(' ', '')},${_info.city},${_info.state}-${_info.zip5}"
                            : "${_info.addressLineOne?.replaceAll(' ', '_')},${_info.city},${_info.state}-${_info.zip5}";

                        if (io.Platform.isIOS) {
                          String url =
                              'https://maps.apple.com/?q=${Uri.encodeQueryComponent(query)}';
                          canLaunchUrl = await canLaunch(url);
                          if (canLaunchUrl) {
                            await launch(url);
                          } else {
                            await launch('https://maps.apple.com/?ll=$query');
                          }
                        } else {
                          await launch(
                              'https://www.google.com/maps/search/?api=1&query=$query');
                        }
                      }
                    },
                    child: Transform.rotate(
                      angle: math.pi / 4,
                      child: const Icon(
                        Icons.navigation,
                        size: 30,
                      ),
                    ),
                  ),
                ],
              ),
            )
          ],
        ),
        body: AppKeyBoard(
          maxLength: 20,
          keyboardBloc: _boolBloc,
          controller: _controller,
          allowSkip: meterListType != MeterListType.completed,
          onSkip: () {
            if (skipReasonsList.isNotEmpty) {
              skipCodesDialog(context, (id, notes) {
                pop();
                completeMeter(
                    meterReadSkipReasonID: id, skipNotes: notes, skip: true);
              });
            } else {
              snackBar(SnackBarMessages.emptySkipReason);
            }
          },
          onDone: () async {
            _focusNode.unfocus();
            _boolBloc.change(false);
            if (_controller.text.isNotEmpty &&
                RegExp(r"^(?!0\d)\d*(\.\d+)?$").hasMatch(_controller.text)) {
              await validationCheck();
            } else {
              snackBar(SnackBarMessages.enterValidInput);
            }
          },
          save: true,
          allowDecimal: true,
          allowNegative: false,
          child: Align(
            alignment: Alignment.topCenter,
            child: _boolBloc.stream(
              ((context) {
                return SingleChildScrollView(
                  child: Padding(
                    padding: EdgeInsets.only(
                        bottom: _boolBloc.data! ? height * 0.4 : 0),
                    child: Padding(
                      padding: EdgeInsets.only(
                          bottom:
                              MediaQuery.of(context).viewInsets.bottom + 20),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          InkWell(
                            onTap: () {
                              showBottom(
                                  context: context,
                                  onTap: () {},
                                  child: MeterDetails(
                                    info: _info,
                                  ));
                            },
                            child: Padding(
                              padding:
                                  const EdgeInsets.only(top: 10, bottom: 10),
                              child: SizedBox(
                                  height: height * 0.12,
                                  width: width * 0.96,
                                  child: DecoratedBox(
                                    decoration: BoxDecoration(
                                        color: AppColors.yellow,
                                        borderRadius: BorderRadius.circular(5)),
                                    child: Center(
                                      child: Text(
                                          nullString(_info.addressLineOne),
                                          textAlign: TextAlign.center,
                                          style: AppStyles.cardTextStyle
                                              .copyWith(
                                                  color: AppColors.black)),
                                    ),
                                  )),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.symmetric(vertical: 8.0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                InputTextFormField(
                                  focusNode: _focusNode,
                                  color: AppColors.grey,
                                  controller: _controller,
                                  width: width * 0.8,
                                  hint: AppStrings.enterReading,
                                  maxLines: 1,
                                  alignText: TextAlign.center,
                                  keyboardType: TextInputType.none,
                                  textStyle: AppStyles.cardTextStyle,
                                  onTap: () {
                                    _boolBloc.change(true);
                                  },
                                ),
                                SizedBox(
                                  height: height * 0.07,
                                  width: height * 0.07,
                                  child: DecoratedBox(
                                    decoration: BoxDecoration(
                                        borderRadius:
                                            BorderRadius.circular(100),
                                        color: AppColors.green),
                                    child: IconButton(
                                        onPressed: () {
                                          if (_boolBloc.data!) {
                                            _focusNode.unfocus();
                                            _boolBloc.change(false);
                                            snackBar(SnackBarMessages.autoRead);
                                          } else {
                                            _notesFocus.unfocus();
                                            snackBar(SnackBarMessages.autoRead);
                                          }
                                        },
                                        icon: Icon(
                                          Icons.camera_enhance,
                                          color: AppColors.black,
                                          size: height * 0.045,
                                        )),
                                  ),
                                )
                              ],
                            ),
                          ),
                          Padding(
                            padding:
                                const EdgeInsets.only(left: 10, bottom: 10),
                            child: Row(
                              children: [
                                InkWell(
                                  onTap: () {
                                    showBottom(
                                        context: context,
                                        onTap: () {},
                                        child: MeterInformation(
                                          info: _info,
                                        ));
                                  },
                                  child: const Icon(
                                    Icons.info,
                                    color: AppColors.white,
                                    size: 28,
                                  ),
                                ),
                                const Padding(
                                  padding:
                                      EdgeInsets.symmetric(horizontal: 8.0),
                                  child: TextWidget(
                                      text: AppStrings.meterNotes,
                                      style: AppStyles.readPageMeterTextStyle),
                                ),
                                SizedBox(
                                  child: InkWell(
                                    onTap: () {
                                      if (editMeterCommentsPrivilege) {
                                        _boolBloc.change(false);
                                        _notesBloc.change(false);
                                        _notesFocus.requestFocus();
                                      } else {
                                        snackBar(SnackBarMessages
                                            .youDontHavePrevilegeToEditMeterNotes);
                                      }
                                    },
                                    child: Row(
                                      children: const [
                                        Padding(
                                          padding: EdgeInsets.symmetric(
                                              horizontal: 4.0),
                                          child: TextWidget(
                                              text: AppStrings.edit,
                                              style: AppStyles
                                                  .readPageEditTextStyle),
                                        ),
                                        Icon(
                                          Icons.edit,
                                          color: AppColors.white,
                                          size: 22,
                                        )
                                      ],
                                    ),
                                  ),
                                ),
                                const Spacer()
                              ],
                            ),
                          ),
                          _notesBloc.stream((context) {
                            return _notesBloc.data!
                                ? Container(
                                    height: height * 0.25,
                                    width: width * 0.96,
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(4),
                                      color: AppColors.grey,
                                    ),
                                    child: SingleChildScrollView(
                                      child: Text(
                                        _notesController.text,
                                        style: AppStyles.cardTextStyle,
                                      ),
                                    ),
                                  )
                                : InputTextFormField(
                                    controller: _notesController,
                                    width: width * 0.96,
                                    height: height * 0.25,
                                    maxLength: 300,
                                    maxLines: 5,
                                    alignText: TextAlign.left,
                                    color: AppColors.grey,
                                    hint: "",
                                    keyboardType: TextInputType.text,
                                    textStyle: AppStyles.cardTextStyle,
                                    focusNode: _notesFocus,
                                  );
                          }),
                          Padding(
                            padding: const EdgeInsets.symmetric(
                                vertical: 24.0, horizontal: 16),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Button(
                                  width: width * 0.4,
                                  height: height * 0.054,
                                  onPress: () async {
                                    if (createWorkorderPrivilege) {
                                      if (await checkCommunityAccess(
                                          selectedCommunityID)) {
                                        showLoader(LoaderStrings.pleaseWait);

                                        await getProblemsList();

                                        await getWorkOrderList().then((value) {
                                          routeWithoutRemove(
                                              page: CreateWorkOrder.routeNamed);
                                        });
                                      }
                                    } else {
                                      snackBar(SnackBarMessages
                                          .youDontHavePrevilegeToCreateWorkorder);
                                    }
                                  },
                                  text: AppStrings.createWorkOrder,
                                  tStyle: AppStyles.buttonStyle,
                                ),
                                Button(
                                    width: width * 0.4,
                                    height: height * 0.054,
                                    onPress: () async {
                                      if (_controller.text.isNotEmpty) {
                                        await validationCheck();
                                      } else {
                                        snackBar(
                                            SnackBarMessages.enterValidInput);
                                      }
                                    },
                                    text: AppStrings.saveNext,
                                    tStyle: AppStyles.buttonStyle),
                              ],
                            ),
                          ),
                          SizedBox(
                            width: width * 0.8,
                            height: height * 0.08,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                InkWell(
                                  onTap: firstMeter
                                      ? null
                                      : (() async {
                                          await prevMeter();
                                        }),
                                  child: Transform.rotate(
                                    angle: math.pi,
                                    child: Image.asset(
                                      Images.arrow,
                                      color:
                                          firstMeter ? null : AppColors.green,
                                    ),
                                  ),
                                ),
                                InkWell(
                                  onTap: lastMeter
                                      ? null
                                      : (() async {
                                          await nextMeter();
                                        }),
                                  child: Image.asset(
                                    Images.arrow,
                                    color: lastMeter ? null : AppColors.green,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          if (showPreviousReadPrivilege)
                            Padding(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 8.0, vertical: 16.0),
                              child: Row(
                                children: [
                                  const TextWidget(
                                      text: AppStrings.lastRead,
                                      style: AppStyles.readPageYellowTextStyle),
                                  TextWidget(
                                      text:
                                          "${doubleToString(_info.lastReading)} , ${dateToString(DateTime.parse(_info.lastReadDate ?? AppStrings.defaultDate))}",
                                      style:
                                          AppStyles.readPageBoldWhiteTextStyle),
                                ],
                              ),
                            ),
                          if (showPreviousReadPrivilege)
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Row(
                                children: [
                                  const TextWidget(
                                      text: AppStrings.lastBilledUsage,
                                      style: AppStyles.readPageYellowTextStyle),
                                  TextWidget(
                                      text:
                                          doubleToString(_info.lastBilledUsage),
                                      style:
                                          AppStyles.readPageBoldWhiteTextStyle),
                                ],
                              ),
                            ),
                          if (showPreviousReadPrivilege)
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Row(
                                children: [
                                  const TextWidget(
                                      text: AppStrings.readingLatitude,
                                      style: AppStyles.readPageYellowTextStyle),
                                  TextWidget(
                                      text: _info.lastReadingLatitude ?? "",
                                      style:
                                          AppStyles.readPageBoldWhiteTextStyle),
                                ],
                              ),
                            ),
                          if (showPreviousReadPrivilege)
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Row(
                                children: [
                                  const TextWidget(
                                      text: AppStrings.readingLongitude,
                                      style: AppStyles.readPageYellowTextStyle),
                                  TextWidget(
                                      text: _info.lastReadingLongitude ?? "",
                                      style:
                                          AppStyles.readPageBoldWhiteTextStyle),
                                ],
                              ),
                            ),
                        ],
                      ),
                    ),
                  ),
                );
              }),
            ),
          ),
        ),
      );
    }));
  }

  Future<void> prevMeter() async {
    if (meterIndex == 0) {
      snackBar(SnackBarMessages.firstMeter);
    } else {
      showLoader(LoaderStrings.pleaseWait);
      await Future.delayed(const Duration(milliseconds: 300), () {
        pop();
        meterIndex -= 1;
        _meterBloc.change(meterIndex);
      });
    }
  }

  Future<void> nextMeter() async {
    if (meterIndex == currentMeterList.length - 1) {
      snackBar(SnackBarMessages.lastMeter);
    } else {
      showLoader(LoaderStrings.pleaseWait);
      await Future.delayed(const Duration(milliseconds: 300), () {
        pop();

        meterIndex += 1;
        _meterBloc.change(meterIndex);
      });
    }
  }

  validationCheck() async {
    if (await checkCommunityAccess(selectedCommunityID)) {
      bool isFailed = false;
      String message = "";

      if (_info.residentID != null) {
        if (_info.residentID! <= 0) {
          if (double.parse(_controller.text) != _info.lastReading) {
            isFailed = true;

            message = vacantUserMessage(double.parse(_controller.text));
          }
        } else {
          if (double.parse(_controller.text) == _info.lastReading) {
            message = zeroUsageMessage(double.parse(_controller.text));
            isFailed = true;
          }
        }
      }

      if (isFailed == false) {
        if (_info.rolloverReading != null) {
          if (_info.lastReading != null) {
            if (double.parse(_controller.text) < _info.lastReading!) {
              message = rollOverMessage(double.parse(_controller.text));
              isFailed = true;
            }
          }
        }
      }

      if (isFailed == false) {
        if (_info.multiplier != null &&
            _info.deviation != null &&
            _info.lastReading != null &&
            _info.lastReadDate != null) {
          int dayCount = dateTimeToBcTimeZone(timeNow)
              .difference(DateTime.parse(_info.lastReadDate!))
              .inDays;

          double allowance =
              ((_info.deviation! * dayCount) / double.parse(_info.multiplier!));
          if (allowance > 0) {
            double? highUsage = _info.lastReading! + allowance;
            if (double.parse(_controller.text) > highUsage) {
              message = highUsageMessage(double.parse(_controller.text));
              isFailed = true;
            } else {
              isFailed = false;
            }
          } else {
            isFailed = false;
          }
        }
      }

      if (!isFailed) {
        await recordGpsCoordinates();
      } else {
        showReadingConfirm(
            message: message,
            onTap: () async {
              pop();
              await recordGpsCoordinates();
            });
      }
    }
  }

  Future<void> recordGpsCoordinates() async {
    if (mtrReadAppGPS) {
      await getGpsCoordinates().then((value) async {
        pop();
        if (value != null &&
            value.latitude != null &&
            value.longitude != null) {
          readingLatitude = value.latitude!;
          readingLongitude = value.longitude!;
          await completeMeter();
        } else if (value != null &&
            value.latitude == null &&
            value.longitude == null) {
          snackBar(SnackBarMessages.unableToFetchLocation);
        }
      });
    } else {
      await completeMeter();
    }
  }

  Future<void> completeMeter({
    bool skip = false,
    int meterReadSkipReasonID = 0,
    String skipNotes = '',
  }) async {
    showLoader(LoaderStrings.pleaseWait);
    bool _isReadingSaved = false;
    if (skip) {
      AddMeterSkipReason _reason = AddMeterSkipReason(
          meterReadSkipReasonID: meterReadSkipReasonID,
          meterID: meterID,
          notes: skipNotes,
          userID: userID,
          status: 0,
          readDate: dateToBcTimeZone(timeNow));
      await dbHelper.insertReadings(
          _reason.toJson(), MeterSkipReasonApiStrings.meterSkipReasonTable);
    } else {
      Map<String, dynamic> row = {
        ReadingStrings.meterReadingID: 0,
        ReadingStrings.meterID: _info.meterID,
        ReadingStrings.previousDate:
            dateToString(DateTime.parse("1753-01-01 00:00:00.000")),
        ReadingStrings.previousReading: 0,
        ReadingStrings.presentDate: dateToBcTimeZone(timeNow),
        ReadingStrings.presentReading: double.parse(_controller.text),
        ReadingStrings.meterStatus: 0,
        ReadingStrings.prevMeterStatus: 0,
        ReadingStrings.inputDate:
            dateToString(DateTime.parse("1753-01-01 00:00:00.000")),
        ReadingStrings.unitOfMeasurementID: 0,
        ReadingStrings.estimationMethod: 0,
        ReadingStrings.hasTime: "false",
        ReadingStrings.inputUserID: userID,
        ReadingStrings.isEstimated: "false",
        ReadingStrings.importBatchID: 0,
        ReadingStrings.meterNotes: _notesController.text,
        ReadingStrings.message: _notesController.text,
        ReadingStrings.gPSLatitude: readingLatitude,
        ReadingStrings.gPSLongitude: readingLongitude,
      };
      await dbHelper.insertReadings(row, ReadingStrings.readingListTable);
    }
    if ((todoMeterList.length == 1 && meterListType == MeterListType.todo) ||
        (skippedMeterList.length == 1 &&
            meterListType == MeterListType.skipped)) {
      _lastInTodo = true;
    }
    await updateLocalList(
        notes: _notesController.text, skipReasonId: meterReadSkipReasonID);
    if (await hasNetwork()) {
      if (skip) {
        await addSkipReason().then((value) => _isReadingSaved = value);
      } else {
        await addMeterReading().then((value) => _isReadingSaved = value);
      }
    } else {
      _isReadingSaved = true;
      snackBar(SnackBarMessages.checkInternet);
    }
    if (_isReadingSaved) {
      if (myRoutesList.containsKey(meterLocationID)) {
        List _todoList = myRoutesList[meterLocationID]!.meterIDs;
        List _skippedList = myRoutesList[meterLocationID]!.skippedMeterIDs;
        List _completedList =
            myRoutesList[meterLocationID]!.readingCompletedMeterIDs;

        if (_todoList.contains(meterID)) {
          if (skip && !_skippedList.contains(meterID)) {
            myRoutesList[meterLocationID]!.skippedMeterIDs.add(meterID);
          } else if (!skip && !_completedList.contains(meterID)) {
            myRoutesList[meterLocationID]!
                .readingCompletedMeterIDs
                .add(meterID);
            if (_skippedList.contains(meterID)) {
              myRoutesList[meterLocationID]!.skippedMeterIDs.remove(meterID);
            }
          }
          await updateMyRoutesToDB({
            if (!skip) MyRoutesApiStrings.status: 1,
            if (skip) MyRoutesApiStrings.skipReasonID: 1,
          });
        }

        // }
      }

      await updateLocalList(
          notes: _notesController.text, skipReasonId: meterReadSkipReasonID);
      if (!_lastInTodo) {
        if (meterListType == MeterListType.completed) {
          if (meterIndex != currentMeterList.length - 1) {
            meterIndex += 1;
            meterID = currentMeterList[meterIndex];
            _meterBloc.change(meterIndex);
          } else {
            routeWithRemove(page: Dashboard.routeNamed);
          }
        } else if (meterIndex != 0 && meterIndex < currentMeterList.length) {
          _meterBloc.change(meterIndex);
        } else {
          meterID = currentMeterList.first;
          meterIndex = currentMeterList.indexOf(meterID);
          _meterBloc.change(meterIndex);
        }
        pop();
      } else {
        _lastInTodo = false;
        snackBar(SnackBarMessages.lastMeter);
        routeWithRemove(page: Dashboard.routeNamed);
      }
    } else {
      pop();
    }
  }
}
