import 'package:flutter/material.dart';
import 'package:fserv/constants/app_constants.dart';
import 'package:fserv/functions/appfunctions.dart';
import 'package:fserv/route/route.dart';
import 'package:fserv/screens/appscreens.dart';
import 'package:fserv/widgets/app_widgets.dart';

class CreateWorkOrder extends StatelessWidget {
  const CreateWorkOrder({Key? key}) : super(key: key);
  final String title = Pages.createWorkOrder;
  static const routeNamed = '/CreateWorkOrder';

  @override
  Widget build(BuildContext context) {
    currentContext = context;
    return WillPopScope(
      onWillPop: () async {
        routeWithRemove(page: Reading.routeNamed);
        return false;
      },
      child: DefaultTabController(
        length: 3,
        initialIndex: 1,
        child: Scaffold(
          appBar: PreferredSize(
              preferredSize: const Size.fromHeight(50.0),
              child: CustomAppBar(
                  title: meterList[meterID]!.meterNo!,
                  titleOnTap: () {
                    showBottom(
                      context: context,
                      onTap: () {},
                      child: MeterDetails(
                        info: meterList[meterID]!,
                      ),
                    );
                  },
                  leadinIcon: Icons.arrow_back,
                  leadingOnTap: () {
                    routeWithRemove(page: Reading.routeNamed);
                  },
                  titleStyle: AppStyles.appBarTextStyle)),
          body: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                flex: 6,
                child: Padding(
                  padding: const EdgeInsets.all(5),
                  child: DecoratedBox(
                    decoration: BoxDecoration(
                        color: AppColors.grey,
                        borderRadius: BorderRadius.circular(5)),
                    child: TabBarView(
                      children: [
                        WorkOrderListView(
                          list: workOrderList.isNotEmpty
                              ? workOrderList
                                  .where((element) =>
                                      nullDate(element.createdDate) !=
                                      nullDate(DateTime.now()))
                                  .toList()
                              : workOrderList.isEmpty
                                  ? []
                                  : null,
                        ),
                        ProblemsList(
                          info: meterList[meterID]!,
                        ),
                        WorkOrderListView(
                          list: workOrderList.isNotEmpty
                              ? workOrderList
                                  .where((element) =>
                                      nullDate(element.createdDate) ==
                                      nullDate(DateTime.now()))
                                  .toList()
                              : workOrderList.isEmpty
                                  ? []
                                  : null,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              Flexible(
                flex: 0,
                child: Padding(
                  padding: EdgeInsets.all(width * 0.01),
                  child: SizedBox(
                    width: width * 0.99,
                    child: DecoratedBox(
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(5),
                          color: AppColors.grey),
                      child: const Center(
                        child: TabBar(
                          isScrollable: true,
                          indicatorWeight: 0.1,
                          indicatorColor: Colors.transparent,
                          indicatorSize: TabBarIndicatorSize.label,
                          unselectedLabelColor: AppColors.lightgrey,
                          labelColor: AppColors.white,
                          labelStyle: AppStyles.problemsTabLabel,
                          tabs: [
                            Tab(text: AppStrings.previousWorkOrder),
                            Tab(text: AppStrings.problemText),
                            Tab(text: AppStrings.todayWorkOrder),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
