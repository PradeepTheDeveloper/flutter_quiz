import 'package:flutter/material.dart';
import 'package:fserv/constants/app_constants.dart';
import 'package:fserv/functions/int_to_string.dart';
import 'package:fserv/model/meter.dart';
import 'package:fserv/widgets/app_widgets.dart';

class MeterInformation extends StatelessWidget {
  final Meter info;
  const MeterInformation({
    Key? key,
    required this.info,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Flexible(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisSize: MainAxisSize.min,
        children: [
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 16.0),
            child: TextWidget(
                text: AppStrings.meterInformation,
                style: AppStyles.boldHeading),
          ),
          TitleValueText(
              label: AppStrings.serialNo, value: info.serialNo ?? ""),
          TitleValueText(label: AppStrings.meterNo, value: info.meterNo ?? ""),
          TitleValueText(label: AppStrings.amrId, value: info.amrId ?? ""),
          TitleValueText(label: AppStrings.amrType, value: info.amrType ?? ""),
          TitleValueText(
              label: AppStrings.standardMeterSize,
              value: info.stdMeterSize ?? ""),
          TitleValueText(label: AppStrings.route, value: meterLocationName),
          TitleValueText(
              label: AppStrings.meterId, value: intToString(info.meterID)),
        ],
      ),
    );
  }
}
