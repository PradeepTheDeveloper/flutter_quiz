import 'package:flutter/material.dart';
import '/bloc/app_bloc.dart';
import '/constants/app_constants.dart';
import '/functions/appfunctions.dart';
import '/widgets/app_widgets.dart';

class SignIn extends StatefulWidget {
  const SignIn({Key? key}) : super(key: key);
  static const routeNamed = '/SignIn';
  @override
  State<SignIn> createState() => _SignInState();
}

class _SignInState extends State<SignIn> {
  late TextEditingController _userName;
  late TextEditingController _password;
  late FocusNode _userNameFocus;
  late FocusNode _passwordFocus;
  late GlobalKey<FormState> _formKey;
  late AppBloc<bool> _showPinBloc;

  @override
  void initState() {
    _userName = TextEditingController();
    _password = TextEditingController();
    _userNameFocus = FocusNode();
    _formKey = GlobalKey<FormState>();
    _passwordFocus = FocusNode();
    _showPinBloc = AppBloc<bool>()..data = true;
    super.initState();
  }

  @override
  void dispose() {
    _userName.dispose();
    _password.dispose();
    _userNameFocus.dispose();
    _passwordFocus.dispose();
    _showPinBloc.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    currentContext = context;

    return DoubleBackToClose(
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        body: SingleChildScrollView(
          child: Padding(
            padding:
                EdgeInsets.only(top: 16.0, bottom: bottomInset + height * 0.1),
            child: Column(
              children: [
                SizedBox(
                  height: height * 0.05,
                ),
                const LogoHeader(),
                SizedBox(
                  height: height * 0.1,
                ),
                Form(
                  key: _formKey,
                  child: Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 20.0),
                        child: InputTextFormField(
                            maxLength: 30,
                            controller: _userName,
                            focusNode: _userNameFocus,
                            color: AppColors.lightWhite,
                            width: width * 0.7,
                            maxLines: 1,
                            hint: AppStrings.userName,
                            keyboardType: TextInputType.visiblePassword,
                            textStyle: AppStyles.signInTextStyle,
                            alignText: TextAlign.center),
                      ),
                      _showPinBloc.stream(
                        (context) => Padding(
                          padding: const EdgeInsets.symmetric(vertical: 8.0),
                          child: InputTextFormField(
                              maxLength: 24,
                              controller: _password,
                              focusNode: _passwordFocus,
                              color: AppColors.lightWhite,
                              width: width * 0.7,
                              maxLines: 1,
                              onSubmit: (value) async {
                                await register();
                              },
                              obscureText: _showPinBloc.data,
                              hint: AppStrings.password,
                              textStyle: AppStyles.signInTextStyle,
                              keyboardType: TextInputType.visiblePassword,
                              alignText: TextAlign.center),
                        ),
                      ),
                      _showPinBloc.stream((context) {
                        return Padding(
                          padding: const EdgeInsets.only(top: 40),
                          child: Row(
                            children: [
                              const Spacer(),
                              InkWell(
                                splashColor: Colors.transparent,
                                enableFeedback: false,
                                onTap: () {
                                  _showPinBloc.change(!_showPinBloc.data!);
                                },
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Icon(!_showPinBloc.data!
                                        ? Icons.visibility_off_rounded
                                        : Icons.visibility_rounded),
                                    Padding(
                                      padding: const EdgeInsets.only(left: 8),
                                      child: Text(
                                        _showPinBloc.data!
                                            ? AppStrings.showPassword
                                            : AppStrings.hidePassword,
                                        style: AppStyles.boldHeading,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              const Spacer(),
                            ],
                          ),
                        );
                      }),
                    ],
                  ),
                ),
                Padding(
                  padding: EdgeInsets.symmetric(
                      horizontal: width * 0.05, vertical: height * 0.02),
                  child: Button(
                    height: height * 0.06,
                    width: width * 0.9,
                    text: AppStrings.signin,
                    tStyle: AppStyles.buttonStyle,
                    onPress: () async {
                      if (_userNameFocus.hasFocus) {
                        _userNameFocus.unfocus();
                      } else if (_passwordFocus.hasFocus) {
                        _passwordFocus.unfocus();
                      }
                      await register();
                    },
                  ),
                ),
              ],
            ),
          ),
        ),
        bottomSheet: Footer(height: height),
      ),
    );
  }

  Future<void> register() async {
    if (_formKey.currentState!.validate()) {
      showLoader(LoaderStrings.pleaseWait);
      await registerNewUser(_userName.text, _password.text);
    }
  }
}
