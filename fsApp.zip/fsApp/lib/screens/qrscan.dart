import 'dart:convert' show jsonDecode;
import 'dart:io' show Platform;
import 'package:fserv/config/appconfigs.dart';
import 'package:fserv/model/appmodels.dart';
import 'package:fserv/screens/appscreens.dart' show ScanHint, SignIn;
import 'package:fserv/widgets/app_widgets.dart';
import 'package:qr_code_scanner/qr_code_scanner.dart'
    show QRViewController, QRView, QrScannerOverlayShape;
import 'package:flutter/material.dart';
import 'package:fserv/constants/app_constants.dart';
import 'package:fserv/route/route.dart';

import '../functions/new_function.dart';

class QRScan extends StatefulWidget {
  const QRScan({Key? key}) : super(key: key);
  static const routeNamed = '/QrScan';

  @override
  _QRScanState createState() => _QRScanState();
}

class _QRScanState extends State<QRScan> {
  QRViewController? qrController;
  final GlobalKey qrKey = GlobalKey(debugLabel: 'QR');

  void qrCallback(String? code) async {
    if (code != null) {
      qrController!.pauseCamera();
      showLoader(LoaderStrings.pleaseWait);
      Future.delayed(const Duration(seconds: 2), () {
        pop();
        try {
          dynamic data = jsonDecode(code);
          qrData = QRData.fromJson(data);
          userID = qrData.userId;
          url = qrData.url;
          isScanned = true;
          billingCompanyID = qrData.billingCompanyId;
          CacheStorage.storeString(SecureStorageKeys.url, url);
          CacheStorage.storeInt(SecureStorageKeys.userID, userID);
          CacheStorage.storeInt(
              SecureStorageKeys.billingCompanyID, billingCompanyID);
          CacheStorage.storeBool(SecureStorageKeys.isScanned, isScanned);
          routeWithRemove(page: SignIn.routeNamed);
        } on Exception catch (e) {
          newRelics(e.toString());
          debugPrint("$e");
          qrController!.resumeCamera();
          snackBar(SnackBarMessages.scanValidQR);
        }
      });
    } else {
      snackBar(SnackBarMessages.rescanQRFromPortal);
    }
  }

  @override
  void reassemble() {
    super.reassemble();
    if (Platform.isAndroid) {
      qrController!.pauseCamera();
    }
    qrController!.resumeCamera();
  }

  @override
  Widget build(BuildContext context) {
    currentContext = context;

    return WillPopScope(
      onWillPop: () async {
        routeWithRemove(page: ScanHint.routeNamed);
        return false;
      },
      child: Scaffold(
        backgroundColor: AppColors.black,
        appBar: PreferredSize(
            preferredSize: const Size.fromHeight(50),
            child: CustomAppBar(
              title: AppStrings.scanQRCode,
              titleStyle: AppStyles.appBarTextStyle,
              leadinIcon: Icons.arrow_back,
              leadingOnTap: () {
                routeWithRemove(page: ScanHint.routeNamed);
              },
            )),
        body: Stack(
          children: [
            IgnorePointer(
              ignoring: true,
              child: _buildQrView(context),
            ),
            SizedBox(
              child: Column(
                children: [
                  Padding(
                    padding: EdgeInsets.symmetric(
                        horizontal: width * 0.05, vertical: height * 0.05),
                    child: Text(
                      AppStrings.scanHintText,
                      style: AppStyles.scanTextStyle,
                      textAlign: TextAlign.justify,
                    ),
                  ),
                  const Spacer(),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }

  Widget _buildQrView(BuildContext context) {
    var scanArea = width * 0.8;
    return QRView(
      key: qrKey,
      onQRViewCreated: _onQRViewCreated,
      overlay: QrScannerOverlayShape(
          borderColor: Colors.blue,
          overlayColor: Colors.black,
          borderRadius: 10,
          borderLength: 30,
          borderWidth: 5,
          cutOutSize: scanArea),
    );
  }

  void _onQRViewCreated(QRViewController controller) {
    qrController = controller;

    qrController!.scannedDataStream.listen((scanData) {
      qrCallback(scanData.code);
    });
    controller.pauseCamera();
    controller.resumeCamera();
  }

  @override
  void dispose() {
    qrController!.dispose();
    super.dispose();
  }
}
