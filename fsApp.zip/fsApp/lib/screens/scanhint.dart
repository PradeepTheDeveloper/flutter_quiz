import 'package:flutter/material.dart';
import 'package:fserv/constants/app_constants.dart';
import 'package:fserv/route/route.dart';
import 'package:fserv/screens/appscreens.dart';
import 'package:fserv/widgets/app_widgets.dart';
import 'package:permission_handler/permission_handler.dart';

class ScanHint extends StatelessWidget {
  const ScanHint({Key? key}) : super(key: key);
  static const routeNamed = '/ScanHint';

  @override
  Widget build(BuildContext context) {
    currentContext = context;
    return DoubleBackToClose(
      child: Scaffold(
        backgroundColor: AppColors.black,
        appBar: const PreferredSize(
            preferredSize: Size.fromHeight(50),
            child: CustomAppBar(
              title: AppStrings.scanQRCode,
              titleStyle: AppStyles.appBarTextStyle,
            )),
        body: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Padding(
              padding: EdgeInsets.symmetric(
                  horizontal: width * 0.05, vertical: height * 0.05),
              child: Text(
                AppStrings.scanHintText,
                style: AppStyles.scanTextStyle,
                textAlign: TextAlign.justify,
              ),
            ),
            const Spacer(),
            SizedBox(
              height: height * 0.4,
              width: width * 0.8,
              child: ClipRRect(
                  borderRadius: BorderRadius.circular(25.0),
                  child: Image.asset(
                    Images.qrScanImage,
                    fit: BoxFit.contain,
                  )),
            ),
            const Spacer(),
            Button(
              height: height * 0.06,
              width: width * 0.9,
              text: AppStrings.ok,
              tStyle: AppStyles.buttonStyle,
              onPress: () async {
                if (await getPermission().isGranted) {
                  routeWithoutRemove(page: QRScan.routeNamed);
                }
              },
            ),
            const Spacer()
          ],
        ),
      ),
    );
  }
}

Future<PermissionStatus> getPermission() async {
  return await Permission.camera.request().then((value) {
    if (value.isPermanentlyDenied) {
      showPermissionDenied(currentContext, true);
    }
    return value;
  });
}
