import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import '../constants/variables.dart';
import '../functions/launch_app_store.dart';
import '../route/route.dart';
import '../widgets/custom_dialog.dart';

inAppUpdate() {
  flexUpdate == true
      ? showCustomDialog(
          Get.context!,
          widget: AlertDialog(
            title: const Text(dialogTitle),
            content: const Text(dialogMessage),
            actions: <Widget>[
              TextButton(
                child: Text(installNowButtonLabel),
                onPressed: () {
                  launchAppStore();
                },
              ),
              TextButton(
                child: const Text(laterButtonLabel),
                onPressed: () {
                  flexUpdate = false;
                  pop();
                },
              ),
            ],
          ),
        )
      : debugPrint("checking flex");
  forceUpdate == true
      ? showCustomDialog(
          Get.context!,
          widget: WillPopScope(
            onWillPop: () {
              SystemNavigator.pop();
              return Future.value(false);
            },
            child: AlertDialog(
              title: const Text(dialogTitle),
              content: const Text(dialogMessage),
              actions: <Widget>[
                TextButton(
                  child: Text(installNowButtonLabel),
                  onPressed: () {
                    launchAppStore();
                  },
                ),
              ],
            ),
          ),
        )
      : debugPrint("checking force");
}
