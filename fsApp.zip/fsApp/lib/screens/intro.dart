import 'package:flutter/material.dart';
import '/constants/app_constants.dart';
import '/route/route.dart';
import '/screens/appscreens.dart';
import '/widgets/app_widgets.dart';

class Login extends StatelessWidget {
  const Login({Key? key}) : super(key: key);
  static const routeNamed = '/Login';
  @override
  Widget build(BuildContext context) {
    currentContext = context;
    return DoubleBackToClose(
      child: Scaffold(
        body: SafeArea(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const LogoHeader(),
              Padding(
                padding: MediaQuery.of(context).padding,
                child: Padding(
                  padding: EdgeInsets.symmetric(
                    horizontal: width * 0.05,
                  ),
                  child: Button(
                    height: height * 0.06,
                    width: width * 0.9,
                    text: AppStrings.register,
                    tStyle: AppStyles.buttonStyle,
                    onPress: () async {
                      routeWithRemove(page: ScanHint.routeNamed);
                    },
                  ),
                ),
              ),
            ],
          ),
        ),
        bottomSheet: Footer(height: height),
      ),
    );
  }
}
