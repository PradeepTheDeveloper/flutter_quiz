import 'package:flutter/material.dart';
import '/bloc/app_bloc.dart';
import '/constants/app_constants.dart';
import '/functions/meter_read_dashboard_data.dart';
import '/route/route.dart';
import '/screens/appscreens.dart';
import '/widgets/app_widgets.dart';

import '../functions/appfunctions.dart';

class PinLoginPage extends StatefulWidget {
  static const routeNamed = '/PinLogInPage';
  final String title = Pages.pinLogin;

  const PinLoginPage({Key? key}) : super(key: key);

  @override
  State<PinLoginPage> createState() => _PinLoginPageState();
}

class _PinLoginPageState extends State<PinLoginPage> {
  late String _pin;

  late List<TextEditingController> _controllers;
  late List<FocusNode> _focusNodes;
  late ScrollController _scrollController;

  late AppBloc<bool> _keyBoardBloc;
  late AppBloc<bool> _showPinBloc;
  late AppBloc<TextEditingController> _controlBloc;

  @override
  void initState() {
    isPinLoginPage = true;
    _focusNodes = List.generate(4, (index) => FocusNode());
    _controllers = List.generate(4, (index) => TextEditingController());
    _scrollController = ScrollController();
    _pin = "";
    _keyBoardBloc = AppBloc<bool>()..data = false;
    _showPinBloc = AppBloc<bool>()..data = false;
    _controlBloc = AppBloc<TextEditingController>()
      ..data = TextEditingController();
    super.initState();
  }

  @override
  void dispose() {
    isPinLoginPage = false;

    for (TextEditingController element in _controllers) {
      element.dispose();
    }
    for (FocusNode element in _focusNodes) {
      element.dispose();
    }
    _keyBoardBloc.close();
    _showPinBloc.close();
    _controlBloc.close();
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    currentContext = context;
    return DoubleBackToClose(
      keyBoardVisibility: _keyBoardBloc,
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        body: _controlBloc.stream((context) {
          return AppKeyBoard(
              allowDecimal: false,
              allowNegative: false,
              maxLength: 1,
              keyboardBloc: _keyBoardBloc,
              controller: _controlBloc.data!,
              onDone: () {
                _keyBoardBloc.change(false);
                login();
              },
              save: false,
              child: _keyBoardBloc.stream(
                ((context) {
                  return ScrollConfiguration(
                    behavior: ScrollConfig(),
                    child: SingleChildScrollView(
                      child: Padding(
                        padding: EdgeInsets.only(
                          top: 16,
                          bottom:
                              _keyBoardBloc.data! ? height * 0.4 : height * 0.3,
                        ),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Padding(
                              padding: EdgeInsets.only(top: height * 0.05),
                              child: const LogoHeader(),
                            ),
                            const LoggedUser(),
                            Padding(
                              padding: EdgeInsets.only(
                                  bottom: 15, top: height * 0.06),
                              child: TextWidget(
                                text: AppStrings.enterPin,
                                style: AppStyles.pinTextStyle,
                              ),
                            ),
                            LoginPin(
                              showPinBloc: _showPinBloc,
                              onChanged: (pin) {
                                _pin = pin;
                              },
                              onComplete: (pin) async {
                                _pin = pin;
                                _keyBoardBloc.change(false);
                                await Future.delayed(
                                    const Duration(milliseconds: 300));

                                login();
                              },
                              onTap: (controller) {
                                _controlBloc.change(controller);
                                _keyBoardBloc.change(true);
                              },
                              controllers: _controllers,
                              focusNodes: _focusNodes,
                            ),
                            _showPinBloc.stream((context) {
                              return Padding(
                                padding: const EdgeInsets.only(top: 40),
                                child: Row(
                                  children: [
                                    const Spacer(),
                                    InkWell(
                                      splashColor: Colors.transparent,
                                      enableFeedback: false,
                                      onTap: () {
                                        _showPinBloc
                                            .change(!_showPinBloc.data!);
                                      },
                                      child: Row(
                                        children: [
                                          Icon(_showPinBloc.data!
                                              ? Icons.visibility_off_rounded
                                              : Icons.visibility_rounded),
                                          Padding(
                                            padding:
                                                const EdgeInsets.only(left: 8),
                                            child: TextWidget(
                                              text: !_showPinBloc.data!
                                                  ? AppStrings.showPin
                                                  : AppStrings.hidePin,
                                              style: AppStyles.boldHeading,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    const Spacer()
                                  ],
                                ),
                              );
                            }),
                            Padding(
                              padding: EdgeInsets.symmetric(
                                  horizontal: width * 0.05, vertical: 15),
                              child: Button(
                                height: height * 0.06,
                                width: width * 0.9,
                                text: AppStrings.loginText,
                                tStyle: AppStyles.buttonStyle,
                                onPress: login,
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                  );
                }),
              ));
        }),
      ),
    );
  }

  void login() async {
    dynamic _page;
    if (_pin.isNotEmpty && _pin.length == 4) {
      if (loginPin == _pin) {
        isPinLoginPage = false;

        showLoader(LoaderStrings.pleaseWait);
        await getToken(initialGet: true).then((value) async {
          if (value.statusCode == 200 || value.statusCode == 502) {
            if (resumed) {
              _page = await checkPausedState();
              if (_page != null) {
                routeWithRemove(page: _page);
              }
            }
            if (!resumed || _page == null) {
              if (meterReadPrivilege && !workOrderPrivilege) {
                await getMeterReadDashBoardData(const Dashboard());
              } else if (!meterReadPrivilege && workOrderPrivilege) {
                routeWithRemove(page: WorkOrderDashBoard.routeNamed);
              } else if (meterReadPrivilege && workOrderPrivilege) {
                routeWithRemove(page: ModuleSelectScreen.routeNamed);
              } else {
                pop();
                snackBar(SnackBarMessages.notAuthorized);
              }
            }
          }
        });
      } else {
        routeWithRemove(page: PinLoginPage.routeNamed);
        snackBar(SnackBarMessages.incorrectPin);
      }
    } else {
      snackBar(SnackBarMessages.enterValidPin);
    }
  }
}
