import 'package:flutter/material.dart';
import '/constants/app_constants.dart';
import '/functions/meter_read_dashboard_data.dart';
import '/route/route.dart';
import '/screens/appscreens.dart';
import '/widgets/app_widgets.dart';

class ModuleSelectScreen extends StatelessWidget {
  const ModuleSelectScreen({Key? key}) : super(key: key);
  final String title = Pages.moduleSelectPage;
  static const routeNamed = '/ModuleSelectScreen';

  @override
  Widget build(BuildContext context) {
    currentContext = context;
    return DoubleBackToClose(
      child: Scaffold(
        body: SafeArea(
          child: Column(
            children: [
              const LogoHeader(),
              SizedBox(
                height: height * 0.7,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    InkWell(
                      onTap: () async {
                        showLoader(LoaderStrings.pleaseWait);
                        await getMeterReadDashBoardData(Dashboard.routeNamed);
                      },
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Text(AppStrings.readMeters,
                              style: AppStyles.sloganStyle),
                          Padding(
                            padding: const EdgeInsets.only(left: 10),
                            child: ImageIcon(
                              const AssetImage(CustomIcon.meterReadingIcon),
                              size: width * 0.2,
                            ),
                          )
                        ],
                      ),
                    ),
                    InkWell(
                      onTap: () {
                        routeWithRemove(page: WorkOrderDashBoard.routeNamed);
                      },
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Text(
                            AppStrings.workOrders,
                            style: AppStyles.sloganStyle,
                          ),
                          Padding(
                            padding: const EdgeInsets.only(left: 10),
                            child: ImageIcon(
                              const AssetImage(CustomIcon.workorderIcon),
                              size: width * 0.2,
                            ),
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
