package com.starnik.smrt;

import androidx.annotation.NonNull;
import io.flutter.embedding.android.FlutterActivity;
import io.flutter.embedding.engine.FlutterEngine;
import io.flutter.plugin.common.MethodChannel;
import android.content.Intent;
import android.net.Uri;
import com.newrelic.agent.android.NewRelic;
import com.newrelic.agent.android.logging.AgentLog;
import java.util.Objects;

public class MainActivity extends FlutterActivity {
  private static final String DEVICEINFOCHANNEL = "deviceInfo";
  private static final String URLLAUNCH = "urlLaunch";
  private static final String NEWRELIC = "newRelic";

  @Override
  public void configureFlutterEngine(@NonNull FlutterEngine flutterEngine) {
    super.configureFlutterEngine(flutterEngine);

    NewRelic.withApplicationToken("AA7bb2e3507fdd2de2ad76888680dcc482b2ecb50c-NRMA").withCrashReportingEnabled(true)
        .withLogLevel(AgentLog.AUDIT)
        .start(this.getApplication());

    new MethodChannel(flutterEngine.getDartExecutor().getBinaryMessenger(), DEVICEINFOCHANNEL)
        .setMethodCallHandler(
            (call, result) -> {
              if (call.method.equals("deviceModel")) {
                String deviceName = android.os.Build.MODEL;
                result.success(deviceName);
              } else if (call.method.equals("deviceID")) {
                String deviceID = android.os.Build.ID;
                result.success(deviceID);
              } else if (call.method.equals("deviceOsVersion")) {
                String osVersion = android.os.Build.VERSION.RELEASE;
                result.success(osVersion);
              }

            else {
                result.notImplemented();
              }
            });

    new MethodChannel(flutterEngine.getDartExecutor().getBinaryMessenger(), URLLAUNCH)
        .setMethodCallHandler(
            (call, result) -> {

              if (call.method.equals("launchUrl")) {
                String url = call.argument("url");
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                startActivity(browserIntent);
                result.success("Done");
              }

            else {
                result.notImplemented();
              }
            });

    new MethodChannel(flutterEngine.getDartExecutor().getBinaryMessenger(), NEWRELIC)
        .setMethodCallHandler(
            (call, result) -> {

              if (call.method.equals("noticeHttpTransaction")) {
                String url = call.argument("url");
                String httpMethod = call.argument("httpMethod");
                int statusCode = call.argument("statusCode");
                long startTime = ((Number) Objects.requireNonNull(call.argument("startTime"))).longValue();
                long bytesSent = ((Number) Objects.requireNonNull(call.argument("bytesSent"))).longValue();
                long bytesReceived = ((Number) Objects.requireNonNull(call.argument("bytesReceived"))).longValue();
                long endTime = ((Number) Objects.requireNonNull(call.argument("endTime"))).longValue();
                NewRelic.noticeHttpTransaction(url, httpMethod, statusCode, startTime, endTime, bytesSent,
                    bytesReceived);
                result.success("Done");
              }

            else if (call.method.equals("setAttribute")) {
                  String name = call.argument("name");
                  String value = call.argument("value");

                  boolean done = NewRelic.setAttribute(name, value);
                result.success(done);
              }

              else if (call.method.equals("removeAttribute")) {
                  String name = call.argument("name");

                  boolean done = NewRelic.removeAttribute(name);
                  result.success(done);
              }

            else {
                result.notImplemented();
              }
            });
  }
}
